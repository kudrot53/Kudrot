# Travel Genie – Firebase Integration Guide (Firestore + Auth)

Goal: run entirely on Firebase (Firestore + Firebase Authentication). This replaces MySQL/REST. No SQL needed.

## 1) Firebase project setup
- Create a Firebase project at https://console.firebase.google.com.
- Add a Web App; copy the config keys into `.env.local` (use `.env.firebase.example` as a template).
- Enable **Authentication → Email/Password**.
- Enable **Firestore** (production mode) in your preferred region.
- (Optional) Enable **Hosting** if you want to deploy the built frontend.

## 2) Environment variables
Create `.env.local` in the repo root:
```
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
```

## 3) Client initialization
- `src/lib/firebase.ts` initializes Firebase, Auth, and Firestore using the Vite env vars.

## 4) Auth usage (email/password)
- Helpers in `src/api/firebase-auth.ts`:
  - `signUpWithEmail({ email, password, username, fullName })` → creates Firebase user + Firestore profile.
  - `signInWithEmail({ email, password })` → logs in.
  - `signOutUser()` → logs out.
  - `listenToAuthChanges(cb)` → subscribe to auth state changes.
- Link Firestore documents by `uid` (user doc id = auth.uid).

## 5) Firestore data layer (no joins)
- Helpers in `src/api/firebase-firestore.ts`:
  - `createTrip`, `updateTrip`, `deleteTrip`, `listMyTrips`.
  - `addItineraryItem`, `listItineraryItems`, `updateItineraryItem`, `deleteItineraryItem` (subcollection under trips/{tripId}/itineraries).
  - `addReview`, `listReviewsForTarget`.
  - `listAchievements`, `upsertUserAchievement`.
  - `createUserProfile`, `getMyProfile`.
- Collections structure (recommended):
  - `users/{uid}`: profile data
  - `trips/{tripId}`: trip data with ownerUid, isPublic flags
    - `itineraries/{itemId}`: itinerary items
    - `sharedAccess/{shareId}` (optional): access control entries
    - `plannedActivities/{id}` (optional): AI/plan activities
  - `reviews/{reviewId}`: public reviews (targetType, targetId)
  - `achievements/{achievementId}`: catalog
  - `users/{uid}/userAchievements/{achievementId}`: per-user progress

## 6) Security rules (starter – tighten for sharing as needed)
Deploy in Firestore Rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() { return request.auth != null; }

    match /users/{userId} {
      allow read: if signedIn() && request.auth.uid == userId;
      allow write: if request.auth.uid == userId;
    }

    match /users/{userId}/userAchievements/{docId} {
      allow read, write: if signedIn() && request.auth.uid == userId;
    }

    match /trips/{tripId} {
      allow read: if resource.data.isPublic == true || (signedIn() && resource.data.ownerUid == request.auth.uid);
      allow create: if signedIn();
      allow update, delete: if signedIn() && resource.data.ownerUid == request.auth.uid;
    }

    match /trips/{tripId}/itineraries/{itemId} {
      allow read, write: if signedIn() &&
        get(/databases/$(database)/documents/trips/$(tripId)).data.ownerUid == request.auth.uid;
    }

    match /reviews/{reviewId} {
      allow read: if true;
      allow create: if signedIn();
      allow update, delete: if signedIn() && resource.data.authorUid == request.auth.uid;
    }

    match /achievements/{id} {
      allow read: if true;
      allow write: if false; // manage via Admin if needed
    }
  }
}
```

## 7) Running locally
- `npm install` (installs Firebase SDK).
- Create `.env.local` with your Firebase keys.
- `npm run dev` to start the Vite dev server.

## 8) Wiring the app
- Replace usages of existing REST API clients (`src/api/*.ts`) with the Firebase helpers:
  - Auth: swap `authService` calls for `signUpWithEmail`, `signInWithEmail`, `signOutUser`, and read `auth.currentUser`.
  - Data: swap `apiClient.*` calls for `firebase-firestore.ts` functions (trips, itineraries, reviews, achievements).
- Keep owner UID on every write (`ownerUid`) for security rules.
- Timestamps: helpers already set `createdAt`/`updatedAt` via `serverTimestamp()`.

## 9) Importing existing data (optional)
- Script a one-time import using Firebase Admin SDK with batched writes (<=500 ops/batch) reading your existing export.
- Map MySQL IDs to Firestore doc IDs; store legacyId fields if you need cross-links.

## 10) Deployment
- If using Hosting: `npm run build` then `firebase deploy --only hosting` (after `firebase init hosting`).
- Firestore/Rules: `firebase deploy --only firestore:rules` when ready.
