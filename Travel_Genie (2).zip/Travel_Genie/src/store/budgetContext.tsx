import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
  type: 'expense' | 'income';
}

export interface Budget {
  total: number;
  currency: string;
  transactions: Transaction[];
}

interface BudgetContextType {
  budget: Budget;
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  removeTransaction: (id: string) => void;
  setBudgetTotal: (total: number) => void;
  getTotalSpent: () => number;
  getRemainingBudget: () => number;
  getTransactionsByCategory: (category: string) => Transaction[];
}

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

const BUDGET_STORAGE_KEY = 'travel_genie_budget';

export const BudgetProvider = ({ children }: { children: ReactNode }) => {
  const [budget, setBudget] = useState<Budget>(() => {
    // Try to load from localStorage
    const stored = localStorage.getItem(BUDGET_STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        // Fall back to default if parsing fails
      }
    }
    return {
      total: 5000,
      currency: 'USD',
      transactions: [],
    };
  });

  // Save to localStorage whenever budget changes
  useEffect(() => {
    localStorage.setItem(BUDGET_STORAGE_KEY, JSON.stringify(budget));
  }, [budget]);

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
    };
    setBudget(prev => ({
      ...prev,
      transactions: [newTransaction, ...prev.transactions],
    }));
  };

  const removeTransaction = (id: string) => {
    setBudget(prev => ({
      ...prev,
      transactions: prev.transactions.filter(t => t.id !== id),
    }));
  };

  const setBudgetTotal = (total: number) => {
    setBudget(prev => ({
      ...prev,
      total: Math.max(0, total),
    }));
  };

  const getTotalSpent = () => {
    return budget.transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  };

  const getRemainingBudget = () => {
    const totalIncome = budget.transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const totalSpent = getTotalSpent();
    return budget.total + totalIncome - totalSpent;
  };

  const getTransactionsByCategory = (category: string) => {
    return budget.transactions.filter(t => t.category === category);
  };

  return (
    <BudgetContext.Provider
      value={{
        budget,
        addTransaction,
        removeTransaction,
        setBudgetTotal,
        getTotalSpent,
        getRemainingBudget,
        getTransactionsByCategory,
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
};

export const useBudget = () => {
  const context = useContext(BudgetContext);
  if (context === undefined) {
    throw new Error('useBudget must be used within a BudgetProvider');
  }
  return context;
};
