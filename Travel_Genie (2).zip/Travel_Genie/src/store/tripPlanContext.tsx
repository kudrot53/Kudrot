import * as React from 'react';
import { travelsApi, type Travel } from '../api/travels';
import {
  tripPlanningApi,
  type TripPlan,
  type PlannedActivity,
} from '../api/trip-planning';
import { destinationsApi, type Destination } from '../api/destinations';
import { useAuth } from './authContext';

type CreateTripInput = {
  destinationId?: string;
  destinationName: string;
  startDate: string;
  endDate: string;
  travelers: number;
  budget?: number;
  currency?: string;
  companions?: string[];
};

type TripPlanContextType = {
  travels: Travel[];
  currentTravel: Travel | null;
  currentPlan: TripPlan | null;
  destinations: Destination[];
  loading: boolean;
  error: string | null;
  loadInitial: () => Promise<void>;
  selectTravel: (travelId: string) => Promise<void>;
  createTrip: (payload: CreateTripInput) => Promise<void>;
  updateTrip: (id: string, updates: Partial<Travel>) => Promise<void>;
  deleteTrip: (id: string) => Promise<void>;
  addActivity: (activity: Omit<PlannedActivity, 'id' | 'trip_plan_id' | 'is_completed' | 'created_at'>) => Promise<void>;
  removeActivity: (activityId: string) => Promise<void>;
  updateActivity: (activityId: string, updates: Partial<PlannedActivity>) => Promise<void>;
};

const TripPlanContext = React.createContext<TripPlanContextType | undefined>(undefined);

export const TripPlanProvider = ({ children }: { children: React.ReactNode }) => {
  const [travels, setTravels] = React.useState<Travel[]>([]);
  const [plans, setPlans] = React.useState<Record<string, TripPlan | null>>({});
  const [currentTravelId, setCurrentTravelId] = React.useState<string | null>(null);
  const [destinations, setDestinations] = React.useState<Destination[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const { isAuthenticated, isLoading: authLoading, logout } = useAuth();

  const currentTravel = currentTravelId ? travels.find((t) => String(t.id) === String(currentTravelId)) || null : null;
  const currentPlan = currentTravelId ? plans[currentTravelId] ?? null : null;

  const loadDestinations = React.useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const data = await destinationsApi.getDestinations(0, 200);
      setDestinations(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load destinations';
      setError(msg);
      if (msg.toLowerCase().includes('unauthorized') || msg.toLowerCase().includes('credential')) {
        logout();
      }
    }
  }, [isAuthenticated, logout]);

  const loadTravels = React.useCallback(async () => {
    if (!isAuthenticated) {
      setTravels([]);
      setPlans({});
      setCurrentTravelId(null);
      return;
    }
    try {
      const list = await travelsApi.getMyTravels();
      setTravels(list);
      if (!currentTravelId && list.length > 0) {
        setCurrentTravelId(String(list[0].id));
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load your trips';
      setError(msg);
      setTravels([]);
      if (msg.toLowerCase().includes('unauthorized') || msg.toLowerCase().includes('credential')) {
        logout();
      }
    }
  }, [currentTravelId, isAuthenticated, logout]);

  const loadInitial = React.useCallback(async () => {
    if (!isAuthenticated) {
      setLoading(false);
      setTravels([]);
      setPlans({});
      setCurrentTravelId(null);
      setError('Please log in to load your trips.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await Promise.all([loadDestinations(), loadTravels()]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load trip data';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated, loadDestinations, loadTravels]);

  const selectTravel = React.useCallback(
    async (travelId: string) => {
      if (!isAuthenticated) {
        setError('Please log in to load trip data.');
        return;
      }
      setCurrentTravelId(travelId);
      if (plans[travelId] !== undefined) return;
      try {
        const planList = await tripPlanningApi.getTripPlansByTravel(travelId);
        const plan = planList.length > 0 ? planList[0] : null;
        setPlans((prev) => ({ ...prev, [travelId]: plan }));
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to load trip plan';
        setError(msg);
        if (msg.toLowerCase().includes('unauthorized') || msg.toLowerCase().includes('credential')) {
          logout();
        }
      }
    },
    [plans, isAuthenticated, logout],
  );

  const createTrip = React.useCallback(
    async (payload: CreateTripInput) => {
      if (!isAuthenticated) {
        setError('Please log in to create a trip');
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const travel = await travelsApi.createTravel({
          title: payload.destinationName,
          description: payload.companions?.length ? `Companions: ${payload.companions.join(', ')}` : undefined,
          destination_id: payload.destinationId,
          start_date: payload.startDate,
          end_date: payload.endDate,
          number_of_travelers: payload.travelers,
          budget: payload.budget || undefined,
          currency: payload.currency || 'USD',
        });

        const plan = await tripPlanningApi.createTripPlan({
          title: `${payload.destinationName} Plan`,
          budget: payload.budget ?? 0,
          remaining_budget: payload.budget ?? 0,
          currency: payload.currency || 'USD',
          preferred_activities: [],
          travel_id: String(travel.id),
        });

        setTravels((prev) => [...prev, travel]);
        setPlans((prev) => ({ ...prev, [String(travel.id)]: { ...plan, activities: plan.activities || [] } }));
        setCurrentTravelId(String(travel.id));
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to create trip plan';
        setError(msg);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [isAuthenticated],
  );

  const updateTrip = React.useCallback(
    async (id: string, updates: Partial<Travel>) => {
      if (!isAuthenticated) {
        setError('Please log in to update trips');
        return;
      }
      setError(null);
      try {
        const updated = await travelsApi.updateTravel(id, {
          title: updates.title,
          description: updates.description,
          start_date: updates.start_date,
          end_date: updates.end_date,
          budget: updates.budget,
          currency: updates.currency,
          number_of_travelers: updates.number_of_travelers,
          destination_id: updates.destination_id,
        });

        setTravels((prev) => prev.map((t) => (String(t.id) === String(id) ? updated : t)));

        setPlans((prev) => {
          const plan = prev[String(id)];
          if (!plan) return prev;
          const nextPlan = { ...plan };
          const nextBudget = updates.budget ?? plan.budget;
          const nextCurrency = updates.currency ?? plan.currency;
          nextPlan.budget = nextBudget;
          nextPlan.currency = nextCurrency;
          if (updates.budget !== undefined) {
            nextPlan.remaining_budget = updates.budget;
          }
          return { ...prev, [String(id)]: nextPlan };
        });

        let planToUpdate = plans[String(id)];
        if (!planToUpdate) {
          const plansFromApi = await tripPlanningApi.getTripPlansByTravel(String(id));
          planToUpdate = plansFromApi.length ? plansFromApi[0] : null;
          if (planToUpdate) {
            setPlans((prev) => ({ ...prev, [String(id)]: planToUpdate! }));
          }
        }

        if (planToUpdate) {
          const nextBudget = updates.budget ?? planToUpdate.budget;
          const syncedPlan = await tripPlanningApi.updateTripPlan(planToUpdate.id, {
            budget: nextBudget,
            remaining_budget: nextBudget,
            currency: updates.currency ?? planToUpdate.currency,
            title: updates.title ? `${updates.title} Plan` : undefined,
            travel_id: String(id),
          });
          setPlans((prev) => ({
            ...prev,
            [String(id)]: {
              ...syncedPlan,
              activities: prev[String(id)]?.activities ?? planToUpdate!.activities ?? [],
              remaining_budget: syncedPlan.remaining_budget ?? nextBudget,
            },
          }));
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to update trip';
        setError(msg);
        throw err;
      }
    },
    [travels, plans, isAuthenticated],
  );

  const deleteTrip = React.useCallback(
    async (id: string) => {
      if (!isAuthenticated) {
        setError('Please log in to delete trips');
        return;
      }
      setError(null);
      try {
        await travelsApi.deleteTravel(id);
        setTravels((prev) => {
          const next = prev.filter((t) => String(t.id) !== String(id));
          setCurrentTravelId((current) => {
            if (String(current) !== String(id)) return current;
            return next.length > 0 ? String(next[0].id) : null;
          });
          return next;
        });
        setPlans((prev) => {
          const { [String(id)]: _, ...rest } = prev;
          return rest;
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to delete trip';
        setError(msg);
        throw err;
      }
    },
    [isAuthenticated],
  );

  const addActivity = React.useCallback(
    async (activity: Omit<PlannedActivity, 'id' | 'trip_plan_id' | 'is_completed' | 'created_at'>) => {
      if (!currentPlan) {
        setError('No trip plan selected');
        return;
      }
      if (!isAuthenticated) {
        setError('Please log in to add activities.');
        return;
      }
      setError(null);
      try {
        const created = await tripPlanningApi.createActivity(currentPlan.travel_id, currentPlan.id, {
          ...activity,
          cost: activity.cost ?? 0,
          currency: activity.currency ?? currentPlan.currency ?? 'USD',
        });
        setPlans((prev) => {
          const plan = prev[String(currentPlan.travel_id)];
          if (!plan) return prev;
          return {
            ...prev,
            [String(currentPlan.travel_id)]: { ...plan, activities: [...plan.activities, created] },
          };
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Failed to add activity';
        setError(msg);
        throw err;
      }
    },
    [currentPlan, isAuthenticated],
  );

  const removeActivity = React.useCallback(
    async (activityId: string) => {
      if (!currentPlan) return;
      await tripPlanningApi.deleteActivity(activityId, currentPlan.travel_id, currentPlan.id);
      setPlans((prev) => {
        const plan = prev[String(currentPlan.travel_id)];
        if (!plan) return prev;
        return {
          ...prev,
          [String(currentPlan.travel_id)]: {
            ...plan,
            activities: plan.activities.filter((a) => a.id !== activityId),
          },
        };
      });
    },
    [currentPlan],
  );

  const updateActivity = React.useCallback(
    async (activityId: string, updates: Partial<PlannedActivity>) => {
      if (!currentPlan) return;
      if (!isAuthenticated) {
        setError('Please log in to edit activities.');
        return;
      }
      const updated = await tripPlanningApi.updateActivity(currentPlan.travel_id, currentPlan.id, activityId, updates);
      setPlans((prev) => {
        const plan = prev[String(currentPlan.travel_id)];
        if (!plan) return prev;
        return {
          ...prev,
          [String(currentPlan.travel_id)]: {
            ...plan,
            activities: plan.activities.map((a) => (a.id === activityId ? updated : a)),
          },
        };
      });
    },
    [currentPlan, isAuthenticated],
  );

  React.useEffect(() => {
    if (authLoading) return;
    void loadInitial();
  }, [authLoading, loadInitial]);

  React.useEffect(() => {
    if (!isAuthenticated || authLoading) return;
    if (currentTravelId && plans[currentTravelId] === undefined) {
      void selectTravel(currentTravelId);
    }
  }, [authLoading, isAuthenticated, currentTravelId, plans, selectTravel]);

  return (
    <TripPlanContext.Provider
      value={{
        travels,
        currentTravel,
        currentPlan,
        destinations,
        loading,
        error,
        loadInitial,
        selectTravel,
        createTrip,
        updateTrip,
        deleteTrip,
        addActivity,
        removeActivity,
        updateActivity,
      }}
    >
      {children}
    </TripPlanContext.Provider>
  );
};

export const useTripPlan = () => {
  const context = React.useContext(TripPlanContext);
  if (context === undefined) {
    throw new Error('useTripPlan must be used within a TripPlanProvider');
  }
  return context;
};
