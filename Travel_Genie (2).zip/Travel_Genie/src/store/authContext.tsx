/**
 * Authentication Context
 * Global state management for user authentication
 */

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { authService } from '../api/auth';

export interface User {
  uid: string;
  email: string | null;
  username: string;
  full_name: string;
  avatar_url?: string;
  location?: string | null;
  bio?: string | null;
  is_premium?: boolean;
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (identifier: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, full_name: string, username: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * AuthProvider component to wrap the application
 */
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize auth state on mount
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const storedUser = authService.getUser();
        const isValid = await authService.verifyToken();

        if (storedUser && isValid) {
          const refreshedUser = await authService.fetchCurrentUser();
          setUser(refreshedUser || storedUser);
        } else if (storedUser && !isValid) {
          // Try to refresh token
          const refreshed = await authService.refreshToken();
          if (refreshed) {
            const refreshedUser = await authService.fetchCurrentUser();
            setUser(refreshedUser || authService.getUser());
          } else {
            authService.logout();
            setUser(null);
          }
        }
      } catch (err) {
        console.error('Auth initialization error:', err);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (identifier: string, password: string): Promise<boolean> => {
    try {
      setError(null);
      setIsLoading(true);

      const result = await authService.login({ identifier, password });

      if (result.success) {
        const authedUser = result.data?.user || authService.getUser();
        if (authedUser) {
          setUser(authedUser);
          return true;
        }
      }

      setError(result.error || 'Login failed');
      return false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Login failed';
      setError(message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (
    email: string,
    password: string,
    full_name: string,
    username: string
  ): Promise<boolean> => {
    try {
      setError(null);
      setIsLoading(true);

      const result = await authService.register({
        email,
        password,
        full_name,
        username,
      });

      if (result.success) {
        const authedUser = result.data?.user || authService.getUser();
        if (authedUser) {
          setUser(authedUser);
          return true;
        }
      }

      setError(result.error || 'Registration failed');
      return false;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Registration failed';
      setError(message);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
    setError(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        error,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Hook to use the AuthContext
 */
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

/**
 * Hook to require authentication for a component
 */
export const useRequireAuth = (redirectPath: string = '/login') => {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = require('react-router-dom').useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate(redirectPath);
    }
  }, [isAuthenticated, isLoading, redirectPath, navigate]);

  return { isAuthenticated, isLoading };
};
