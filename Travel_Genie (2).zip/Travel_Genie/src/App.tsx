import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import HomePage from './pages/HomePage';
import LoadingSpinner from './components/ui/LoadingSpinner';

// Lazy loaded components for better performance
const LoginPage = lazy(() => import('./pages/LoginPage'));
const UserDashboard = lazy(() => import('./pages/UserDashboard'));
const FeaturesPage = lazy(() => import('./pages/FeaturesPage'));
const TripPlanningPage = lazy(() => import('./pages/TripPlanningPage'));
const LeaderboardPage = lazy(() => import('./pages/LeaderboardPage'));
const ExpenseSplitterPage = lazy(() => import('./pages/ExpenseSplitterPage'));

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
        <Suspense fallback={<LoadingSpinner />}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/dashboard" element={<UserDashboard />} />
            <Route path="/features" element={<FeaturesPage />} />
            <Route path="/trip-planning" element={<TripPlanningPage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/expense-splitter" element={<ExpenseSplitterPage />} />
          </Routes>
        </Suspense>
      </div>
    </Router>
  );
}

export default App;