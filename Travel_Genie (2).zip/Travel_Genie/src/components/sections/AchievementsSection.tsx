import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserAchievement, Achievement, achievementsApi } from '../../api/achievements';
import AchievementCard from '../ui/AchievementCard';

interface AchievementsSectionProps {
  className?: string;
}

const AchievementsSection = ({ className = '' }: AchievementsSectionProps) => {
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [allAchievements, setAllAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'completed' | 'in-progress'>('all');
  const [selectedAchievement, setSelectedAchievement] = useState<UserAchievement | null>(null);

  useEffect(() => {
    fetchAchievements();
  }, []);

  const fetchAchievements = async () => {
    try {
      setLoading(true);
      const [userAchievementsData, allAchievementsData] = await Promise.all([
        achievementsApi.getUserAchievements(),
        achievementsApi.getAchievements()
      ]);
      
      setUserAchievements(userAchievementsData);
      setAllAchievements(allAchievementsData);
    } catch (err) {
      setError('Failed to load achievements');
      console.error('Error fetching achievements:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredAchievements = userAchievements.filter(achievement => {
    if (activeTab === 'completed') return achievement.is_completed;
    if (activeTab === 'in-progress') return !achievement.is_completed && achievement.progress > 0;
    return true; // 'all' tab
  });

  const completedCount = userAchievements.filter(a => a.is_completed).length;
  const inProgressCount = userAchievements.filter(a => !a.is_completed && a.progress > 0).length;
  const totalPoints = userAchievements
    .filter(a => a.is_completed)
    .reduce((sum, a) => sum + a.achievement.points, 0);

  const unlockedCount = userAchievements.length;
  const totalAvailableCount = allAchievements.length;

  if (loading) {
    return (
      <div className={`${className}`}>
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="bg-gray-200 rounded-xl h-48"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${className}`}>
        <div className="text-center py-12">
          <div className="text-red-500 mb-2">⚠️</div>
          <p className="text-gray-600">{error}</p>
          <button
            onClick={fetchAchievements}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`${className}`}>
      {/* Stats Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
      >
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-xl">
          <div className="text-3xl font-bold">{completedCount}</div>
          <div className="text-sm opacity-90">Completed</div>
        </div>
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-xl">
          <div className="text-3xl font-bold">{inProgressCount}</div>
          <div className="text-sm opacity-90">In Progress</div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-xl">
          <div className="text-3xl font-bold">{totalPoints}</div>
          <div className="text-sm opacity-90">Total Points</div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-xl">
          <div className="text-3xl font-bold">{unlockedCount}/{totalAvailableCount}</div>
          <div className="text-sm opacity-90">Unlocked</div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg w-fit">
        {[
          { id: 'all', label: 'All Achievements', count: userAchievements.length },
          { id: 'completed', label: 'Completed', count: completedCount },
          { id: 'in-progress', label: 'In Progress', count: inProgressCount }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.label} ({tab.count})
          </button>
        ))}
      </div>

      {/* Achievements Grid */}
      <AnimatePresence mode="wait">
        {filteredAchievements.length === 0 ? (
          <motion.div
            key="empty"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center py-12"
          >
            <div className="text-6xl mb-4">🏆</div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {activeTab === 'completed' && 'No completed achievements yet'}
              {activeTab === 'in-progress' && 'No achievements in progress'}
              {activeTab === 'all' && 'No achievements unlocked yet'}
            </h3>
            <p className="text-gray-600">
              {activeTab === 'completed' && 'Start completing challenges to earn your first achievement!'}
              {activeTab === 'in-progress' && 'Start working on some achievements to see them here!'}
              {activeTab === 'all' && 'Explore the app and start unlocking achievements!'}
            </p>
          </motion.div>
        ) : (
          <motion.div
            key="grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence>
              {filteredAchievements.map((userAchievement, index) => (
                <motion.div
                  key={userAchievement.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <AchievementCard
                    userAchievement={userAchievement}
                    onClick={() => setSelectedAchievement(userAchievement)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Achievement Detail Modal */}
      <AnimatePresence>
        {selectedAchievement && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
            onClick={() => setSelectedAchievement(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl p-6 max-w-md w-full"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-16 h-16 rounded-full flex items-center justify-center text-3xl"
                    style={{ backgroundColor: selectedAchievement.achievement.badge_color }}
                  >
                    {selectedAchievement.achievement.icon_url || '🏆'}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {selectedAchievement.achievement.name}
                    </h3>
                    <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                      {selectedAchievement.achievement.category}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedAchievement(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <p className="text-gray-600 mb-4">
                {selectedAchievement.achievement.description}
              </p>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700">Progress</span>
                  <span className="text-sm font-bold text-gray-900">
                    {selectedAchievement.progress}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all duration-300"
                    style={{ width: `${selectedAchievement.progress}%` }}
                  />
                </div>
              </div>

              <div className="mt-4 flex justify-between items-center pt-4 border-t">
                <div className="text-lg font-bold text-gray-900">
                  {selectedAchievement.achievement.points} points
                </div>
                {selectedAchievement.is_completed && (
                  <div className="flex items-center space-x-2 text-green-600">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    <span className="text-sm font-medium">Completed</span>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AchievementsSection;
