import { motion } from 'framer-motion';
import { Globe, Heart, Shield, Award, Users, Target } from 'lucide-react';

const AboutSection = () => {
    const stats = [
        { number: "500K+", label: "Happy Travelers", icon: Users },
        { number: "150+", label: "Countries", icon: Globe },
        { number: "98%", label: "Satisfaction", icon: Heart },
        { number: "24/7", label: "Support", icon: Shield }
    ];

    const values = [
        {
            icon: Target,
            title: "Mission",
            description: "To make travel planning effortless and enjoyable for everyone, using cutting-edge technology to create personalized experiences."
        },
        {
            icon: Heart,
            title: "Vision",
            description: "To become the world's most trusted travel companion, connecting people with amazing destinations and creating lifelong memories."
        },
        {
            icon: Award,
            title: "Excellence",
            description: "We strive for perfection in every detail, from destination recommendations to customer support, ensuring exceptional travel experiences."
        }
    ];

    return (
        <section id="about" className="py-20 bg-white">
            <div className="container mx-auto px-4">
                {/* Section Header */}
                <motion.div
                    className="text-center mb-16"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    <motion.h2
                        className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        About <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600">Travel Genie</span>
                    </motion.h2>

                    <motion.p
                        className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        We're revolutionizing the way people plan and experience travel. Our AI-powered platform
                        combines cutting-edge technology with human expertise to deliver unforgettable journeys.
                    </motion.p>
                </motion.div>

                {/* Stats Grid */}
                <motion.div
                    className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    {stats.map((stat, index) => (
                        <motion.div
                            key={index}
                            className="text-center"
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1, duration: 0.6 }}
                            viewport={{ once: true }}
                            whileHover={{ y: -10 }}
                        >
                            <motion.div
                                className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full mb-4 mx-auto"
                                whileHover={{ scale: 1.1, rotate: 5 }}
                                transition={{ duration: 0.3 }}
                            >
                                <stat.icon className="w-8 h-8 text-blue-600" />
                            </motion.div>

                            <motion.div
                                className="text-3xl lg:text-4xl font-bold text-gray-900 mb-2"
                                initial={{ opacity: 0, scale: 0.5 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                                viewport={{ once: true }}
                            >
                                {stat.number}
                            </motion.div>

                            <div className="text-gray-600 font-medium">{stat.label}</div>
                        </motion.div>
                    ))}
                </motion.div>

                {/* Values Section */}
                <motion.div
                    className="grid grid-cols-1 lg:grid-cols-3 gap-8"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    viewport={{ once: true }}
                >
                    {values.map((value, index) => (
                        <motion.div
                            key={index}
                            className="bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border border-gray-100 hover:shadow-xl transition-all duration-300"
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                            viewport={{ once: true }}
                            whileHover={{ y: -10, scale: 1.02 }}
                        >
                            <motion.div
                                className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full mb-6"
                                whileHover={{ scale: 1.1, rotate: 360 }}
                                transition={{ duration: 0.6 }}
                            >
                                <value.icon className="w-7 h-7 text-white" />
                            </motion.div>

                            <h3 className="text-2xl font-bold text-gray-900 mb-4">{value.title}</h3>
                            <p className="text-gray-600 leading-relaxed">{value.description}</p>
                        </motion.div>
                    ))}
                </motion.div>

                {/* Story Section */}
                <motion.div
                    className="mt-16 bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-8 lg:p-12 text-white"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                        <motion.div
                            initial={{ opacity: 0, x: -30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.3, duration: 0.8 }}
                            viewport={{ once: true }}
                        >
                            <h3 className="text-3xl lg:text-4xl font-bold mb-6">Our Story</h3>
                            <p className="text-lg leading-relaxed mb-6 text-blue-50">
                                Founded in 2020, Travel Genie emerged from a simple idea: travel planning should be
                                exciting, not overwhelming. Our team of travel enthusiasts and tech experts came together
                                to create a platform that combines the best of artificial intelligence with human insight.
                            </p>
                            <p className="text-lg leading-relaxed text-blue-50">
                                Today, we're proud to help hundreds of thousands of travelers discover new destinations,
                                create perfect itineraries, and make memories that last a lifetime.
                            </p>
                        </motion.div>

                        <motion.div
                            className="relative"
                            initial={{ opacity: 0, x: 30 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.5, duration: 0.8 }}
                            viewport={{ once: true }}
                        >
                            <div className="aspect-square bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                                <motion.div
                                    animate={{
                                        scale: [1, 1.1, 1],
                                        rotate: [0, 5, -5, 0],
                                    }}
                                    transition={{
                                        duration: 4,
                                        repeat: Infinity,
                                        ease: "easeInOut"
                                    }}
                                >
                                    <Globe className="w-32 h-32 text-white" />
                                </motion.div>
                            </div>
                        </motion.div>
                    </div>
                </motion.div>
            </div>
        </section>
    );
};

export default AboutSection;