import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle, Plane, MapPin, Calendar, DollarSign, Users, Shield, Camera } from 'lucide-react';

const FAQSection = () => {
    const [activeIndex, setActiveIndex] = useState<number | null>(null);

    const faqs = [
        {
            question: "How does Travel Genie create personalized itineraries?",
            answer: "Travel Genie uses advanced AI algorithms that analyze your preferences, travel history, budget, and interests. We consider factors like weather patterns, local events, crowd levels, and transportation options to create the perfect itinerary tailored specifically to you.",
            icon: Calendar,
            category: "Planning"
        },
        {
            question: "Can I modify my itinerary after it's been created?",
            answer: "Absolutely! Your itinerary is fully customizable. You can add, remove, or rearrange activities at any time. Our smart rescheduling feature will automatically adjust timing and suggest alternatives if needed.",
            icon: Calendar,
            category: "Planning"
        },
        {
            question: "How accurate are the budget estimates?",
            answer: "Our budget estimates are highly accurate, updated in real-time with current prices from verified partners. We include costs for accommodations, transportation, meals, activities, and even miscellaneous expenses. You can set your budget and we'll find options that match.",
            icon: DollarSign,
            category: "Budget"
        },
        {
            question: "Is my personal and payment information secure?",
            answer: "Yes, we use bank-level encryption and follow industry best practices for data security. Your information is never shared with third parties without your explicit consent, and we comply with GDPR and other privacy regulations.",
            icon: Shield,
            category: "Security"
        },
        {
            question: "Can I plan trips with friends or family?",
            answer: "Yes! Our group planning feature allows you to collaborate with others. You can share itineraries, vote on activities, split costs, and communicate through our built-in chat system. Everyone gets a say in the planning process.",
            icon: Users,
            category: "Groups"
        },
        {
            question: "What destinations do you cover?",
            answer: "We cover over 150 countries and thousands of cities worldwide. From popular tourist destinations to hidden gems off the beaten path, our database is constantly expanding with new destinations and local insights.",
            icon: MapPin,
            category: "Destinations"
        },
        {
            question: "How do you handle travel disruptions or changes?",
            answer: "Our system monitors your trip in real-time and alerts you to any disruptions. We provide alternative options and help you rebook automatically. In case of emergencies, our 24/7 support team is always available to assist.",
            icon: Plane,
            category: "Support"
        },
        {
            question: "Can I use Travel Genie for business travel?",
            answer: "Yes, we offer specialized features for business travelers including expense tracking, receipt management, meeting scheduling, and integration with corporate travel policies. Many companies use Travel Genie for their travel management.",
            icon: Users,
            category: "Business"
        }
    ];

    const categories = ["All", "Planning", "Budget", "Security", "Groups", "Destinations", "Support", "Business"];
    const [selectedCategory, setSelectedCategory] = useState("All");

    const filteredFAQs = selectedCategory === "All"
        ? faqs
        : faqs.filter(faq => faq.category === selectedCategory);

    const toggleFAQ = (index: number) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    const getCategoryIcon = (category: string) => {
        const iconMap: { [key: string]: any } = {
            "Planning": Calendar,
            "Budget": DollarSign,
            "Security": Shield,
            "Groups": Users,
            "Destinations": MapPin,
            "Support": Plane,
            "Business": Users
        };
        return iconMap[category] || HelpCircle;
    };

    return (
        <section id="faq" className="py-20 bg-gradient-to-br from-gray-50 to-white">
            <div className="container mx-auto px-4">
                {/* Section Header */}
                <motion.div
                    className="text-center mb-16"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    <motion.div
                        className="inline-flex items-center space-x-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6"
                        initial={{ opacity: 0, y: -20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1, duration: 0.6 }}
                        viewport={{ once: true }}
                    >
                        <HelpCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">Frequently Asked Questions</span>
                    </motion.div>

                    <motion.h2
                        className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        Got <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600">Questions?</span>
                    </motion.h2>

                    <motion.p
                        className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        Find answers to common questions about Travel Genie. Can't find what you're looking for?
                        Feel free to contact our support team.
                    </motion.p>
                </motion.div>

                {/* Category Filter */}
                <motion.div
                    className="flex flex-wrap justify-center gap-3 mb-12"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.6 }}
                    viewport={{ once: true }}
                >
                    {categories.map((category, index) => (
                        <motion.button
                            key={category}
                            onClick={() => setSelectedCategory(category)}
                            className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${selectedCategory === category
                                    ? 'bg-gradient-to-r from-blue-600 to-teal-600 text-white shadow-lg'
                                    : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-500'
                                }`}
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.5 + index * 0.05, duration: 0.4 }}
                            viewport={{ once: true }}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            {category === "All" ? (
                                <div className="flex items-center space-x-2">
                                    <HelpCircle className="w-4 h-4" />
                                    <span>{category}</span>
                                </div>
                            ) : (
                                <div className="flex items-center space-x-2">
                                    {(() => {
                                        const Icon = getCategoryIcon(category);
                                        return <Icon className="w-4 h-4" />;
                                    })()}
                                    <span>{category}</span>
                                </div>
                            )}
                        </motion.button>
                    ))}
                </motion.div>

                {/* FAQ Items */}
                <div className="max-w-4xl mx-auto space-y-4">
                    {filteredFAQs.map((faq, index) => (
                        <motion.div
                            key={index}
                            className="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300"
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
                            viewport={{ once: true }}
                        >
                            <motion.button
                                onClick={() => toggleFAQ(index)}
                                className="w-full px-6 py-5 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
                                whileHover={{ backgroundColor: '#F9FAFB' }}
                            >
                                <div className="flex items-center space-x-4 flex-1">
                                    <motion.div
                                        className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full flex items-center justify-center"
                                        whileHover={{ scale: 1.1, rotate: 360 }}
                                        transition={{ duration: 0.6 }}
                                    >
                                        <faq.icon className="w-6 h-6 text-blue-600" />
                                    </motion.div>

                                    <div className="flex-1">
                                        <h3 className="text-lg font-semibold text-gray-900 pr-4">{faq.question}</h3>
                                        <span className="text-sm text-blue-600 font-medium">{faq.category}</span>
                                    </div>
                                </div>

                                <motion.div
                                    className={`flex-shrink-0 w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center transition-colors duration-200 ${activeIndex === index ? 'bg-blue-100' : ''
                                        }`}
                                    animate={{ rotate: activeIndex === index ? 180 : 0 }}
                                    transition={{ duration: 0.3 }}
                                >
                                    <ChevronDown className={`w-4 h-4 ${activeIndex === index ? 'text-blue-600' : 'text-gray-600'}`} />
                                </motion.div>
                            </motion.button>

                            <AnimatePresence>
                                {activeIndex === index && (
                                    <motion.div
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        transition={{ duration: 0.3, ease: 'easeInOut' }}
                                        className="overflow-hidden"
                                    >
                                        <div className="px-6 pb-5 pt-0">
                                            <div className="pl-16">
                                                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                                            </div>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </motion.div>
                    ))}
                </div>

                {/* Still Have Questions */}
                <motion.div
                    className="mt-16 text-center bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-8 lg:p-12 text-white"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: 0.8 }}
                    viewport={{ once: true }}
                >
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.9, duration: 0.6 }}
                        viewport={{ once: true }}
                    >
                        <h3 className="text-3xl font-bold mb-4">Still Have Questions?</h3>
                        <p className="text-xl text-blue-50 mb-8 max-w-2xl mx-auto">
                            Our support team is here to help you 24/7. Get in touch and we'll be happy to assist you.
                        </p>

                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <motion.button
                                onClick={() => {
                                    const contactSection = document.getElementById('contact');
                                    if (contactSection) {
                                        contactSection.scrollIntoView({ behavior: 'smooth' });
                                    }
                                }}
                                className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors shadow-lg"
                                whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(0,0,0,0.2)' }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Contact Support
                            </motion.button>

                            <motion.button
                                className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-all duration-300"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Browse Help Center
                            </motion.button>
                        </div>
                    </motion.div>
                </motion.div>
            </div>
        </section>
    );
};

export default FAQSection;