import { motion } from 'framer-motion';
import { Map, Calendar, DollarSign, Users, Camera, Shield, Clock, Star } from 'lucide-react';

const ServicesSection = () => {
    const services = [
        {
            icon: Map,
            title: "Destination Discovery",
            description: "Explore thousands of curated destinations with detailed insights, hidden gems, and local recommendations.",
            features: ["AI-powered recommendations", "Local insights", "Seasonal guides", "Travel alerts"],
            color: "from-blue-500 to-blue-600"
        },
        {
            icon: Calendar,
            title: "Smart Itinerary Planning",
            description: "Create personalized day-by-day itineraries optimized for your interests, budget, and travel style.",
            features: ["Dynamic scheduling", "Weather integration", "Activity optimization", "Time management"],
            color: "from-teal-500 to-teal-600"
        },
        {
            icon: DollarSign,
            title: "Budget Management",
            description: "Track expenses in real-time, find the best deals, and stay within your travel budget effortlessly.",
            features: ["Expense tracking", "Deal finder", "Currency converter", "Budget alerts"],
            color: "from-green-500 to-green-600"
        },
        {
            icon: Users,
            title: "Group Coordination",
            description: "Plan trips with friends and family, collaborate on itineraries, and share experiences seamlessly.",
            features: ["Shared planning", "Voting system", "Group chat", "Photo sharing"],
            color: "from-purple-500 to-purple-600"
        },
        {
            icon: Camera,
            title: "Memory Preservation",
            description: "Document your journey with photo journals, location tagging, and beautiful travel stories.",
            features: ["Photo journal", "Location tagging", "Story creation", "Social sharing"],
            color: "from-pink-500 to-pink-600"
        },
        {
            icon: Shield,
            title: "Travel Safety",
            description: "Stay safe with 24/7 support, emergency contacts, travel insurance, and real-time safety alerts.",
            features: ["Emergency support", "Travel insurance", "Safety alerts", "Medical locator"],
            color: "from-red-500 to-red-600"
        }
    ];

    const benefits = [
        { icon: Clock, title: "Save Time", description: "Cut planning time by 80% with AI assistance" },
        { icon: DollarSign, title: "Save Money", description: "Find the best deals and avoid tourist traps" },
        { icon: Star, title: "Better Experience", description: "Discover authentic local experiences" },
        { icon: Users, title: "Stress-Free", description: "Enjoy your trip without worrying about details" }
    ];

    return (
        <section id="services" className="py-20 bg-gradient-to-br from-gray-50 to-white">
            <div className="container mx-auto px-4">
                {/* Section Header */}
                <motion.div
                    className="text-center mb-16"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    <motion.h2
                        className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600">Services</span>
                    </motion.h2>

                    <motion.p
                        className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        Comprehensive travel solutions designed to make every journey unforgettable.
                        From planning to execution, we've got you covered.
                    </motion.p>
                </motion.div>

                {/* Services Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
                    {services.map((service, index) => (
                        <motion.div
                            key={index}
                            className="group relative"
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1, duration: 0.6 }}
                            viewport={{ once: true }}
                        >
                            <motion.div
                                className="bg-white rounded-2xl p-8 h-full border border-gray-100 hover:shadow-2xl transition-all duration-300 relative overflow-hidden"
                                whileHover={{ y: -10 }}
                            >
                                {/* Background Gradient */}
                                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />

                                {/* Icon */}
                                <motion.div
                                    className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${service.color} rounded-full mb-6`}
                                    whileHover={{ scale: 1.1, rotate: 360 }}
                                    transition={{ duration: 0.6 }}
                                >
                                    <service.icon className="w-8 h-8 text-white" />
                                </motion.div>

                                {/* Content */}
                                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>

                                {/* Features */}
                                <ul className="space-y-2">
                                    {service.features.map((feature, featureIndex) => (
                                        <motion.li
                                            key={featureIndex}
                                            className="flex items-center space-x-2 text-sm text-gray-600"
                                            initial={{ opacity: 0, x: -10 }}
                                            whileInView={{ opacity: 1, x: 0 }}
                                            transition={{ delay: 0.5 + index * 0.1 + featureIndex * 0.05, duration: 0.4 }}
                                            viewport={{ once: true }}
                                        >
                                            <div className="w-1.5 h-1.5 bg-blue-600 rounded-full" />
                                            <span>{feature}</span>
                                        </motion.li>
                                    ))}
                                </ul>
                            </motion.div>
                        </motion.div>
                    ))}
                </div>

                {/* Benefits Section */}
                <motion.div
                    className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-3xl p-8 lg:p-12 text-white"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8 }}
                    viewport={{ once: true }}
                >
                    <motion.div
                        className="text-center mb-12"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.6 }}
                        viewport={{ once: true }}
                    >
                        <h3 className="text-3xl lg:text-4xl font-bold mb-4">Why Choose Travel Genie?</h3>
                        <p className="text-xl text-blue-50 max-w-2xl mx-auto">
                            Experience the difference with our innovative approach to travel planning
                        </p>
                    </motion.div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {benefits.map((benefit, index) => (
                            <motion.div
                                key={index}
                                className="text-center"
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.3 + index * 0.1, duration: 0.6 }}
                                viewport={{ once: true }}
                                whileHover={{ y: -10 }}
                            >
                                <motion.div
                                    className="inline-flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full mb-4 mx-auto"
                                    whileHover={{ scale: 1.1, rotate: 360 }}
                                    transition={{ duration: 0.6 }}
                                >
                                    <benefit.icon className="w-8 h-8 text-white" />
                                </motion.div>

                                <h4 className="text-xl font-bold mb-2">{benefit.title}</h4>
                                <p className="text-blue-100 text-sm">{benefit.description}</p>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            </div>
        </section>
    );
};

export default ServicesSection;