import { motion } from 'framer-motion';
import { ArrowRight, MapPin, Calendar, Users, Star, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
    const features = [
        { icon: MapPin, text: "1000+ Destinations" },
        { icon: Calendar, text: "Flexible Planning" },
        { icon: Users, text: "Community Reviews" },
        { icon: Star, text: "Expert Recommendations" }
    ];

    return (
        <section id="hero" className="min-h-screen flex items-center relative overflow-hidden">
            {/* Background Elements */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-teal-50" />

            {/* Floating Elements */}
            <motion.div
                className="absolute top-20 left-10 w-20 h-20 bg-blue-200 rounded-full opacity-20"
                animate={{
                    y: [0, -30, 0],
                    x: [0, 20, 0],
                }}
                transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            />

            <motion.div
                className="absolute bottom-20 right-10 w-32 h-32 bg-teal-200 rounded-full opacity-20"
                animate={{
                    y: [0, 40, 0],
                    x: [0, -30, 0],
                }}
                transition={{
                    duration: 8,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                }}
            />

            <motion.div
                className="absolute top-40 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-20"
                animate={{
                    y: [0, -20, 0],
                    x: [0, 15, 0],
                }}
                transition={{
                    duration: 5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 2
                }}
            />

            <div className="container mx-auto px-4 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    {/* Left Content */}
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8, ease: 'easeOut' }}
                    >
                        <motion.div
                            className="inline-flex items-center space-x-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6"
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2, duration: 0.6 }}
                        >
                            <Sparkles className="w-4 h-4" />
                            <span className="text-sm font-medium">AI-Powered Travel Planning</span>
                        </motion.div>

                        <motion.h1
                            className="text-5xl lg:text-7xl font-bold text-gray-900 leading-tight mb-6"
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.3, duration: 0.8 }}
                        >
                            Discover Your
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600"> Perfect Journey</span>
                        </motion.h1>

                        <motion.p
                            className="text-xl text-gray-600 mb-8 leading-relaxed"
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.4, duration: 0.8 }}
                        >
                            Let Travel Genie craft unforgettable experiences with intelligent recommendations,
                            seamless planning, and personalized itineraries tailored just for you.
                        </motion.p>

                        <motion.div
                            className="flex flex-col sm:flex-row gap-4 mb-12"
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.5, duration: 0.8 }}
                        >
                            <motion.button
                                whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(0,0,0,0.15)' }}
                                whileTap={{ scale: 0.95 }}
                                className="bg-gradient-to-r from-blue-600 to-teal-600 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center justify-center space-x-2"
                            >
                                <span>Start Planning</span>
                                <ArrowRight className="w-5 h-5" />
                            </motion.button>

                            <motion.button
                                whileHover={{ scale: 1.05, borderColor: '#3B82F6', color: '#3B82F6' }}
                                whileTap={{ scale: 0.95 }}
                                className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-full font-semibold text-lg hover:border-blue-500 transition-all duration-300"
                            >
                                Watch Demo
                            </motion.button>
                        </motion.div>

                        {/* Features Grid */}
                        <motion.div
                            className="grid grid-cols-2 sm:grid-cols-4 gap-4"
                            initial={{ opacity: 0, y: 30 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.6, duration: 0.8 }}
                        >
                            {features.map((feature, index) => (
                                <motion.div
                                    key={index}
                                    className="flex items-center space-x-2"
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.7 + index * 0.1, duration: 0.6 }}
                                >
                                    <feature.icon className="w-5 h-5 text-blue-600" />
                                    <span className="text-sm text-gray-600">{feature.text}</span>
                                </motion.div>
                            ))}
                        </motion.div>
                    </motion.div>

                    {/* Right Content - Interactive Visual */}
                    <motion.div
                        className="relative"
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8, ease: 'easeOut', delay: 0.3 }}
                    >
                        <div className="relative">
                            {/* Main Card */}
                            <motion.div
                                className="bg-white rounded-2xl shadow-2xl p-6 border border-gray-100"
                                whileHover={{ y: -10 }}
                                transition={{ duration: 0.3 }}
                            >
                                <div className="aspect-video bg-gradient-to-br from-blue-400 to-teal-400 rounded-xl mb-4 flex items-center justify-center">
                                    <motion.div
                                        animate={{
                                            rotate: [0, 5, -5, 0],
                                        }}
                                        transition={{
                                            duration: 4,
                                            repeat: Infinity,
                                            ease: "easeInOut"
                                        }}
                                    >
                                        <MapPin className="w-16 h-16 text-white" />
                                    </motion.div>
                                </div>

                                <h3 className="text-xl font-bold text-gray-900 mb-2">Cox&apos;s Bazar, Bangladesh</h3>
                                <p className="text-gray-600 mb-4">Unwind on the world&apos;s longest sea beach with our curated 7-day escape</p>

                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-1">
                                        {[...Array(5)].map((_, i) => (
                                            <motion.div
                                                key={i}
                                                initial={{ scale: 0 }}
                                                animate={{ scale: 1 }}
                                                transition={{ delay: 1 + i * 0.1, duration: 0.3 }}
                                            >
                                                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                            </motion.div>
                                        ))}
                                    </div>
                                    <span className="text-sm text-gray-500">4.9 (324 reviews)</span>
                                </div>
                            </motion.div>

                            {/* Floating Cards */}
                            <motion.div
                                className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg p-3 border border-gray-100"
                                animate={{
                                    y: [0, -10, 0],
                                }}
                                transition={{
                                    duration: 3,
                                    repeat: Infinity,
                                    ease: "easeInOut",
                                    delay: 0.5
                                }}
                            >
                                <div className="flex items-center space-x-2">
                                    <Calendar className="w-4 h-4 text-blue-600" />
                                    <span className="text-sm font-medium">7 Days</span>
                                </div>
                            </motion.div>

                            <motion.div
                                className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-3 border border-gray-100"
                                animate={{
                                    y: [0, 10, 0],
                                }}
                                transition={{
                                    duration: 3,
                                    repeat: Infinity,
                                    ease: "easeInOut",
                                    delay: 1
                                }}
                            >
                                <div className="flex items-center space-x-2">
                                    <Users className="w-4 h-4 text-teal-600" />
                                    <span className="text-sm font-medium">2-4 People</span>
                                </div>
                            </motion.div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default HeroSection;
