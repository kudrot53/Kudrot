import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Plus, MapPin, AlertCircle, ChevronDown } from 'lucide-react';
import { useTripPlan } from '../../store/tripPlanContext';

const ItineraryPreview = () => {
  const { currentTravel, currentPlan, addActivity, removeActivity } = useTripPlan();
  const [expandedItems, setExpandedItems] = useState<number[]>([]);
  const [newItem, setNewItem] = useState({
    name: '',
    category: 'food',
    cost: '',
    location: '',
    notes: '',
  });
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [error, setError] = useState('');

  const activities = currentPlan?.activities || [];
  const currencyCode = currentPlan?.currency || 'USD';
  const currencySymbol = useMemo(() => {
    const map: Record<string, string> = {
      USD: '$',
      EUR: 'EUR',
      GBP: 'GBP',
      BDT: 'BDT',
      INR: 'INR',
      CAD: 'C$',
      AUD: 'A$',
    };
    return map[currencyCode.toUpperCase()] || currencyCode.toUpperCase();
  }, [currencyCode]);

  const totalCost = useMemo(
    () => activities.reduce((sum, a) => sum + (a.cost || 0), 0),
    [activities],
  );

  if (!currentTravel) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-12"
      >
        <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <p className="text-gray-600">
          Create a trip plan or pick one from the selector to start adding itinerary items.
        </p>
      </motion.div>
    );
  }

  const handleAddItem = async () => {
    if (!newItem.name.trim()) {
      setError('Please enter an activity name');
      return;
    }
    try {
      await addActivity({
        name: newItem.name,
        category: newItem.category || 'food',
        cost: newItem.cost ? parseFloat(newItem.cost) : 0,
        currency: currentPlan?.currency || 'BDT',
        description: newItem.notes || undefined,
        location: newItem.location || undefined,
      });
      setNewItem({
        name: '',
        category: 'food',
        cost: '',
        location: '',
        notes: '',
      });
      setError('');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to add activity';
      setError(message);
    }
  };

  const generateSuggestions = () => {
    if (!currentTravel) return;
    const name = currentTravel.title.toLowerCase();
    const city = currentTravel.destination?.city?.toLowerCase?.() || '';
    const country = currentTravel.destination?.country?.toLowerCase?.() || '';
    const isBeach = name.includes('beach') || city.includes('cox') || city.includes('bazar');
    const isForest = name.includes('forest') || name.includes('sundar') || city.includes('mangrove');
    const isTea = name.includes('tea') || city.includes('srimangal') || city.includes('sylhet');
    const isCity = city.length > 0 && !isBeach && !isForest && !isTea;

    const base: string[] = [
      'Morning local breakfast crawl',
      'Sunset photo walk',
      'Evening street food tour',
      'Hidden alley coffee stop',
      'Local market treasure hunt',
      'Street art stroll',
      'Rooftop viewpoint at golden hour',
    ];

    const beachIdeas = [
      'Beach sunrise walk',
      'Seafood dinner',
      'Surf or kayak rental',
      'Beach market shopping',
      'Night bonfire by the shore',
    ];
    const forestIdeas = [
      'Boat safari',
      'Permit and guide meetup',
      'Wildlife lookout at dawn',
      'Nature trail with packed lunch',
      'Stargazing camp spot',
    ];
    const teaIdeas = [
      'Tea estate cycling loop',
      'Tea tasting session',
      'Seven-layer tea stop',
      'Sunrise over tea gardens',
      'Workshop with local tea makers',
    ];
    const cityIdeas = [
      'Historic old town walk',
      'Museum + cafe combo',
      'Riverfront evening promenade',
      'Local handicraft bazaar',
      'Night food lane crawl',
    ];
    const countryIdeas = [
      `Taste of ${country || 'local'} cooking class`,
      'Meet a local guide for hidden spots',
      'Festival / event scan for the evening',
    ];

    let pool = [...base];
    if (isBeach) pool = pool.concat(beachIdeas);
    if (isForest) pool = pool.concat(forestIdeas);
    if (isTea) pool = pool.concat(teaIdeas);
    if (isCity) pool = pool.concat(cityIdeas);
    if (country) pool = pool.concat(countryIdeas);

    // Shuffle and take 5 unique ideas
    const shuffled = [...new Set(pool)].sort(() => Math.random() - 0.5);
    setSuggestions(shuffled.slice(0, 5));
  };

  const toggleExpanded = (itemId: number) => {
    setExpandedItems((prev) =>
      prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId],
    );
  };

  const categories = [
    { value: 'food', label: 'Food & Dining' },
    { value: 'adventure', label: 'Adventure' },
    { value: 'cultural', label: 'Cultural' },
    { value: 'shopping', label: 'Shopping' },
    { value: 'accommodation', label: 'Accommodation' },
    { value: 'transportation', label: 'Transportation' },
    { value: 'other', label: 'Other' },
  ];

  return (
    <div className="tg-card p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {currentTravel.title}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Start Date</p>
            <p className="font-semibold text-gray-800">{new Date(currentTravel.start_date).toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-gray-600">End Date</p>
            <p className="font-semibold text-gray-800">{new Date(currentTravel.end_date).toLocaleDateString()}</p>
          </div>
          <div>
            <p className="text-gray-600">Travelers</p>
            <p className="font-semibold text-gray-800">{currentTravel.number_of_travelers}</p>
          </div>
          <div>
            <p className="text-gray-600">Activities</p>
            <p className="font-semibold text-gray-800">{activities.length}</p>
          </div>
        </div>
      </div>

      <div className="mb-8 p-5 bg-gradient-to-br from-blue-50 to-teal-50 rounded-lg border border-blue-200">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Add Activity
        </h3>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <input
            type="text"
            name="name"
            value={newItem.name}
            onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
            placeholder="Activity name (required)"
            className="tg-input"
          />

          <select
            name="category"
            value={newItem.category}
            onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
            className="tg-input"
          >
            {categories.map((cat) => (
              <option key={cat.value} value={cat.value}>
                {cat.label}
              </option>
            ))}
          </select>

          <input
            type="number"
            name="cost"
            value={newItem.cost}
            onChange={(e) => setNewItem({ ...newItem, cost: e.target.value })}
            placeholder="Cost (optional)"
            step="0.01"
            min="0"
            className="tg-input"
          />

          <input
            type="text"
            name="location"
            value={newItem.location}
            onChange={(e) => setNewItem({ ...newItem, location: e.target.value })}
            placeholder="Location (optional)"
            className="tg-input"
          />
        </div>

        <textarea
          name="notes"
          value={newItem.notes}
          onChange={(e) => setNewItem({ ...newItem, notes: e.target.value })}
          placeholder="Notes (optional)"
          rows={2}
          className="w-full tg-input mb-4"
        />

        <button
          onClick={handleAddItem}
          className="w-full tg-btn-primary"
        >
          <Plus className="w-4 h-4" />
          Add to Itinerary
        </button>

        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-semibold text-gray-800">Need ideas?</p>
            <button
              onClick={generateSuggestions}
              className="text-sm text-blue-600 hover:text-blue-700"
              type="button"
            >
              Suggest activities
            </button>
          </div>
          <div className="space-y-2">
            {suggestions.length === 0 && (
              <p className="text-sm text-gray-500">Click suggest to get itinerary ideas.</p>
            )}
            {suggestions.map((idea, idx) => (
              <button
                key={idx}
                onClick={() => setNewItem((prev) => ({ ...prev, name: idea, notes: prev.notes || '' }))}
                className="w-full text-left px-3 py-2 border border-dashed border-blue-200 rounded-lg hover:border-blue-400 hover:bg-white transition text-sm text-gray-700"
              >
                {idea}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Itinerary ({activities.length})
        </h3>

        {activities.length === 0 ? (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-8 text-gray-500"
          >
            No activities added yet. Create your first itinerary item above!
          </motion.p>
        ) : (
          <AnimatePresence>
            {activities.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-3"
              >
                <div
                  onClick={() => toggleExpanded(item.id)}
                  className="bg-gray-50 border border-gray-200 rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition flex items-start justify-between"
                >
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{item.name}</p>
                    <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600">
                      {item.category && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                          {item.category}
                        </span>
                      )}
                      {item.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {item.location}
                        </span>
                      )}
                      {item.cost !== undefined && (
                        <span className="flex items-center gap-1 text-green-700 font-semibold">
                          <span>{currencySymbol}</span> {item.cost}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <ChevronDown
                      className={`w-5 h-5 text-gray-600 transition ${
                        expandedItems.includes(item.id) ? 'rotate-180' : ''
                      }`}
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeActivity(item.id);
                      }}
                      className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <AnimatePresence>
                  {expandedItems.includes(item.id) && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-white border border-gray-200 border-t-0 rounded-b-lg p-4 text-sm text-gray-700"
                    >
                      {item.description ? (
                        <p className="text-gray-600">{item.description}</p>
                      ) : (
                        <p className="text-gray-500 italic">No additional details</p>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {activities.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-6 pt-6 border-t border-gray-200"
        >
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Total Activities</p>
              <p className="text-2xl font-bold text-blue-600">{activities.length}</p>
            </div>
            <div>
              <p className="text-gray-600">Total Budget</p>
              <p className="text-2xl font-bold text-green-600">
                {currencySymbol} {totalCost}
              </p>
            </div>
            <div>
              <p className="text-gray-600">Duration</p>
              <p className="text-2xl font-bold text-purple-600">
                {Math.max(
                  1,
                  Math.ceil(
                    (new Date(currentTravel.end_date).getTime() -
                      new Date(currentTravel.start_date).getTime()) /
                      (1000 * 60 * 60 * 24),
                  ),
                )}{' '}
                days
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default ItineraryPreview;
