import type { FC } from 'react';
import { motion } from 'framer-motion';
import { UserAchievement } from '../../api/achievements';

interface AchievementCardProps {
  userAchievement: UserAchievement;
  onClick?: () => void;
}

const AchievementCard: FC<AchievementCardProps> = ({ userAchievement, onClick }) => {
  const { achievement, progress, is_completed, completed_at } = userAchievement;
  
  const getProgressColor = () => {
    if (is_completed) return 'bg-gradient-to-r from-green-400 to-green-600';
    if (progress >= 75) return 'bg-gradient-to-r from-blue-400 to-blue-600';
    if (progress >= 50) return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
    if (progress >= 25) return 'bg-gradient-to-r from-orange-400 to-orange-600';
    return 'bg-gradient-to-r from-gray-400 to-gray-600';
  };

  const getCategoryColor = () => {
    switch (achievement.category.toLowerCase()) {
      case 'exploration': return 'bg-purple-100 text-purple-800';
      case 'social': return 'bg-blue-100 text-blue-800';
      case 'planning': return 'bg-green-100 text-green-800';
      case 'review': return 'bg-yellow-100 text-yellow-800';
      case 'milestone': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transition-all duration-300 ${
        is_completed ? 'ring-2 ring-green-400 ring-opacity-50' : ''
      }`}
    >
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div 
              className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${getProgressColor()}`}
              style={{ backgroundColor: achievement.badge_color }}
            >
              {achievement.icon_url || '🏆'}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{achievement.name}</h3>
              <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getCategoryColor()}`}>
                {achievement.category}
              </span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-gray-900">{achievement.points}</div>
            <div className="text-xs text-gray-500">points</div>
          </div>
        </div>

        {/* Description */}
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {achievement.description}
        </p>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm font-medium text-gray-900">{progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className={`h-full ${getProgressColor()} transition-all duration-300`}
            />
          </div>
        </div>

        {/* Completion Status */}
        {is_completed && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-4 flex items-center space-x-2 text-green-600"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span className="text-sm font-medium">
              Completed {completed_at ? new Date(completed_at).toLocaleDateString() : ''}
            </span>
          </motion.div>
        )}

        {/* In Progress Status */}
        {!is_completed && progress > 0 && (
          <div className="mt-4 flex items-center space-x-2 text-blue-600">
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span className="text-sm font-medium">In Progress</span>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default AchievementCard;
