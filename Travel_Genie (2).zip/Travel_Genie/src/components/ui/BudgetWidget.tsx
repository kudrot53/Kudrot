import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DollarSign,
  Plus,
  Trash2,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  ChevronDown,
} from 'lucide-react';
import { useBudget, type Transaction } from '../../store/budgetContext';

const BudgetWidget = () => {
  const { budget, addTransaction, removeTransaction, setBudgetTotal, getTotalSpent, getRemainingBudget } = useBudget();
  const [showForm, setShowForm] = useState(false);
  const [showTransactions, setShowTransactions] = useState(false);
  const [editBudget, setEditBudget] = useState(false);
  const [newBudgetAmount, setNewBudgetAmount] = useState(budget.total.toString());
  const [newTransaction, setNewTransaction] = useState({
    description: '',
    amount: '',
    category: 'food',
    type: 'expense' as 'expense' | 'income',
  });
  const [error, setError] = useState('');

  const totalSpent = getTotalSpent();
  const remaining = getRemainingBudget();
  const spentPercentage = budget.total > 0 ? (totalSpent / budget.total) * 100 : 0;
  const isOverBudget = remaining < 0;

  const categories = [
    { value: 'food', label: '🍽️ Food & Dining' },
    { value: 'accommodation', label: '🏨 Accommodation' },
    { value: 'transportation', label: '✈️ Transportation' },
    { value: 'activity', label: '🎭 Activity' },
    { value: 'shopping', label: '🛍️ Shopping' },
    { value: 'other', label: '📌 Other' },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewTransaction(prev => ({ ...prev, [name]: value }));
    setError('');
  };

  const handleAddTransaction = () => {
    if (!newTransaction.description.trim()) {
      setError('Please enter a description');
      return;
    }
    if (!newTransaction.amount || parseFloat(newTransaction.amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    addTransaction({
      description: newTransaction.description,
      amount: parseFloat(newTransaction.amount),
      category: newTransaction.category,
      date: new Date().toISOString(),
      type: newTransaction.type,
    });

    setNewTransaction({
      description: '',
      amount: '',
      category: 'food',
      type: 'expense',
    });
    setShowForm(false);
  };

  const handleSaveBudget = () => {
    const amount = parseFloat(newBudgetAmount);
    if (isNaN(amount) || amount < 0) {
      setError('Please enter a valid budget amount');
      return;
    }
    setBudgetTotal(amount);
    setEditBudget(false);
    setError('');
  };

  const getProgressColor = () => {
    if (isOverBudget) return 'from-red-600 to-red-400';
    if (spentPercentage > 75) return 'from-yellow-600 to-yellow-400';
    if (spentPercentage > 50) return 'from-blue-600 to-blue-400';
    return 'from-green-600 to-green-400';
  };

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.value === category);
    return cat ? cat.label.split(' ')[0] : '📌';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-lg p-6 mb-8"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <DollarSign className="w-6 h-6 text-blue-600" />
          Budget Tracker
        </h2>
      </div>

      {/* Budget Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {/* Total Budget */}
        <motion.div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600 font-semibold">Total Budget</p>
            {!editBudget && (
              <button
                onClick={() => setEditBudget(true)}
                className="text-xs text-blue-600 hover:underline"
              >
                Edit
              </button>
            )}
          </div>
          {editBudget ? (
            <div className="flex gap-2">
              <input
                type="number"
                value={newBudgetAmount}
                onChange={e => setNewBudgetAmount(e.target.value)}
                className="flex-1 px-2 py-1 border border-blue-300 rounded-lg text-sm"
              />
              <button
                onClick={handleSaveBudget}
                className="px-3 py-1 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          ) : (
            <p className="text-3xl font-bold text-blue-700">
              ${budget.total.toFixed(2)}
            </p>
          )}
        </motion.div>

        {/* Amount Spent */}
        <motion.div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4">
          <p className="text-sm text-gray-600 font-semibold mb-2 flex items-center gap-1">
            <TrendingDown className="w-4 h-4" />
            Spent
          </p>
          <p className="text-3xl font-bold text-orange-700">
            ${totalSpent.toFixed(2)}
          </p>
          <p className="text-xs text-orange-600 mt-1">
            {spentPercentage.toFixed(1)}% of budget
          </p>
        </motion.div>

        {/* Remaining Budget */}
        <motion.div
          className={`bg-gradient-to-br ${
            isOverBudget
              ? 'from-red-50 to-red-100'
              : 'from-green-50 to-green-100'
          } rounded-lg p-4`}
        >
          <p className="text-sm text-gray-600 font-semibold mb-2 flex items-center gap-1">
            <TrendingUp className="w-4 h-4" />
            Remaining
          </p>
          <p
            className={`text-3xl font-bold ${
              isOverBudget ? 'text-red-700' : 'text-green-700'
            }`}
          >
            ${remaining.toFixed(2)}
          </p>
          {isOverBudget && (
            <div className="flex items-center gap-1 text-xs text-red-600 mt-1">
              <AlertCircle className="w-3 h-3" />
              Over budget
            </div>
          )}
        </motion.div>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm font-semibold text-gray-700">Spending Progress</p>
          <p className="text-sm text-gray-600">{spentPercentage.toFixed(1)}%</p>
        </div>
        <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(spentPercentage, 100)}%` }}
            transition={{ duration: 0.5 }}
            className={`h-full bg-gradient-to-r ${getProgressColor()}`}
          />
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2"
        >
          <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-red-700 text-sm">{error}</p>
        </motion.div>
      )}

      {/* Add Transaction Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6 p-4 bg-gray-50 border border-gray-200 rounded-lg"
          >
            <h3 className="font-semibold text-gray-800 mb-4">Add Transaction</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  type="text"
                  name="description"
                  value={newTransaction.description}
                  onChange={handleInputChange}
                  placeholder="Description (required)"
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                />
                <input
                  type="number"
                  name="amount"
                  value={newTransaction.amount}
                  onChange={handleInputChange}
                  placeholder="Amount"
                  step="0.01"
                  min="0"
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <select
                  name="category"
                  value={newTransaction.category}
                  onChange={handleInputChange}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                >
                  {categories.map(cat => (
                    <option key={cat.value} value={cat.value}>
                      {cat.label}
                    </option>
                  ))}
                </select>
                <select
                  name="type"
                  value={newTransaction.type}
                  onChange={handleInputChange}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                >
                  <option value="expense">Expense</option>
                  <option value="income">Income</option>
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddTransaction}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold text-sm"
                >
                  Add Transaction
                </button>
                <button
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition font-semibold text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Transaction Button */}
      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full mb-4 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition font-semibold flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Transaction
        </button>
      )}

      {/* Transactions List */}
      <div>
        <button
          onClick={() => setShowTransactions(!showTransactions)}
          className="w-full flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition font-semibold text-gray-800"
        >
          <span>Recent Transactions ({budget.transactions.length})</span>
          <ChevronDown
            className={`w-5 h-5 transition ${showTransactions ? 'rotate-180' : ''}`}
          />
        </button>

        <AnimatePresence>
          {showTransactions && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-2 space-y-2"
            >
              {budget.transactions.length === 0 ? (
                <p className="text-center py-4 text-gray-500">No transactions yet</p>
              ) : (
                budget.transactions.map((transaction, index) => (
                  <motion.div
                    key={transaction.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getCategoryIcon(transaction.category)}</span>
                        <div>
                          <p className="font-semibold text-gray-800 text-sm">
                            {transaction.description}
                          </p>
                          <p className="text-xs text-gray-600">
                            {new Date(transaction.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span
                        className={`font-bold text-sm ${
                          transaction.type === 'expense'
                            ? 'text-red-600'
                            : 'text-green-600'
                        }`}
                      >
                        {transaction.type === 'expense' ? '-' : '+'}$
                        {transaction.amount.toFixed(2)}
                      </span>
                      <button
                        onClick={() => removeTransaction(transaction.id)}
                        className="p-1 text-red-600 hover:bg-red-100 rounded-lg transition"
                        title="Delete transaction"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default BudgetWidget;
