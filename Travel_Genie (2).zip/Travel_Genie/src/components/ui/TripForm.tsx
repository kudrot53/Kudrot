import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar, Users, Plus, AlertCircle, RefreshCcw } from 'lucide-react';
import { useTripPlan } from '../../store/tripPlanContext';
import { destinationsApi, type Destination } from '../../api/destinations';
import { authService } from '../../api/auth';
import type { Travel } from '../../api/travels';

interface TripFormProps {
  onSuccess?: () => void;
  groupMode?: boolean;
  selectedTravel?: Travel | null;
  onUpdated?: (id?: number) => void;
  readOnly?: boolean;
}

const TripForm = ({
  onSuccess,
  groupMode = false,
  selectedTravel,
  onUpdated,
  readOnly = false,
}: TripFormProps) => {
  const { createTrip, updateTrip, selectTravel } = useTripPlan();
  const [formData, setFormData] = useState({
    destinationId: '',
    destinationName: '',
    startDate: '',
    endDate: '',
    travelers: 1,
    budget: 0,
    currency: 'BDT',
  });
  const [error, setError] = useState('');
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [loadingDestinations, setLoadingDestinations] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [companions, setCompanions] = useState<string[]>([]);
  const [companionInput, setCompanionInput] = useState('');
  const isEditing = !!selectedTravel;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'travelers' ? parseInt(value, 10) : value,
    });
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const token = authService.getToken();
    if (!token) {
      setError('You must be logged in to save a trip plan.');
      return;
    }
    if (readOnly) {
      setError('This shared trip is view-only. Switch to one of your trips to edit.');
      return;
    }
    if (!formData.destinationId && !selectedTravel?.destination_id) {
      setError('Please select a destination');
      return;
    }
    const startDate = formData.startDate || selectedTravel?.start_date;
    const endDate = formData.endDate || selectedTravel?.end_date;

    if (!startDate) {
      setError('Please select a start date');
      return;
    }
    if (!endDate) {
      setError('Please select an end date');
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
      setError('Start date must be before end date');
      return;
    }
    if (formData.travelers < 1) {
      setError('At least one traveler required');
      return;
    }
    if (groupMode && companions.length === 0 && !isEditing) {
      setError('Add at least one companion to start a group trip');
      return;
    }

    const selectedDestination =
      destinations.find(d => d.id === Number(formData.destinationId)) ||
      destinations.find(d => d.id === selectedTravel?.destination_id);

    setSubmitting(true);
    setError('');

    const submit = async () => {
    const start = startDate;
    const end = endDate;

    if (isEditing && selectedTravel) {
        await updateTrip(selectedTravel.id, {
          destination_id: Number(formData.destinationId || selectedTravel.destination_id),
          start_date: start,
          end_date: end,
          number_of_travelers: formData.travelers,
          budget: formData.budget || undefined,
          currency: formData.currency || selectedTravel.currency,
          title: selectedDestination?.name || selectedTravel.title,
        });
        await selectTravel(selectedTravel.id);
        onUpdated?.(selectedTravel.id);
      } else {
        await createTrip({
          destinationId: Number(formData.destinationId),
          destinationName: selectedDestination?.name || formData.destinationName,
          startDate: start,
          endDate: end,
          travelers: formData.travelers,
          budget: formData.budget || undefined,
          currency: formData.currency || 'BDT',
          companions,
        });
        onUpdated?.();
        onSuccess?.();
      }
    };

    submit()
      .then(() => {
        if (!isEditing) {
          setFormData({
            destinationId: '',
            destinationName: '',
            startDate: '',
            endDate: '',
            travelers: 1,
            budget: 0,
            currency: 'BDT',
          });
          setCompanions([]);
          setCompanionInput('');
        }
      })
      .catch((err: unknown) => {
        const message = err instanceof Error ? err.message : 'Failed to save trip plan';
        setError(message);
      })
      .finally(() => setSubmitting(false));
  };

  const loadDestinations = async () => {
    try {
      setLoadingDestinations(true);
      const data = await destinationsApi.getDestinations(0, 100);
      setDestinations(data);
    } catch {
      setError('Could not load destinations from the server.');
    } finally {
      setLoadingDestinations(false);
    }
  };

  React.useEffect(() => {
    loadDestinations();
  }, []);

  React.useEffect(() => {
    if (!selectedTravel) {
      setFormData({
        destinationId: '',
        destinationName: '',
        startDate: '',
        endDate: '',
        travelers: 1,
        budget: 0,
        currency: 'BDT',
      });
      setCompanions([]);
      setCompanionInput('');
      setError('');
      return;
    }
    setFormData({
      destinationId: selectedTravel.destination_id ? String(selectedTravel.destination_id) : '',
      destinationName: selectedTravel.destination?.name || selectedTravel.title || '',
      startDate: selectedTravel.start_date || '',
      endDate: selectedTravel.end_date || '',
      travelers: selectedTravel.number_of_travelers || 1,
      budget: selectedTravel.budget || 0,
      currency: selectedTravel.currency || 'BDT',
    });
    setError('');
  }, [selectedTravel]);

  const addCompanion = () => {
    const value = companionInput.trim();
    if (!value) return;
    if (companions.includes(value)) {
      setCompanionInput('');
      return;
    }
    setCompanions((prev) => [...prev, value]);
    setCompanionInput('');
  };

  const removeCompanion = (name: string) => {
    setCompanions((prev) => prev.filter((c) => c !== name));
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="tg-card p-6 mb-8"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">{isEditing ? 'Edit Trip Plan' : 'Plan Your Trip'}</h2>
        {isEditing && !readOnly && (
          <button
            type="button"
            onClick={() => {
              setFormData({
                destinationId: '',
                destinationName: '',
                startDate: '',
                endDate: '',
                travelers: 1,
                budget: 0,
                currency: 'BDT',
              });
              setCompanions([]);
              setCompanionInput('');
              setError('');
            }}
            className="flex items-center gap-2 text-sm text-gray-600 hover:text-blue-600"
          >
            <RefreshCcw className="w-4 h-4" />
            New trip
          </button>
        )}
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3"
        >
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-red-700">{error}</p>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Destination Select */}
        <div>
          <label htmlFor="destination" className="block text-sm font-semibold text-gray-700 mb-2">
            <MapPin className="w-4 h-4 inline mr-2" />
            Destination
          </label>
          <select
            id="destination"
            name="destinationId"
            value={formData.destinationId}
            onChange={(e) => {
              const dest = destinations.find(d => d.id === Number(e.target.value));
              setFormData({
                ...formData,
                destinationId: e.target.value,
                destinationName: dest?.name || '',
              });
              setError('');
            }}
            className="tg-input"
            disabled={loadingDestinations || readOnly}
          >
            <option value="">{loadingDestinations ? 'Loading destinations...' : 'Select a destination'}</option>
            {destinations.map((dest) => (
              <option key={dest.id} value={dest.id}>
                {dest.name} ({dest.city}, {dest.country})
              </option>
            ))}
          </select>
        </div>

        {/* Travelers Input */}
        <div>
          <label htmlFor="travelers" className="block text-sm font-semibold text-gray-700 mb-2">
            <Users className="w-4 h-4 inline mr-2" />
            Number of Travelers
          </label>
          <select
            id="travelers"
            name="travelers"
            value={formData.travelers}
            onChange={handleInputChange}
              className="tg-input"
              disabled={readOnly}
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => (
              <option key={num} value={num}>
                {num} {num === 1 ? 'traveler' : 'travelers'}
              </option>
            ))}
          </select>
        </div>

        {/* Companions */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            Companions {groupMode ? '(required for group trips)' : '(optional)'}
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={companionInput}
              onChange={(e) => setCompanionInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addCompanion();
                }
              }}
              placeholder="Enter name or email"
              className="flex-1 tg-input"
              disabled={readOnly}
            />
            <button
              type="button"
              onClick={addCompanion}
              className="tg-btn-secondary"
            >
              Add
            </button>
          </div>
          {companions.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {companions.map((c) => (
                <span
                  key={c}
                  className="flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-sm"
                >
                  {c}
                  <button
                    type="button"
                    onClick={() => removeCompanion(c)}
                  className="text-blue-600 hover:text-blue-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          ) : (
            <p className="text-xs text-gray-500">Add friends to invite them into your trip workspace.</p>
          )}
        </div>

        {/* Start Date */}
        <div>
          <label htmlFor="startDate" className="block text-sm font-semibold text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Start Date
          </label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            value={formData.startDate}
            onChange={handleInputChange}
            className="tg-input"
            disabled={readOnly}
          />
        </div>

        {/* End Date */}
        <div>
          <label htmlFor="endDate" className="block text-sm font-semibold text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            End Date
          </label>
          <input
            type="date"
            id="endDate"
            name="endDate"
            value={formData.endDate}
            onChange={handleInputChange}
            className="tg-input"
            disabled={readOnly}
          />
        </div>

        {/* Budget */}
        <div>
          <label htmlFor="budget" className="block text-sm font-semibold text-gray-700 mb-2">
            Budget (optional)
          </label>
          <input
            type="number"
            id="budget"
            name="budget"
            value={formData.budget}
            onChange={(e) => setFormData({ ...formData, budget: Number(e.target.value) })}
            className="tg-input"
            min="0"
            disabled={readOnly}
          />
        </div>

        {/* Currency */}
        <div>
          <label htmlFor="currency" className="block text-sm font-semibold text-gray-700 mb-2">
            Currency
          </label>
          <select
            id="currency"
            name="currency"
            value={formData.currency}
            onChange={handleInputChange}
            className="tg-input"
            disabled={readOnly}
          >
            {['BDT', 'USD', 'EUR', 'INR'].map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      <motion.button
        type="submit"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
        className="mt-6 w-full tg-btn-primary disabled:opacity-70"
        disabled={submitting || readOnly}
      >
        <Plus className="w-5 h-5" />
        {submitting ? 'Saving...' : isEditing ? 'Update Trip Plan' : 'Create Trip Plan'}
      </motion.button>
    </motion.form>
  );
};

export default TripForm;
