import { listAchievements as fsListAchievements, upsertUserAchievement } from './firebase-firestore';

export interface Achievement {
    id: string;
    name: string;
    description: string;
    icon_url: string;
    badge_color: string;
    points: number;
    category: string;
    is_active: boolean;
}

export interface UserAchievement {
    id: string;
    user_id: string;
    achievement_id: string;
    progress: number;
    is_completed: boolean;
    completed_at?: string;
    achievement: Achievement;
}

export interface AchievementCreate {
    name: string;
    description: string;
    icon_url: string;
    badge_color: string;
    points: number;
    category: string;
    is_active?: boolean;
}

export interface UserAchievementUpdate {
    progress?: number;
    is_completed?: boolean;
}

// Achievements API backed by Firestore collections (achievements + users/{uid}/achievements)
export const achievementsApi = {
    getAchievements: async (_skip = 0, _limit = 100): Promise<Achievement[]> => {
        const list = await fsListAchievements();
        return list.map((a: any) => ({
            id: a.id,
            name: a.name,
            description: a.description,
            icon_url: a.icon_url,
            badge_color: a.badge_color,
            points: a.points ?? 0,
            category: a.category,
            is_active: a.is_active ?? true,
        }));
    },

    getAchievementsByCategory: async (category: string, skip = 0, limit = 100): Promise<Achievement[]> => {
        const all = await achievementsApi.getAchievements(skip, limit);
        return all.filter(a => a.category === category);
    },

    searchAchievements: async (query: string, skip = 0, limit = 100): Promise<Achievement[]> => {
        const all = await achievementsApi.getAchievements(skip, limit);
        return all.filter(
            a =>
                a.name.toLowerCase().includes(query.toLowerCase()) ||
                a.description.toLowerCase().includes(query.toLowerCase())
        );
    },

    getAchievement: async (achievementId: string | number): Promise<Achievement> => {
        const all = await achievementsApi.getAchievements();
        const hit = all.find(a => a.id === String(achievementId));
        if (!hit) throw new Error('Achievement not found');
        return hit;
    },

    // User Achievement endpoints (simplified)
    getUserAchievements: async (_skip = 0, _limit = 100): Promise<UserAchievement[]> => {
        // Not storing per-user achievements list here; return empty to avoid errors
        return [];
    },

    getCompletedUserAchievements: async (): Promise<UserAchievement[]> => {
        return [];
    },

    getUserAchievement: async (_userAchievementId: string | number): Promise<UserAchievement> => {
        throw new Error('Not implemented');
    },

    createUserAchievement: async (userAchievement: {
        achievement_id: string;
        progress?: number;
    }): Promise<UserAchievement> => {
        await upsertUserAchievement({
            achievementId: userAchievement.achievement_id,
            progress: userAchievement.progress ?? 0,
            isCompleted: false,
        });
        return {
            id: userAchievement.achievement_id,
            user_id: '',
            achievement_id: userAchievement.achievement_id,
            progress: userAchievement.progress ?? 0,
            is_completed: false,
            achievement: await achievementsApi.getAchievement(userAchievement.achievement_id),
        };
    },

    updateUserAchievement: async (
        userAchievementId: string | number,
        update: UserAchievementUpdate
    ): Promise<UserAchievement> => {
        await upsertUserAchievement({
            achievementId: String(userAchievementId),
            progress: update.progress ?? 0,
            isCompleted: update.is_completed ?? false,
        });
        return achievementsApi.createUserAchievement({
            achievement_id: String(userAchievementId),
            progress: update.progress,
        });
    },

    deleteUserAchievement: async (_userAchievementId: string | number): Promise<void> => {
        // Not implemented; requires delete of doc under users/{uid}/userAchievements/{id}
    },
};
