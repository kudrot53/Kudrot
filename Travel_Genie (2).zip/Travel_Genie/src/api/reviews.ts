import { addReview, listReviewsForTarget } from './firebase-firestore';

export interface Review {
    id: string;
    title: string;
    content: string;
    rating: number;
    review_type: string;
    is_verified: boolean;
    helpful_count: number;
    images?: string;
    created_at: string;
    updated_at?: string;
    user_id: number;
    destination_id?: number;
    travel_id?: number;
}

export interface ReviewCreate {
    title: string;
    content: string;
    rating: number;
    review_type: string;
    images?: string;
    destination_id?: number;
    travel_id?: number;
}

export interface ReviewUpdate {
    title?: string;
    content?: string;
    rating?: number;
    images?: string;
}

export const reviewsApi = {
    createReview: async (review: ReviewCreate): Promise<Review> => {
        const id = await addReview({
            targetType: review.destination_id ? 'destination' : 'trip',
            targetId: String(review.destination_id ?? review.travel_id ?? ''),
            rating: review.rating,
            title: review.title,
            content: review.content,
            images: review.images ? [review.images] : [],
        });
        return {
            id,
            title: review.title,
            content: review.content,
            rating: review.rating,
            review_type: review.review_type,
            is_verified: false,
            helpful_count: 0,
        };
    },

    getAllReviews: async (skip = 0, limit = 100): Promise<Review[]> => {
        // Firestore: no pagination implemented; return limited set
        const destinationReviews = await listReviewsForTarget('destination', '');
        return destinationReviews.slice(skip, skip + limit) as any;
    },

    getReviewsByTravel: async (travelId: number | string, _skip = 0, _limit = 100): Promise<Review[]> => {
        const list = await listReviewsForTarget('trip', String(travelId));
        return list as any;
    },

    getReviewsByDestination: async (destinationId: number | string, _skip = 0, _limit = 100): Promise<Review[]> => {
        const list = await listReviewsForTarget('destination', String(destinationId));
        return list as any;
    },

    getReviewsByUser: async (_userId: number | string, _skip = 0, _limit = 100): Promise<Review[]> => {
        // Not indexed by user in Firestore helper; return empty list for now
        return [];
    },

    getReviewsByType: async (type: string, skip = 0, limit = 100): Promise<Review[]> => {
        const byDest = await listReviewsForTarget('destination', type === 'destination' ? '' : 'noop');
        return byDest.slice(skip, skip + limit) as any;
    },

    searchReviews: async (query: string, skip = 0, limit = 100): Promise<Review[]> => {
        const all = await reviewsApi.getAllReviews();
        return all.filter(r => r.title.toLowerCase().includes(query.toLowerCase())).slice(skip, skip + limit);
    },

    getReview: async (_reviewId: number | string): Promise<Review> => {
        throw new Error('Not implemented for Firestore');
    },

    updateReview: async (_reviewId: number | string, _review: ReviewUpdate): Promise<Review> => {
        throw new Error('Not implemented for Firestore');
    },

    deleteReview: async (_reviewId: number | string): Promise<void> => {
        throw new Error('Not implemented for Firestore');
    },

    markReviewHelpful: async (_reviewId: number | string): Promise<{ helpful_count: number }> => {
        return { helpful_count: 0 };
    },
};
