/**
 * Firestore data access layer for Travel Genie (Firebase-only).
 * Provides CRUD helpers used by the UI instead of REST/SQL.
 */

import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type DocumentReference,
  type QueryConstraint,
} from 'firebase/firestore';
import { getFirestoreDb, getFirebaseAuth } from '../lib/firebase';

export type TripStatus = 'planning' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
export type ItineraryItemType =
  | 'accommodation'
  | 'transportation'
  | 'activity'
  | 'meal'
  | 'sightseeing'
  | 'shopping'
  | 'entertainment'
  | 'other';

export interface TravelInput {
  title: string;
  description?: string;
  startDate: string;
  endDate: string;
  status?: TripStatus;
  budget?: number;
  currency?: string;
  numberOfTravelers?: number;
  destinationId?: string;
  isPublic?: boolean;
  imageUrl?: string;
  notes?: string;
  shareToken?: string;
}

export interface ItineraryInput {
  title: string;
  description?: string;
  date: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  cost?: number;
  bookingReference?: string;
  notes?: string;
  isCompleted?: boolean;
  itemType: ItineraryItemType;
}

export interface ReviewInput {
  targetType: 'destination' | 'trip';
  targetId: string;
  rating: number;
  title: string;
  content: string;
  images?: string[];
}

export interface AchievementProgress {
  achievementId: string;
  progress: number;
  isCompleted: boolean;
}

export interface DestinationInput {
  name: string;
  country?: string;
  city?: string;
  description?: string;
  imageUrl?: string;
  category?: string;
  latitude?: number;
  longitude?: number;
  rating?: number;
  isFeatured?: boolean;
  averageCostPerDay?: number;
  currency?: string;
  language?: string;
  timezone?: string;
}

export interface TripPlanInput {
  title: string;
  description?: string;
  budget: number;
  remaining_budget?: number;
  currency?: string;
  preferred_activities?: string[];
  travel_id: string;
}

export interface ActivityInput {
  name: string;
  description?: string;
  cost: number;
  currency?: string;
  duration_hours?: number;
  location?: string;
  category?: string;
  booking_reference?: string;
  is_completed?: boolean;
}

export interface SharedAccessInput {
  email: string;
  access_level?: string;
}

const db = getFirestoreDb();
const auth = getFirebaseAuth();

const requireUid = (): string => {
  const uid = auth.currentUser?.uid;
  if (!uid) throw new Error('Not signed in');
  return uid;
};

// ---------------------------
// Users
// ---------------------------
export async function createUserProfile(data: {
  uid: string;
  email: string;
  username: string;
  fullName: string;
  avatarUrl?: string;
  location?: string | null;
  bio?: string | null;
}) {
  const ref = doc(db, 'users', data.uid);
  await setDoc(
    ref,
    {
      email: data.email,
      username: data.username,
      fullName: data.fullName,
      avatarUrl: data.avatarUrl || null,
      location: data.location ?? null,
      bio: data.bio ?? null,
      isPremium: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    },
    { merge: true },
  );
}

export async function updateUserProfile(patch: {
  fullName?: string;
  avatarUrl?: string | null;
  bio?: string | null;
  location?: string | null;
}) {
  const uid = requireUid();
  const ref = doc(db, 'users', uid);
  await updateDoc(ref, { ...patch, updatedAt: serverTimestamp() });
  const snap = await getDoc(ref);
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function getUserProfile(uid?: string) {
  const targetUid = uid || requireUid();
  const snap = await getDoc(doc(db, 'users', targetUid));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

// ---------------------------
// Travels (top-level collection)
// ---------------------------
const travelsCollection = collection(db, 'travels');

const mapTravel = (d: any) => ({
  id: d.id,
  ...d.data(),
});

export async function createTravel(payload: TravelInput) {
  const uid = requireUid();
  const ref = await addDoc(travelsCollection, {
    ...payload,
    userId: uid,
    status: payload.status || 'planning',
    currency: payload.currency || 'USD',
    numberOfTravelers: payload.numberOfTravelers ?? 1,
    isPublic: payload.isPublic ?? false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function updateTravel(travelId: string, patch: Partial<TravelInput>) {
  const ref = doc(db, 'travels', travelId);
  await updateDoc(ref, { ...patch, updatedAt: serverTimestamp() });
}

export async function deleteTravel(travelId: string) {
  await deleteDoc(doc(db, 'travels', travelId));
}

export async function listMyTravels() {
  const uid = requireUid();
  const q = query(travelsCollection, where('userId', '==', uid), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map(mapTravel);
}

export async function listPublicTravels(max = 100) {
  const q = query(travelsCollection, where('isPublic', '==', true), orderBy('createdAt', 'desc'), limit(max));
  const snap = await getDocs(q);
  return snap.docs.map(mapTravel);
}

// ---------------------------
// Itineraries (travels/{id}/itineraryItems)
// ---------------------------
const itineraryCollection = (travelId: string) => collection(db, 'travels', travelId, 'itineraryItems');

export async function addItineraryItem(travelId: string, item: ItineraryInput) {
  const ref = await addDoc(itineraryCollection(travelId), {
    ...item,
    isCompleted: item.isCompleted ?? false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function listItineraryItems(travelId: string) {
  const q = query(itineraryCollection(travelId), orderBy('date', 'asc'), orderBy('startTime', 'asc'));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function updateItineraryItem(travelId: string, itemId: string, patch: Partial<ItineraryInput>) {
  await updateDoc(doc(db, 'travels', travelId, 'itineraryItems', itemId), {
    ...patch,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteItineraryItem(travelId: string, itemId: string) {
  await deleteDoc(doc(db, 'travels', travelId, 'itineraryItems', itemId));
}

// ---------------------------
// Trip Plans (travels/{id}/tripPlans)
// ---------------------------
const tripPlansCollection = (travelId: string) => collection(db, 'travels', travelId, 'tripPlans');

export async function createTripPlan(travelId: string, input: TripPlanInput) {
  const ref = await addDoc(tripPlansCollection(travelId), {
    title: input.title,
    description: input.description || '',
    budget: input.budget,
    remaining_budget: input.remaining_budget ?? input.budget,
    currency: input.currency || 'USD',
    preferred_activities: input.preferred_activities || [],
    is_approved: false,
    travel_id: travelId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function listTripPlansByTravel(travelId: string) {
  const q = query(tripPlansCollection(travelId), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function updateTripPlan(travelId: string, planId: string, patch: Partial<TripPlanInput>) {
  await updateDoc(doc(db, 'travels', travelId, 'tripPlans', planId), { ...patch, updatedAt: serverTimestamp() });
}

export async function deleteTripPlan(travelId: string, planId: string) {
  await deleteDoc(doc(db, 'travels', travelId, 'tripPlans', planId));
}

// ---------------------------
// Planned Activities (travels/{id}/tripPlans/{id}/plannedActivities)
// ---------------------------
const activitiesCollection = (travelId: string, planId: string) =>
  collection(db, 'travels', travelId, 'tripPlans', planId, 'plannedActivities');

export async function createActivity(travelId: string, planId: string, input: ActivityInput) {
  const ref = await addDoc(activitiesCollection(travelId, planId), {
    ...input,
    currency: input.currency || 'USD',
    is_completed: input.is_completed ?? false,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function listActivities(travelId: string, planId: string) {
  const q = query(activitiesCollection(travelId, planId), orderBy('createdAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function updateActivity(travelId: string, planId: string, activityId: string, patch: Partial<ActivityInput>) {
  await updateDoc(doc(db, 'travels', travelId, 'tripPlans', planId, 'plannedActivities', activityId), {
    ...patch,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteActivity(travelId: string, planId: string, activityId: string) {
  await deleteDoc(doc(db, 'travels', travelId, 'tripPlans', planId, 'plannedActivities', activityId));
}

// ---------------------------
// Shared Access (travels/{id}/sharedAccess)
// ---------------------------
const sharedAccessCollection = (travelId: string) => collection(db, 'travels', travelId, 'sharedAccess');

export async function shareTrip(travelId: string, input: SharedAccessInput) {
  const ref = await addDoc(sharedAccessCollection(travelId), {
    email: input.email,
    access_level: input.access_level || 'view',
    is_active: true,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function listSharedAccesses(travelId: string) {
  const snap = await getDocs(sharedAccessCollection(travelId));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function revokeSharedAccess(travelId: string, accessId: string) {
  await deleteDoc(doc(db, 'travels', travelId, 'sharedAccess', accessId));
}

// ---------------------------
// Destinations (top-level)
// ---------------------------
export async function listDestinations(opts?: { is_featured?: boolean; category?: string }) {
  const constraints: QueryConstraint[] = [];
  if (opts?.is_featured) constraints.push(where('is_featured', '==', true));
  if (opts?.category) constraints.push(where('category', '==', opts.category));
  const q = constraints.length ? query(collection(db, 'destinations'), ...constraints) : collection(db, 'destinations');
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function getDestination(id: string) {
  const snap = await getDoc(doc(db, 'destinations', id));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function createDestination(input: DestinationInput) {
  const ref = await addDoc(collection(db, 'destinations'), {
    ...input,
    is_featured: input.isFeatured ?? false,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function updateDestination(id: string, patch: Partial<DestinationInput>) {
  await updateDoc(doc(db, 'destinations', id), { ...patch, updatedAt: serverTimestamp() });
}

export async function deleteDestination(id: string) {
  await deleteDoc(doc(db, 'destinations', id));
}

// ---------------------------
// Reviews (top-level)
// ---------------------------
export async function addReview(review: ReviewInput) {
  const uid = requireUid();
  const ref = await addDoc(collection(db, 'reviews'), {
    ...review,
    authorUid: uid,
    images: review.images || [],
    helpfulCount: 0,
    isVerified: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function listReviewsForTarget(targetType: 'destination' | 'trip', targetId: string) {
  const q = query(collection(db, 'reviews'), where('targetType', '==', targetType), where('targetId', '==', targetId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// ---------------------------
// Achievements
// ---------------------------
export async function listAchievements() {
  const snap = await getDocs(collection(db, 'achievements'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function upsertUserAchievement(data: AchievementProgress) {
  const uid = requireUid();
  const ref = doc(db, 'users', uid, 'achievements', data.achievementId);
  await setDoc(
    ref,
    {
      achievementId: data.achievementId,
      progress: data.progress,
      isCompleted: data.isCompleted,
      updatedAt: serverTimestamp(),
    },
    { merge: true },
  );
}

// ---------------------------
// Helpers
// ---------------------------
export function travelDoc(travelId: string): DocumentReference {
  return doc(db, 'travels', travelId);
}

export function userDoc(uid: string): DocumentReference {
  return doc(db, 'users', uid);
}

// Legacy exports kept for compatibility with existing imports
export { createTravel as createTrip, updateTravel as updateTrip, deleteTravel as deleteTrip, listMyTravels as listMyTrips };
