/**
 * Firebase Authentication helpers (email/password) for the frontend.
 */

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User,
} from 'firebase/auth';
import { getFirebaseAuth } from '../lib/firebase';
import { createUserProfile } from './firebase-firestore';

const auth = getFirebaseAuth();

export async function signUpWithEmail(data: { email: string; password: string; username: string; fullName: string }) {
  const cred = await createUserWithEmailAndPassword(auth, data.email, data.password);
  await createUserProfile({
    uid: cred.user.uid,
    email: data.email,
    username: data.username,
    fullName: data.fullName,
  });
  return cred.user;
}

export async function signInWithEmail(data: { email: string; password: string }) {
  const cred = await signInWithEmailAndPassword(auth, data.email, data.password);
  return cred.user;
}

export async function signOutUser() {
  await signOut(auth);
}

export function listenToAuthChanges(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}
