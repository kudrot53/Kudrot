import {
    createTripPlan,
    listTripPlansByTravel,
    updateTripPlan as fsUpdateTripPlan,
    deleteTripPlan as fsDeleteTripPlan,
    createActivity as fsCreateActivity,
    listActivities as fsListActivities,
    updateActivity as fsUpdateActivity,
    deleteActivity as fsDeleteActivity,
    shareTrip,
    listSharedAccesses,
    revokeSharedAccess,
} from './firebase-firestore';

// Trip Plan Types
export interface PlannedActivity {
    id: string;
    name: string;
    description?: string;
    cost: number;
    currency: string;
    duration_hours?: number;
    location?: string;
    category?: string;
    booking_reference?: string;
    trip_plan_id: string;
    travel_id?: string;
    is_completed: boolean;
    created_at: string;
}

export interface PlannedActivityCreate {
    name: string;
    description?: string;
    cost: number;
    currency?: string;
    duration_hours?: number;
    location?: string;
    category?: string;
    booking_reference?: string;
}

export interface TripPlan {
    id: string;
    title: string;
    description?: string;
    budget: number;
    remaining_budget: number;
    currency: string;
    preferred_activities: string[];
    is_approved: boolean;
    travel_id: string;
    user_id?: string;
    activities: PlannedActivity[];
    created_at: string;
    updated_at?: string;
}

export interface TripPlanCreate {
    title: string;
    description?: string;
    budget: number;
    remaining_budget?: number;
    currency?: string;
    preferred_activities?: string[];
    travel_id: string;
}

export interface TripPlanClonePayload {
    source_travel_id: number;
    source_trip_plan_id?: number;
    title?: string;
    description?: string;
    budget?: number;
    currency?: string;
    preferred_activities?: string[];
    copy_itinerary?: boolean;
    copy_activities?: boolean;
    start_date?: string;
    end_date?: string;
}

// Trip Sharing Types
export interface SharedTravelAccess {
    id: string;
    email: string;
    access_level: string;
    access_code: string;
    travel_id: string;
    is_active: boolean;
    created_at: string;
}

export interface SharedTravelAccessCreate {
    email: string;
    access_level?: string;
}

export const tripPlanningApi = {
    // Trip Plan endpoints
    createTripPlan: async (plan: TripPlanCreate): Promise<TripPlan> => {
        const id = await createTripPlan(plan.travel_id, {
            title: plan.title,
            description: plan.description,
            budget: plan.budget,
            remaining_budget: plan.remaining_budget,
            currency: plan.currency,
            preferred_activities: plan.preferred_activities,
            travel_id: plan.travel_id,
        });
        return { id, title: plan.title, description: plan.description, budget: plan.budget, remaining_budget: plan.remaining_budget ?? plan.budget, currency: plan.currency || 'USD', preferred_activities: plan.preferred_activities || [], is_approved: false, travel_id: plan.travel_id, activities: [], created_at: new Date().toISOString() };
    },

    cloneTripFromTemplate: async (payload: TripPlanClonePayload): Promise<TripPlan> => {
        // Simplified: create a new plan using provided fields
        const planId = await createTripPlan(String(payload.source_travel_id), {
            title: payload.title || 'Cloned Plan',
            description: payload.description,
            budget: payload.budget ?? 0,
            currency: payload.currency,
            preferred_activities: payload.preferred_activities,
            travel_id: String(payload.source_travel_id),
        });
        return tripPlanningApi.getTripPlan(planId, String(payload.source_travel_id));
    },

    getTripPlansByTravel: async (travelId: string | number): Promise<TripPlan[]> => {
        const list = await listTripPlansByTravel(String(travelId));
        return list.map((p: any) => ({
            id: p.id,
            title: p.title,
            description: p.description,
            budget: p.budget,
            remaining_budget: p.remaining_budget,
            currency: p.currency || 'USD',
            preferred_activities: p.preferred_activities || [],
            is_approved: p.is_approved ?? false,
            travel_id: p.travel_id || String(travelId),
            activities: [],
            created_at: p.createdAt,
            updated_at: p.updatedAt,
        }));
    },

    getTripPlan: async (tripPlanId: string, travelId?: string): Promise<TripPlan> => {
        if (!travelId) throw new Error('travelId is required to load a trip plan');
        const plans = await tripPlanningApi.getTripPlansByTravel(travelId);
        const found = plans.find(p => p.id === tripPlanId);
        if (!found) throw new Error('Trip plan not found');
        return found;
    },

    updateTripPlan: async (
        tripPlanId: string,
        plan: Partial<TripPlanCreate>
    ): Promise<TripPlan> => {
        const travelId = plan.travel_id;
        if (!travelId) {
            throw new Error('travel_id is required to update a trip plan');
        }
        await fsUpdateTripPlan(travelId, tripPlanId, {
            title: plan.title,
            description: plan.description,
            budget: plan.budget ?? 0,
            remaining_budget: plan.remaining_budget,
            currency: plan.currency,
            preferred_activities: plan.preferred_activities,
            travel_id: travelId,
        });
        const list = await listTripPlansByTravel(travelId);
        const updated = list.find((p: any) => p.id === tripPlanId);
        return updated
            ? {
                  id: updated.id,
                  title: updated.title,
                  description: updated.description,
                  budget: updated.budget,
                  remaining_budget: updated.remaining_budget,
                  currency: updated.currency || 'USD',
                  preferred_activities: updated.preferred_activities || [],
                  is_approved: updated.is_approved ?? false,
                  travel_id: updated.travel_id || travelId,
                  activities: [],
                  created_at: updated.createdAt,
                  updated_at: updated.updatedAt,
              }
            : { id: tripPlanId, title: plan.title || '', description: plan.description, budget: plan.budget ?? 0, remaining_budget: plan.remaining_budget ?? 0, currency: plan.currency || 'USD', preferred_activities: plan.preferred_activities || [], is_approved: false, travel_id: travelId, activities: [], created_at: '' };
    },

    deleteTripPlan: async (tripPlanId: string, travelId?: string): Promise<void> => {
        if (!travelId) throw new Error('travelId is required to delete a trip plan');
        await fsDeleteTripPlan(travelId, tripPlanId);
    },

    // Planned Activity endpoints
    createActivity: async (
        travelId: string,
        tripPlanId: string,
        activity: PlannedActivityCreate
    ): Promise<PlannedActivity> => {
        const id = await fsCreateActivity(travelId, tripPlanId, {
            ...activity,
        });
        return {
            id,
            name: activity.name,
            description: activity.description,
            cost: activity.cost,
            currency: activity.currency || 'USD',
            duration_hours: activity.duration_hours,
            location: activity.location,
            category: activity.category,
            booking_reference: activity.booking_reference,
            trip_plan_id: tripPlanId,
            travel_id: travelId,
            is_completed: false,
            created_at: new Date().toISOString(),
        };
    },

    getActivities: async (tripPlanId: string, travelId?: string): Promise<PlannedActivity[]> => {
        if (!travelId) return [];
        const list = await fsListActivities(travelId, tripPlanId);
        return list.map((a: any) => ({
            id: a.id,
            name: a.name,
            description: a.description,
            cost: a.cost,
            currency: a.currency || 'USD',
            duration_hours: a.duration_hours,
            location: a.location,
            category: a.category,
            booking_reference: a.booking_reference,
            trip_plan_id: tripPlanId,
            travel_id: travelId,
            is_completed: a.is_completed ?? false,
            created_at: a.createdAt,
        }));
    },

    updateActivity: async (
        travelId: string,
        planId: string,
        activityId: string,
        activity: Partial<PlannedActivityCreate>
    ): Promise<PlannedActivity> => {
        await fsUpdateActivity(travelId, planId, activityId, activity);
        return {
            id: activityId,
            name: activity.name || '',
            description: activity.description,
            cost: activity.cost || 0,
            currency: activity.currency || 'USD',
            duration_hours: activity.duration_hours,
            location: activity.location,
            category: activity.category,
            booking_reference: activity.booking_reference,
            trip_plan_id: planId,
            travel_id: travelId,
            is_completed: activity.is_completed ?? false,
            created_at: '',
        };
    },

    deleteActivity: async (activityId: string, travelId?: string, planId?: string): Promise<void> => {
        if (!travelId || !planId) throw new Error('travelId and planId are required to delete an activity');
        await fsDeleteActivity(travelId, planId, activityId);
    },

    // Trip Sharing endpoints
    shareTrip: async (
        travelId: string,
        access: SharedTravelAccessCreate
    ): Promise<SharedTravelAccess> => {
        const id = await shareTrip(travelId, access);
        return {
            id,
            email: access.email,
            access_level: access.access_level || 'view',
            access_code: '',
            travel_id: travelId,
            is_active: true,
            created_at: new Date().toISOString(),
        };
    },

    getSharedAccesses: async (travelId: string | number): Promise<SharedTravelAccess[]> => {
        const list = await listSharedAccesses(String(travelId));
        return list.map((a: any) => ({
            id: a.id,
            email: a.email,
            access_level: a.access_level,
            access_code: '',
            travel_id: String(travelId),
            is_active: a.is_active ?? true,
            created_at: a.createdAt,
        }));
    },

    verifyShareAccess: async (
        accessCode: string
    ): Promise<{ travel_id: number; travel_title: string; access_level: string; shared_by: number }> => {
        throw new Error('Share code verification not implemented for Firestore');
    },

    revokeAccess: async (accessId: string, travelId?: string): Promise<void> => {
        if (!travelId) throw new Error('travelId is required to revoke access');
        await revokeSharedAccess(travelId, accessId);
    },

    leaveSharedTrip: async (_travelId: string | number): Promise<void> => {
        // Not implemented
    },
};
