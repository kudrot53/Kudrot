const FUNCTIONS_BASE_URL =
  import.meta.env.VITE_FUNCTIONS_BASE_URL ||
  (import.meta.env.VITE_FIREBASE_PROJECT_ID ? `https://us-central1-${import.meta.env.VITE_FIREBASE_PROJECT_ID}.cloudfunctions.net` : '');

const requireFunctionsBase = () => {
  if (!FUNCTIONS_BASE_URL) {
    throw new Error('Firebase Functions base URL is not configured');
  }
  return FUNCTIONS_BASE_URL;
};

export interface RatesResponse {
  base: string;
  date?: string;
  rates: Record<string, number>;
}

export interface SafetyResponse {
  country: string;
  city?: string | null;
  safety: Record<string, unknown>;
  weather_alerts: Array<Record<string, unknown>>;
}

export interface RecommendationsResponse {
  country: string;
  city?: string | null;
  currency: Record<string, unknown>;
  language: Record<string, unknown>;
  electricity: Record<string, unknown>;
  water: Record<string, unknown>;
  vaccinations: unknown[];
  suggested_activities: string[];
}

export const premiumApi = {
  async getRates(base: string): Promise<RatesResponse> {
    const resp = await fetch(`${requireFunctionsBase()}/getRates?base=${encodeURIComponent(base)}`);
    if (!resp.ok) {
      throw new Error((await resp.text()) || 'Failed to load rates');
    }
    return resp.json();
  },

  async getSafety(country: string, city?: string): Promise<SafetyResponse> {
    const url = new URL(`${requireFunctionsBase()}/getSafety`);
    url.searchParams.set('country', country);
    if (city) url.searchParams.set('city', city);
    const resp = await fetch(url.toString());
    if (!resp.ok) {
      throw new Error((await resp.text()) || 'Failed to load safety info');
    }
    return resp.json();
  },

  async getRecommendations(country: string, city?: string): Promise<RecommendationsResponse> {
    const url = new URL(`${requireFunctionsBase()}/getRecommendations`);
    url.searchParams.set('country', country);
    if (city) url.searchParams.set('city', city);
    const resp = await fetch(url.toString());
    if (!resp.ok) {
      throw new Error((await resp.text()) || 'Failed to load recommendations');
    }
    return resp.json();
  },
};
