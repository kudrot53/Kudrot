import {
  createTravel as fsCreateTravel,
  updateTravel as fsUpdateTravel,
  deleteTravel as fsDeleteTravel,
  listMyTravels,
  listPublicTravels,
  type TravelInput,
} from './firebase-firestore';

export interface Travel {
  id: string;
  title: string;
  description?: string;
  start_date: string;
  end_date: string;
  budget?: number;
  currency: string;
  number_of_travelers: number;
  is_public: boolean;
  image_url?: string;
  notes?: string;
  share_token?: string;
  actual_cost?: number;
  estimated_budget?: number;
  destination_id?: string;
  user_id?: string;
  created_at?: string;
  updated_at?: string;
  status?: string;
  destination?: {
    name?: string;
    city?: string;
    country?: string;
  };
}

export interface TravelCreate {
  title: string;
  description?: string;
  start_date: string;
  end_date: string;
  budget?: number;
  currency?: string;
  number_of_travelers?: number;
  is_public?: boolean;
  image_url?: string;
  notes?: string;
  share_token?: string;
  destination_id?: string;
}

export type TravelUpdate = Partial<TravelCreate>;

const mapTrip = (t: any): Travel => ({
  id: t.id,
  title: t.title,
  description: t.description,
  start_date: t.startDate ?? t.start_date,
  end_date: t.endDate ?? t.end_date,
  budget: t.budget,
  currency: t.currency ?? 'USD',
  number_of_travelers: t.numberOfTravelers ?? t.travelers ?? t.number_of_travelers ?? 1,
  is_public: t.isPublic ?? t.is_public ?? false,
  destination_id: t.destinationId ?? t.destination_id,
  user_id: t.userId ?? t.ownerUid ?? t.user_id,
  image_url: t.imageUrl ?? t.image_url,
  notes: t.notes,
  share_token: t.shareToken ?? t.share_token,
  actual_cost: t.actualCost ?? t.actual_cost,
  estimated_budget: t.estimated_budget ?? t.estimatedBudget,
  created_at: t.createdAt,
  updated_at: t.updatedAt,
  status: t.status,
});

export const travelsApi = {
  async createTravel(payload: TravelCreate): Promise<Travel> {
    const id = await fsCreateTravel({
      title: payload.title,
      description: payload.description,
      startDate: payload.start_date,
      endDate: payload.end_date,
      budget: payload.budget,
      currency: payload.currency,
      numberOfTravelers: payload.number_of_travelers,
      isPublic: payload.is_public,
      destinationId: payload.destination_id,
      imageUrl: payload.image_url,
      notes: payload.notes,
      shareToken: payload.share_token,
    } as TravelInput);
    return {
      id,
      title: payload.title,
      description: payload.description,
      start_date: payload.start_date,
      end_date: payload.end_date,
      budget: payload.budget,
      currency: payload.currency || 'USD',
      number_of_travelers: payload.number_of_travelers ?? 1,
      is_public: payload.is_public ?? false,
      destination_id: payload.destination_id,
      image_url: payload.image_url,
      notes: payload.notes,
      share_token: payload.share_token,
    };
  },

  async getMyTravels(): Promise<Travel[]> {
    const list = await listMyTravels();
    return list.map(mapTrip);
  },

  async getPublicTravels(): Promise<Travel[]> {
    const list = await listPublicTravels();
    return list.map(mapTrip);
  },

  async updateTravel(id: string | number, payload: TravelUpdate): Promise<Travel> {
    const tripId = String(id);
    await fsUpdateTravel(tripId, {
      title: payload.title,
      description: payload.description,
      startDate: payload.start_date,
      endDate: payload.end_date,
      budget: payload.budget,
      currency: payload.currency,
      numberOfTravelers: payload.number_of_travelers,
      isPublic: payload.is_public,
      destinationId: payload.destination_id,
      imageUrl: payload.image_url,
      notes: payload.notes,
      shareToken: payload.share_token,
    });
    const all = await listMyTravels();
    const found = all.find(t => t.id === tripId);
    return found
      ? mapTrip(found)
      : {
          id: tripId,
          title: payload.title || '',
          description: payload.description,
          start_date: payload.start_date || '',
          end_date: payload.end_date || '',
          currency: payload.currency || 'USD',
          number_of_travelers: payload.number_of_travelers ?? 1,
          is_public: payload.is_public ?? false,
          destination_id: payload.destination_id,
          image_url: payload.image_url,
          notes: payload.notes,
          share_token: payload.share_token,
        };
  },

  async deleteTravel(id: string | number): Promise<void> {
    await fsDeleteTravel(String(id));
  },
};
