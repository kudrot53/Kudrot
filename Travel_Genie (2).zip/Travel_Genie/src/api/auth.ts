/**
 * Authentication Service (Firebase)
 * Handles user registration, login, logout, and token management with Firebase Auth.
 */
import { signInWithEmail, signUpWithEmail, signOutUser, listenToAuthChanges } from './firebase-auth';
import { getFirebaseAuth } from '../lib/firebase';
import { FirebaseError } from 'firebase/app';
import { getUserProfile } from './firebase-firestore';

export interface LoginRequest {
  identifier: string; // email
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  full_name: string;
  username: string;
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  data?: {
    user: {
      uid: string;
      email: string | null;
      username: string;
      full_name: string;
      avatar_url?: string | null;
      location?: string | null;
      bio?: string | null;
      is_premium?: boolean;
    };
    token: string;
    expires_in: number;
  };
  error?: string;
}

const TOKEN_KEY = 'access_token';
const USER_KEY = 'user_data';
const TOKEN_TYPE_KEY = 'token_type';

const auth = getFirebaseAuth();

const serializeUser = (user: any, profile?: any) => ({
  uid: user?.uid,
  email: user?.email ?? profile?.email ?? null,
  username: profile?.username || user?.displayName || user?.email || '',
  full_name: profile?.fullName || user?.displayName || '',
  avatar_url: profile?.avatarUrl ?? null,
  location: profile?.location ?? null,
  bio: profile?.bio ?? null,
  is_premium: profile?.isPremium ?? false,
});

const mapFirebaseAuthError = (error: unknown): string => {
  if (error instanceof FirebaseError) {
    switch (error.code) {
      case 'auth/email-already-in-use':
        return 'That email is already registered.';
      case 'auth/weak-password':
        return 'Password is too weak. Please use at least 6 characters.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address.';
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
      case 'auth/user-not-found':
        return 'Invalid email or password.';
      case 'auth/too-many-requests':
        return 'Too many attempts. Please wait and try again.';
      default:
        return error.message || 'Authentication failed';
    }
  }
  return error instanceof Error ? error.message : 'Authentication failed';
};

/**
 * Authentication service for handling user registration, login, and token management
 */
export const authService = {
  /**
   * Register a new user (Firebase)
   */
  async register(data: RegisterRequest): Promise<AuthResponse> {
    try {
      const user = await signUpWithEmail({
        email: data.email,
        password: data.password,
        username: data.username,
        fullName: data.full_name,
      });
      const [token, profile] = await Promise.all([user.getIdToken(), getUserProfile(user.uid)]);
      this.setToken(token);
      const payloadUser = serializeUser(user, profile);
      this.setUser(payloadUser);
      return {
        success: true,
        data: {
          user: payloadUser,
          token,
          expires_in: 0,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapFirebaseAuthError(error),
      };
    }
  },

  /**
   * Login with email and password (Firebase)
   */
  async login(data: LoginRequest): Promise<AuthResponse> {
    try {
      const user = await signInWithEmail({
        email: data.identifier,
        password: data.password,
      });
      const [token, profile] = await Promise.all([user.getIdToken(), getUserProfile(user.uid)]);
      this.setToken(token);
      const payloadUser = serializeUser(user, profile);
      this.setUser(payloadUser);
      return {
        success: true,
        data: {
          user: payloadUser,
          token,
          expires_in: 0,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: mapFirebaseAuthError(error),
      };
    }
  },

  /**
   * Logout - clear stored tokens and user data
   */
  async logout(): Promise<void> {
    await signOutUser();
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(TOKEN_TYPE_KEY);
  },

  /**
   * Get stored authentication token
   */
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  /**
   * Set authentication token
   */
  setToken(token: string): void {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(TOKEN_TYPE_KEY, 'Bearer');
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated(): boolean {
    return !!this.getToken();
  },

  /**
   * Get stored user data
   */
  getUser(): any {
    const user = localStorage.getItem(USER_KEY);
    return user ? JSON.parse(user) : null;
  },

  /**
   * Set user data
   */
  setUser(user: any): void {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },

  /**
   * Verify token validity (checks current firebase user)
   */
  async verifyToken(): Promise<boolean> {
    const current = auth.currentUser;
    return !!current;
  },

  /**
   * Refresh authentication token (Firebase auto refresh; we just fetch a fresh ID token)
   */
  async refreshToken(): Promise<boolean> {
    try {
      const current = auth.currentUser;
      if (!current) return false;
      const token = await current.getIdToken(true);
      this.setToken(token);
      return true;
    } catch (error) {
      console.error('Token refresh error:', error);
      await this.logout();
      return false;
    }
  },

  /**
   * Fetch the currently authenticated user profile (from Firebase)
   */
  async fetchCurrentUser() {
    const current = auth.currentUser;
    if (!current) return null;
    const [token, profile] = await Promise.all([current.getIdToken(), getUserProfile(current.uid)]);
    this.setToken(token);
    const payloadUser = serializeUser(current, profile);
    this.setUser(payloadUser);
    return payloadUser;
  },

  listenToAuthChanges: (cb: (user: any) => void) => {
    return listenToAuthChanges((u) => {
      if (u) {
        getUserProfile(u.uid)
          .then((profile) => cb(serializeUser(u, profile)))
          .catch(() => cb(serializeUser(u)));
      } else {
        cb(null);
      }
    });
  },
};
