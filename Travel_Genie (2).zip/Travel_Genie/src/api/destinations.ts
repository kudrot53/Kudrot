import {
  listDestinations,
  getDestination as fsGetDestination,
  createDestination as fsCreateDestination,
  updateDestination as fsUpdateDestination,
  deleteDestination as fsDeleteDestination,
} from './firebase-firestore';

export interface Destination {
  id: string;
  name: string;
  description?: string;
  city?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
  rating?: number;
  review_count?: number;
  image_url?: string;
  is_featured?: boolean;
  category?: string;
  best_season?: string;
  best_time_to_visit?: string;
  average_cost_per_day?: number;
  created_at?: string;
}

export interface DestinationCreate {
  name: string;
  description?: string;
  city?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
  category?: string;
  best_season?: string;
  best_time_to_visit?: string;
  average_cost_per_day?: number;
  image_url?: string;
}

export const destinationsApi = {
  getDestinations: async (_skip = 0, _limit = 100, is_featured?: boolean, category?: string): Promise<Destination[]> => {
    const list = await listDestinations({ is_featured, category });
    return list.map((d: any) => ({
      id: d.id,
      name: d.name,
      description: d.description,
      city: d.city,
      country: d.country,
      latitude: d.latitude,
      longitude: d.longitude,
      rating: d.rating,
      image_url: d.imageUrl ?? d.image_url,
      is_featured: d.is_featured ?? d.isPopular,
      category: d.category,
      average_cost_per_day: d.averageCostPerDay ?? d.average_cost_per_day,
    }));
  },

  getFeaturedDestinations: async (): Promise<Destination[]> => {
    return destinationsApi.getDestinations(0, 50, true);
  },

  getDestination: async (id: string | number): Promise<Destination> => {
    const dest = await fsGetDestination(String(id));
    if (!dest) throw new Error('Destination not found');
    return {
      id: dest.id,
      name: (dest as any).name,
      description: (dest as any).description,
      city: (dest as any).city,
      country: (dest as any).country,
      image_url: (dest as any).imageUrl ?? (dest as any).image_url,
    };
  },

  createDestination: async (destination: DestinationCreate): Promise<Destination> => {
    const id = await fsCreateDestination({
      name: destination.name,
      city: destination.city,
      country: destination.country,
      description: destination.description,
      imageUrl: destination.image_url,
      category: destination.category,
      averageCostPerDay: destination.average_cost_per_day,
    });
    return { id, name: destination.name };
  },

  updateDestination: async (id: string | number, destination: Partial<DestinationCreate>): Promise<Destination> => {
    await fsUpdateDestination(String(id), {
      name: destination.name ?? '',
      city: destination.city,
      country: destination.country,
      description: destination.description,
      imageUrl: destination.image_url,
      category: destination.category,
      averageCostPerDay: destination.average_cost_per_day,
    });
    return destinationsApi.getDestination(String(id));
  },

  deleteDestination: async (id: string | number): Promise<void> => {
    await fsDeleteDestination(String(id));
  },

  searchDestinations: async (query: string): Promise<Destination[]> => {
    const destinations = await destinationsApi.getDestinations(0, 200);
    return destinations.filter(
      (d: Destination) =>
        d.name.toLowerCase().includes(query.toLowerCase()) ||
        (d.country || '').toLowerCase().includes(query.toLowerCase())
    );
  },

  getByCategory: async (category: string): Promise<Destination[]> => {
    return destinationsApi.getDestinations(0, 100, undefined, category);
  },
};
