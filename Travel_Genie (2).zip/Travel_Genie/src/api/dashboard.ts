import { listMyTravels, listPublicTravels, getUserProfile } from './firebase-firestore';
import { authService } from './auth';

export interface DashboardSummary {
    user: {
        id: string;
        full_name: string;
        username: string;
        is_premium: boolean;
    };
    stats: {
        total_travels: number;
        upcoming_travels: number;
        completed_travels: number;
        total_destinations: number;
        completed_achievements: number;
        active_achievements: number;
        total_budget: number;
    };
    upcoming_trip?: any;
    highlighted_destination?: any;
    recent_trips: any[];
    last_updated: string;
}

export const dashboardApi = {
    getSummary: async (): Promise<DashboardSummary> => {
        const authUser = authService.getUser();
        const profile = await getUserProfile().catch(() => null);
        const trips = await listMyTravels();
        const now = Date.now();
        const upcomingTrips = trips.filter((t: any) => {
            const start = t.startDate || t.start_date;
            return start ? new Date(start).getTime() >= now : false;
        });
        const completedTrips = trips.filter((t: any) => (t.status || '').toLowerCase() === 'completed');
        const totalBudget = trips.reduce((sum, t: any) => sum + (t.budget || 0), 0);
        const uniqueDestinations = new Set(trips.map((t: any) => t.destinationId || t.destination_id).filter(Boolean)).size;

        const user = {
            id: profile?.id || authUser?.uid || '',
            full_name: (profile as any)?.fullName || authUser?.full_name || authUser?.username || '',
            username: (profile as any)?.username || authUser?.username || '',
            is_premium: Boolean((profile as any)?.isPremium),
        };

        const recent = trips
            .slice()
            .sort((a: any, b: any) => new Date(b.createdAt || b.created_at || 0).getTime() - new Date(a.createdAt || a.created_at || 0).getTime())
            .slice(0, 5)
            .map((t: any) => ({
                id: t.id,
                title: t.title,
                start_date: t.startDate || t.start_date,
                end_date: t.endDate || t.end_date,
                status: t.status,
            }));

        return {
            user,
            stats: {
                total_travels: trips.length,
                upcoming_travels: upcomingTrips.length,
                completed_travels: completedTrips.length,
                total_destinations: uniqueDestinations,
                completed_achievements: 0,
                active_achievements: 0,
                total_budget: totalBudget,
            },
            upcoming_trip: upcomingTrips[0]
                ? { id: upcomingTrips[0].id, title: upcomingTrips[0].title, start_date: upcomingTrips[0].startDate || upcomingTrips[0].start_date }
                : undefined,
            highlighted_destination: undefined,
            recent_trips: recent,
            last_updated: new Date().toISOString(),
        };
    },
};
