import * as React from 'react';
import { createRoot } from 'react-dom/client';

import './index.css';
import App from './App';
import { TripPlanProvider } from './store/tripPlanContext';
import { BudgetProvider } from './store/budgetContext';
import { AuthProvider } from './store/authContext';
import { ensureFirebaseConfig } from './lib/firebase';

const rootElement = document.getElementById('root');
const root = createRoot(rootElement!);

try {
  ensureFirebaseConfig();
  root.render(
    <AuthProvider>
      <TripPlanProvider>
        <BudgetProvider>
          <App />
        </BudgetProvider>
      </TripPlanProvider>
    </AuthProvider>,
  );
} catch (error) {
  const message = error instanceof Error ? error.message : 'Missing Firebase configuration';
  root.render(
    <div className="min-h-screen flex items-center justify-center bg-gray-50 text-center px-6">
      <div className="space-y-3 max-w-lg">
        <h1 className="text-2xl font-bold text-red-600">Travel Genie configuration error</h1>
        <p className="text-gray-700">
          {message}. Please set your VITE_FIREBASE_* environment variables in <code>.env.local</code> and restart the app.
        </p>
      </div>
    </div>,
  );
}
