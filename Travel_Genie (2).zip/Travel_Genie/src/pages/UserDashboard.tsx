import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin,
  Calendar,
  Users,
  DollarSign,
  Clock,
  Plane,
  Search,
  Plus,
  Bell,
  Settings,
  User,
  Heart,
  Globe,
  LogOut,
  X,
  AlertCircle,
  ChevronDown,
  Shield,
  CreditCard,
  Check,
  Users as UsersIcon,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { dashboardApi, type DashboardSummary } from '../api/dashboard';
import { destinationsApi, type Destination } from '../api/destinations';
import { travelsApi, type Travel } from '../api/travels';
import { tripPlanningApi } from '../api/trip-planning';
import { premiumApi } from '../api/premium';
import { useAuth } from '../store/authContext';
import { authService } from '../api/auth';
import { updateUserProfile } from '../api/firebase-firestore';

const UserDashboard = () => {
  const navigate = useNavigate();
  const { user, logout, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSettingsMenuOpen, setIsSettingsMenuOpen] = useState(false);
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [profileForm, setProfileForm] = useState({
    full_name: user?.full_name || '',
    username: user?.username || '',
    avatar_url: user?.avatar_url || '',
    location: user?.location || '',
    bio: user?.bio || '',
  });
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [destinationsLoading, setDestinationsLoading] = useState(false);
  const [destinationsError, setDestinationsError] = useState<string | null>(null);
  const [publicTravels, setPublicTravels] = useState<Travel[]>([]);
  const [myTrips, setMyTrips] = useState<Travel[]>([]);
  const [tripsLoading, setTripsLoading] = useState(false);
  const [tripsError, setTripsError] = useState<string | null>(null);
  const [companionsLoading, setCompanionsLoading] = useState(false);
  const [companionsError, setCompanionsError] = useState<string | null>(null);
  const [joining, setJoining] = useState<number | null>(null);
  const settingsMenuRef = useRef<HTMLDivElement | null>(null);
  const premiumLocksEnabled = import.meta.env.VITE_ENABLE_PREMIUM_LOCKS === 'true';
  const premiumActive = !premiumLocksEnabled;
  const [premiumLoading, setPremiumLoading] = useState(false);
  const [premiumError, setPremiumError] = useState<string | null>(null);
  const [premiumRates, setPremiumRates] = useState<any>(null);
  const [premiumSafety, setPremiumSafety] = useState<any>(null);
  const [premiumRecs, setPremiumRecs] = useState<any>(null);
  const [showRealtimeModal, setShowRealtimeModal] = useState(false);
  const fallbackRates = useMemo(
    () => ({
      USD: 1,
      EUR: 0.93,
      GBP: 0.78,
      BDT: 110,
      INR: 83,
      JPY: 150,
      CAD: 1.36,
      AUD: 1.52,
    }),
    [],
  );

  useEffect(() => {
    if (user) {
      setProfileForm((prev) => ({
        ...prev,
        full_name: user.full_name || '',
        username: user.username || prev.username,
        avatar_url: user.avatar_url || '',
        location: user.location || '',
        bio: user.bio || '',
      }));
    }
  }, [user]);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    const loadSummary = async () => {
      try {
        const data = await dashboardApi.getSummary();
        setSummary(data);
      } catch (error) {
        console.error('Failed to load dashboard summary', error);
      }
    };
    loadSummary();
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    if (!premiumActive) return;
    const recent = summary?.recent_trips?.[0];
    const country = (recent as any)?.destination?.country || 'Bangladesh';
    const city = (recent as any)?.destination?.city || undefined;
    const currency =
      (recent as any)?.destination?.currency ||
      (recent as any)?.currency ||
      'USD';
    void loadPremiumData(country, city, currency);
  }, [premiumActive, summary]);

  useEffect(() => {
    if (activeTab !== 'destinations') return;

    const loadDestinations = async () => {
      try {
        setDestinationsLoading(true);
        setDestinationsError(null);
        const data = await destinationsApi.getDestinations(0, 100);
        setDestinations(data);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Failed to load destinations';
        setDestinationsError(message);
      } finally {
        setDestinationsLoading(false);
      }
    };

    loadDestinations();
  }, [activeTab]);

  useEffect(() => {
    if (activeTab !== 'companions') return;

    const loadPublicTravels = async () => {
      try {
        setCompanionsLoading(true);
        setCompanionsError(null);
        const data = await travelsApi.getPublicTravels(0, 100);
        setPublicTravels(data);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Failed to load upcoming trips';
        setCompanionsError(message);
      } finally {
        setCompanionsLoading(false);
      }
    };

    loadPublicTravels();
  }, [activeTab]);

  const loadMyTrips = useCallback(async () => {
    try {
      setTripsLoading(true);
      setTripsError(null);
      const data = await travelsApi.getMyTravels();
      setMyTrips(data);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to load your trips';
      setTripsError(message);
      setMyTrips([]);
    } finally {
      setTripsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (activeTab !== 'trips') return;
    if (tripsLoading) return;
    if (myTrips.length === 0) {
      void loadMyTrips();
    }
  }, [activeTab, myTrips.length, tripsLoading, loadMyTrips]);

  useEffect(() => {
    // Load user's trips early so budget aggregation can normalize currencies on the overview.
    if (myTrips.length === 0 && !tripsLoading) {
      void loadMyTrips();
    }
  }, [loadMyTrips, myTrips.length, tripsLoading]);

  const stats = useMemo(() => {
    if (!summary) {
      return [
        { icon: MapPin, label: 'Destinations', value: '-', color: 'from-blue-500 to-blue-600', change: '' },
        { icon: Calendar, label: 'Trips Planned', value: '-', color: 'from-teal-500 to-teal-600', change: '' },
        { icon: Users, label: 'Travel Companions', value: '-', color: 'from-purple-500 to-purple-600', change: '' },
        { icon: DollarSign, label: 'Total Budget', value: '-', color: 'from-green-500 to-green-600', change: '' },
      ];
    }

    const convertToUsd = (amount: number, currency?: string) => {
      const code = (currency || 'USD').toUpperCase();
      const rate = fallbackRates[code] || 1;
      return rate ? amount / rate : amount;
    };

    const normalizedBudget = myTrips.reduce((sum, trip) => {
      const amount = Number(trip.budget || 0);
      if (!amount || Number.isNaN(amount)) return sum;
      return sum + convertToUsd(amount, trip.currency);
    }, 0);

    const displayBudget = myTrips.length ? normalizedBudget : summary.stats.total_budget;

    return [
      {
        icon: MapPin,
        label: 'Destinations',
        value: summary.stats.total_destinations.toString(),
        color: 'from-blue-500 to-blue-600',
        change: summary.stats.upcoming_travels ? `+${summary.stats.upcoming_travels} upcoming` : '',
      },
      {
        icon: Calendar,
        label: 'Trips Planned',
        value: summary.stats.total_travels.toString(),
        color: 'from-teal-500 to-teal-600',
        change: summary.stats.completed_travels ? `${summary.stats.completed_travels} completed` : '',
      },
      {
        icon: Users,
        label: 'Travel Companions',
        value: summary.stats.active_achievements.toString(),
        color: 'from-purple-500 to-purple-600',
        change: summary.stats.completed_achievements ? `${summary.stats.completed_achievements} achievements` : '',
      },
      {
        icon: DollarSign,
        label: 'Total Budget',
        value: `$${displayBudget.toLocaleString(undefined, { maximumFractionDigits: 2 })}`,
        color: 'from-green-500 to-green-600',
        change: myTrips.length ? 'Converted to USD' : summary.stats.total_budget ? 'Updated' : '',
      },
    ];
  }, [fallbackRates, myTrips, summary]);

  const upcomingTrips = useMemo(() => {
    if (!summary) return [];
    return summary.recent_trips.map((trip) => {
      const start = new Date(trip.start_date);
      const end = new Date(trip.end_date);
      const daysLeft = Math.max(0, Math.ceil((start.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
      return {
        id: trip.id,
        destination: trip.destination?.name || trip.title,
        dates: `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`,
        status: trip.status,
        image: 'plane',
        progress: trip.status === 'completed' ? 100 : trip.status === 'planning' ? 45 : 75,
        daysLeft,
      };
    });
  }, [summary]);

  const recentActivities = [
    { icon: MapPin, text: 'Added new destination', time: 'Just now', color: 'text-blue-600' },
    { icon: Calendar, text: 'Updated itinerary', time: 'Today', color: 'text-teal-600' },
    { icon: Users, text: 'Shared a trip', time: 'This week', color: 'text-purple-600' },
    { icon: Heart, text: 'Saved destinations', time: 'This month', color: 'text-red-600' },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Globe },
    { id: 'trips', label: 'My Trips', icon: Plane },
    { id: 'destinations', label: 'Destinations', icon: MapPin },
    { id: 'companions', label: 'Companions', icon: Users },
  ];

  const displayName = user?.full_name || user?.username || 'Traveler';
  const premiumHighlights = [
    { title: 'Budget Tracking & Optimization', icon: DollarSign, note: 'Real-time spend, deals, alerts' },
    { title: 'Group Trip Coordination', icon: Users, note: 'Shared planning, votes, group chat' },
    { title: '24/7 Travel Safety', icon: Shield, note: 'Emergency support, safety alerts' },
    { title: 'Real-time Updates', icon: Clock, note: 'Flights, weather, disruption alerts' },
  ];
  const realtimeChecklist = [
    'Flight updates (gates, delays, cancellations, baggage, boarding)',
    'Weather alerts (storms, rain, heat/cold waves, cyclone/monsoon)',
    'Event notifications (festivals, closures, traffic, safety, concerts)',
    'Travel disruptions (strikes, roadblocks, bus/train delays, unrest)',
  ];
  const groupCoordChecklist = [
    'Shared planning with live edits on trips and itineraries',
    'Polls and voting for hotels, restaurants, or activities',
    'Group chat tied to each trip (messages, locations, attachments)',
    'Expense splitting with balances per person',
  ];
  const latestTrip = summary?.recent_trips?.[0];
  const realtimeContext = {
    destination: latestTrip?.destination?.name || latestTrip?.title || 'your upcoming trips',
    window: latestTrip
      ? `${new Date(latestTrip.start_date).toLocaleDateString()} - ${new Date(latestTrip.end_date).toLocaleDateString()}`
      : 'next journeys',
  };
  const budgetChecklist = [
    'Real-time expense tracking with auto categories',
    'Deal finder for stays, activities, food, and transport',
    'Currency converter with live rates',
    'Budget alerts for thresholds and unusual spend',
  ];
  const budgetTechPoints = [
    'Expense tables store amount, category, timestamp, trip ID, user ID, and notes',
    'Analytics layer computes totals, averages, remaining budget, and category breakdowns',
    'Deal finder uses external offers APIs tied to trip destination and dates',
    'Currency conversion applies live rates when saving or viewing expenses',
    'Notifications surface budget alerts in-app (and push/email where enabled)',
  ];

  const handleProfileChange = (field: string, value: string) => {
    setProfileForm((prev) => ({ ...prev, [field]: value }));
  };

  const toggleSettingsMenu = () => setIsSettingsMenuOpen((prev) => !prev);

  const closeSettingsMenu = () => setIsSettingsMenuOpen(false);

  useEffect(() => {
    if (!isSettingsMenuOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (settingsMenuRef.current && !settingsMenuRef.current.contains(event.target as Node)) {
        closeSettingsMenu();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeSettingsMenu();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isSettingsMenuOpen]);

  const openProfileSettings = () => {
    setIsSettingsOpen(true);
    closeSettingsMenu();
  };

  const loadPremiumData = async (countryHint?: string, cityHint?: string, currencyHint?: string) => {
    try {
      setPremiumLoading(true);
      setPremiumError(null);

      const country = countryHint || 'Bangladesh';
      const city = cityHint || undefined;
      const currency = (currencyHint || 'USD').toUpperCase();

      const [rates, safety, recs] = await Promise.all([
        premiumApi.getRates(currency),
        premiumApi.getSafety(country, city),
        premiumApi.getRecommendations(country, city),
      ]);

      setPremiumRates(rates);
      setPremiumSafety(safety);
      setPremiumRecs(recs);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load premium data';
      setPremiumError(msg);
    } finally {
      setPremiumLoading(false);
    }
  };

  const goToMyTripsTab = () => {
    setActiveTab('trips');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goToTripPlanning = () => navigateTo('/trip-planning');
  const goToFeatures = () => {
    setActiveTab('destinations');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const goToCompanions = () => {
    setActiveTab('companions');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const saveProfile = async () => {
    try {
      setIsSavingProfile(true);
      setProfileError(null);
      const updatedUser = await updateUserProfile({
        fullName: profileForm.full_name,
        avatarUrl: profileForm.avatar_url || null,
        bio: profileForm.bio || null,
        location: profileForm.location || null,
      });
      if (updatedUser) {
        const merged = {
          uid: user?.uid || updatedUser.id,
          email: (updatedUser as any).email ?? user?.email ?? null,
          username: (updatedUser as any).username ?? user?.username ?? '',
          full_name: (updatedUser as any).fullName ?? profileForm.full_name,
          avatar_url: (updatedUser as any).avatarUrl ?? profileForm.avatar_url,
          location: (updatedUser as any).location ?? profileForm.location,
          bio: (updatedUser as any).bio ?? profileForm.bio,
          is_premium: (updatedUser as any).isPremium ?? user?.is_premium ?? false,
        };
        authService.setUser(merged);
      }
      setProfileForm((prev) => ({
        ...prev,
        full_name: (updatedUser as any)?.fullName || prev.full_name,
        username: (updatedUser as any)?.username || prev.username,
        avatar_url: (updatedUser as any)?.avatarUrl || prev.avatar_url,
      }));
      setIsSettingsOpen(false);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to update profile';
      setProfileError(message);
    } finally {
      setIsSavingProfile(false);
    }
  };

  const filteredDestinations = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return destinations;
    return destinations.filter((d) =>
      [d.name, d.city, d.country].filter(Boolean).some((field) => field!.toLowerCase().includes(query))
    );
  }, [destinations, searchQuery]);

  const filteredTrips = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const sorted = [...myTrips].sort(
      (a, b) => new Date(a.start_date).getTime() - new Date(b.start_date).getTime()
    );
    if (!query) return sorted;
    return sorted.filter((trip) =>
      [
        trip.title,
        trip.description,
        trip.destination?.name,
        trip.destination?.city,
        trip.destination?.country,
      ]
        .filter(Boolean)
        .some((field) => field!.toLowerCase().includes(query))
    );
  }, [myTrips, searchQuery]);

  const navigateTo = (path: string) => {
    navigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Header */}
      <motion.header
        className="bg-white/90 backdrop-blur border-b border-gray-100 sticky top-0 z-40 shadow-sm"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center space-x-6">
              {/* Logo */}
              <Link to="/" className="flex items-center space-x-2">
                <Plane className="w-7 h-7 text-blue-600" />
                <span className="text-xl font-semibold text-gray-900">Travel Genie</span>
              </Link>

              {/* Navigation Tabs */}
              <nav className="hidden md:flex space-x-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-full text-sm transition-all duration-200 ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-700 shadow-inner'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            <div className="flex items-center space-x-3">
              {/* Search */}
              <div className="hidden md:flex items-center space-x-2 bg-gray-100/80 border border-gray-200 rounded-full px-3 py-1.5 shadow-inner">
                <Search className="w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search trips..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent outline-none text-sm w-44 placeholder:text-gray-400"
                />
              </div>

              {/* Minimal actions */}
              <button className="p-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors">
                <Bell className="w-5 h-5" />
              </button>

              <div className="relative" ref={settingsMenuRef}>
                <button
                  onClick={toggleSettingsMenu}
                  className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-full border border-gray-200 bg-white text-gray-800 font-medium shadow-sm hover:shadow transition-all duration-150"
                  aria-label="Open settings"
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-teal-500 text-white">
                    <Settings className="w-4 h-4" />
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${isSettingsMenuOpen ? 'rotate-180' : ''}`}
                  />
                </button>
                <button
                  className="sm:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
                  onClick={openProfileSettings}
                  aria-label="Open settings"
                >
                  <Settings className="w-5 h-5" />
                </button>

                <AnimatePresence>
                  {isSettingsMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-10"
                    >
                      <div className="h-1 bg-gradient-to-r from-blue-500 to-teal-500" />
                      <div className="py-2">
                        <button
                          onClick={openProfileSettings}
                          className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-blue-50 transition-colors"
                        >
                          <div className="mt-0.5 text-blue-600">
                            <User className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">Profile settings</p>
                            <p className="text-xs text-gray-500">Update your name, avatar, and bio.</p>
                          </div>
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('overview');
                            closeSettingsMenu();
                          }}
                          className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-blue-50 transition-colors"
                        >
                          <div className="mt-0.5 text-blue-600">
                            <Shield className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">Account info</p>
                            <p className="text-xs text-gray-500">Security and contact details (coming soon).</p>
                          </div>
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab('overview');
                            closeSettingsMenu();
                          }}
                          className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-blue-50 transition-colors"
                        >
                          <div className="mt-0.5 text-blue-600">
                            <CreditCard className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">Subscriptions</p>
                            <p className="text-xs text-gray-500">Manage billing and perks (coming soon).</p>
                          </div>
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="flex items-center space-x-2 pl-3 border-l border-gray-200">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className="font-medium text-gray-900 hidden sm:inline">{displayName}</span>
              </div>
            </div>
          </div>
        </div>
      </motion.header>

      <main className="container mx-auto px-4 py-8">
        {/* Mobile Tabs */}
        <div className="md:hidden mb-6 overflow-x-auto">
          <div className="flex space-x-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600 bg-white border border-gray-200'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Welcome Section */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {displayName}!</h1>
              <p className="text-gray-600">Your travel adventures await. Here's what's happening with your trips.</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-all duration-300"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  whileHover={{ y: -5 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 bg-gradient-to-br ${stat.color} rounded-lg`}>
                      <stat.icon className="w-6 h-6 text-white" />
                    </div>
                    {stat.change && <span className="text-sm text-green-600 font-medium">{stat.change}</span>}
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </motion.div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Upcoming Trips */}
              <motion.div
                className="lg:col-span-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4, duration: 0.6 }}
              >
                <div className="bg-white rounded-xl border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center justify-between">
                      <h2 className="text-xl font-bold text-gray-900">Upcoming Trips</h2>
                      <button
                        className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                        onClick={goToMyTripsTab}
                      >
                        View All
                      </button>
                    </div>
                  </div>

                  <div className="p-6 space-y-4">
                    {upcomingTrips.length === 0 && (
                      <p className="text-gray-500 text-sm">No trips yet. Plan your first trip!</p>
                    )}
                    {upcomingTrips.map((trip, index) => (
                      <motion.div
                        key={trip.id}
                        className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 + index * 0.1, duration: 0.6 }}
                        whileHover={{ scale: 1.02 }}
                      >
                        <div className="text-4xl">{trip.image}</div>

                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{trip.destination}</h3>
                          <p className="text-sm text-gray-600 mb-2">{trip.dates}</p>

                          <div className="flex items-center space-x-4">
                            <div className="flex-1">
                              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                                <span>Planning Progress</span>
                                <span>{trip.progress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-gradient-to-r from-blue-500 to-teal-500 h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${trip.progress}%` }}
                                />
                              </div>
                            </div>

                            <div className="text-sm text-gray-600">{trip.daysLeft} days left</div>
                          </div>
                        </div>

                        <div
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            trip.status === 'confirmed'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {trip.status}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Recent Activities */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5, duration: 0.6 }}
              >
                <div className="bg-white rounded-xl border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900">Recent Activities</h2>
                  </div>

                  <div className="p-6 space-y-4">
                    {recentActivities.map((activity, index) => (
                      <motion.div
                        key={index}
                        className="flex items-start space-x-3"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 + index * 0.1, duration: 0.6 }}
                      >
                        <activity.icon className={`w-5 h-5 ${activity.color} mt-0.5`} />
                        <div className="flex-1">
                          <p className="text-sm text-gray-900">{activity.text}</p>
                          <p className="text-xs text-gray-500">{activity.time}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Quick Actions */}
                <motion.div
                  className="mt-6 bg-gradient-to-br from-blue-600 to-teal-600 rounded-xl p-6 text-white"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8, duration: 0.6 }}
                >
                  <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <button
                      type="button"
                      className="w-full flex items-center space-x-3 bg-white/20 backdrop-blur-sm rounded-lg p-3 hover:bg-white/30 transition-colors"
                      onClick={goToTripPlanning}
                    >
                      <Plus className="w-5 h-5" />
                      <span className="font-medium">Plan New Trip</span>
                    </button>
                    <button
                      type="button"
                      className="w-full flex items-center space-x-3 bg-white/20 backdrop-blur-sm rounded-lg p-3 hover:bg-white/30 transition-colors"
                      onClick={goToFeatures}
                    >
                      <MapPin className="w-5 h-5" />
                      <span className="font-medium">Explore Destinations</span>
                    </button>
                    <button
                  type="button"
                  className="w-full flex items-center space-x-3 bg-white/20 backdrop-blur-sm rounded-lg p-3 hover:bg-white/30 transition-colors"
                  onClick={goToCompanions}
                >
                  <Users className="w-5 h-5" />
                      <span className="font-medium">Invite Friends</span>
                    </button>
                    <div className="h-px bg-white/20" />
                <button
                  type="button"
                  className="w-full flex items-center space-x-3 bg-white/15 backdrop-blur-sm rounded-lg p-3 hover:bg-white/25 transition-colors"
                  onClick={() => navigateTo('/expense-splitter')}
                >
                  <DollarSign className="w-5 h-5" />
                  <span className="font-medium">Budget tracking & alerts</span>
                </button>
                <button
                  type="button"
                  className="w-full flex items-center space-x-3 bg-white/15 backdrop-blur-sm rounded-lg p-3 hover:bg-white/25 transition-colors"
                  onClick={() => navigateTo('/trip-planning?mode=group')}
                >
                  <UsersIcon className="w-5 h-5" />
                  <span className="font-medium">Group coordination</span>
                </button>
                    <button
                      type="button"
                      className="w-full flex items-center space-x-3 bg-white/15 backdrop-blur-sm rounded-lg p-3 hover:bg-white/25 transition-colors"
                      onClick={() => setShowRealtimeModal(true)}
                    >
                      <Clock className="w-5 h-5" />
                      <span className="font-medium">Real-time updates</span>
                    </button>
                  </div>
                </motion.div>

                {premiumActive && (
                  <motion.div
                    className="mt-4 bg-white rounded-xl border border-blue-100 shadow-sm p-5"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.9, duration: 0.6 }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">Premium toolkit</h3>
                        <p className="text-sm text-gray-600">All premium features are unlocked for you.</p>
                      </div>
                      <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
                        Active
                      </span>
                    </div>
                    <div className="space-y-3">
                      {premiumHighlights.map((item, idx) => {
                        const Icon = item.icon;
                        return (
                          <div
                            key={idx}
                            className="flex items-start gap-3 p-3 rounded-lg border border-gray-100 hover:border-blue-200 hover:bg-blue-50/40 transition-colors cursor-pointer"
                            onClick={goToFeatures}
                          >
                            <div className="w-9 h-9 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center">
                              <Icon className="w-4 h-4" />
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-semibold text-gray-900">{item.title}</p>
                              <p className="text-xs text-gray-600">{item.note}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <button
                      onClick={() => navigateTo('/features')}
                      className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-teal-600 text-white font-medium hover:shadow-lg transition"
                    >
                      <span>Explore all features</span>
                      <ChevronDown className="w-4 h-4 transform rotate-90" />
                    </button>
                  </motion.div>
                )}
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* Destinations tab */}
        {activeTab === 'destinations' && (
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Destinations in Bangladesh</h2>
                <p className="text-gray-600">Explore beaches, hills, islands, and heritage spots we have ready for you.</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search destinations..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
              {destinationsLoading && (
                <div className="text-center py-10 text-gray-500">Loading destinations...</div>
              )}

              {destinationsError && (
                <div className="text-center py-10 text-red-600 flex items-center justify-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  <span>{destinationsError}</span>
                </div>
              )}

              {!destinationsLoading && !destinationsError && filteredDestinations.length === 0 && (
                <div className="text-center py-10 text-gray-500">No destinations found. Try a different search.</div>
              )}

              {!destinationsLoading && !destinationsError && filteredDestinations.length > 0 && (
                <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                  {filteredDestinations.map((destination) => (
                    <div
                      key={destination.id}
                      className="border border-gray-100 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow bg-gradient-to-br from-white to-blue-50/40"
                    >
                      <div className="h-40 bg-gray-100 relative">
                        {destination.image_url ? (
                          <img
                            src={destination.image_url}
                            alt={destination.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-blue-500">
                            <MapPin className="w-10 h-10" />
                          </div>
                        )}
                        <span className="absolute top-3 right-3 bg-white/90 text-xs font-semibold text-blue-600 px-3 py-1 rounded-full">
                          {destination.country || 'Bangladesh'}
                        </span>
                      </div>
                      <div className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{destination.name}</h3>
                            <p className="text-sm text-gray-600">
                              {[destination.city, destination.country].filter(Boolean).join(', ') || 'Bangladesh'}
                            </p>
                          </div>
                          {destination.category && (
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full capitalize">
                              {destination.category}
                            </span>
                          )}
                        </div>
                        {destination.description && (
                          <p className="text-sm text-gray-700 line-clamp-2">{destination.description}</p>
                        )}
                        <div className="flex items-center justify-between text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4 text-blue-500" />
                            {destination.best_time_to_visit || destination.best_season
                              ? `Best: ${destination.best_time_to_visit || destination.best_season}`
                              : 'Any season'}
                          </span>
                          <span className="font-semibold text-blue-600">
                            {destination.average_cost_per_day
                              ? `BDT ${destination.average_cost_per_day}/day`
                              : 'Budget friendly'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Trips Tab */}
        {activeTab === 'trips' && (
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">My Trips</h2>
                <p className="text-gray-600">Trips you&apos;re planning or wish to go.</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => void loadMyTrips()}
                  disabled={tripsLoading}
                  className="px-4 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition disabled:opacity-60"
                >
                  {tripsLoading ? 'Refreshing...' : 'Refresh'}
                </button>
                <button
                  onClick={() => navigate('/trip-planning')}
                  className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
                >
                  Plan a Trip
                </button>
              </div>
            </div>

            {tripsError && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  <span>{tripsError}</span>
                </div>
                <button
                  onClick={() => void loadMyTrips()}
                  className="px-3 py-2 rounded-lg bg-white text-red-700 border border-red-200 hover:bg-red-100 transition"
                >
                  Retry
                </button>
              </div>
            )}

            {tripsLoading && myTrips.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg shadow text-gray-600">
                Loading your trips...
              </div>
            )}

            {!tripsLoading && filteredTrips.length === 0 && !tripsError && (
              <div className="text-center py-16 bg-white rounded-xl shadow">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full mb-4">
                  <Plane className="w-12 h-12 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Plan your next trip</h2>
                <p className="text-gray-600 mb-6">
                  You don&apos;t have any trips yet. Start planning to build your itinerary and budget.
                </p>
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={() => navigate('/trip-planning')}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    Plan a Trip Now
                  </button>
                  <button
                    onClick={() => setActiveTab('destinations')}
                    className="border border-blue-200 text-blue-700 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors"
                  >
                    Browse Destinations
                  </button>
                </div>
              </div>
            )}

            {!tripsLoading && filteredTrips.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTrips.map((trip) => {
                  const start = new Date(trip.start_date);
                  const end = new Date(trip.end_date);
                  const daysLeft = Math.max(0, Math.ceil((start.getTime() - Date.now()) / (1000 * 60 * 60 * 24)));
                  const status = trip.status || 'planning';
                  const budget = trip.budget ?? 0;
                  const destinationLabel =
                    trip.destination?.name ||
                    trip.description ||
                    trip.title ||
                    'Destination pending';

                  return (
                    <div
                      key={trip.id}
                      className="bg-white rounded-xl shadow-md p-5 border border-gray-100 hover:shadow-lg transition flex flex-col gap-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-sm text-blue-600 font-semibold capitalize">{status}</p>
                          <h3 className="text-lg font-bold text-gray-900">{trip.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-1">{destinationLabel}</p>
                        </div>
                        <span className="text-xs px-2 py-1 rounded-full bg-amber-50 text-amber-700">
                          {daysLeft > 0 ? `${daysLeft} days left` : 'In progress'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm text-gray-700">
                        <div>
                          <p className="text-xs text-gray-500">Dates</p>
                          <p className="font-semibold">
                            {start.toLocaleDateString()} - {end.toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Travelers</p>
                          <p className="font-semibold">{trip.number_of_travelers}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Budget</p>
                          <p className="font-semibold">
                            {trip.currency} {budget || '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Access</p>
                          <p className="font-semibold">{trip.is_public ? 'Public' : 'Private'}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 mt-auto">
                        <button
                          onClick={() => navigate('/trip-planning')}
                          className="flex-1 px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition"
                        >
                          Open in Planner
                        </button>
                        <button
                          onClick={goToMyTripsTab}
                          className="px-4 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition"
                        >
                          View All
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const ownerId = trip.user_id !== undefined && trip.user_id !== null ? Number(trip.user_id) : null;
                              const isShared = user && ownerId !== null && ownerId !== Number(user.id);
                              if (isShared) {
                                await tripPlanningApi.leaveSharedTrip(trip.id);
                              } else {
                                await travelsApi.deleteTravel(trip.id);
                              }
                              setMyTrips((prev) => prev.filter((t) => t.id !== trip.id));
                            } catch (err) {
                              const message = err instanceof Error ? err.message : 'Failed to delete trip';
                              setTripsError(message);
                            }
                          }}
                          className="px-4 py-2 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 transition"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        )}

        {/* Companions Tab */}
        {activeTab === 'companions' && (
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Upcoming Trips</h2>
                <p className="text-gray-600">Join a public trip or clone it into your own plan.</p>
              </div>
              <button
                onClick={() => setActiveTab('trips')}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Go to My Trips
              </button>
            </div>

            {companionsLoading && (
              <div className="text-center py-12 bg-white rounded-lg shadow-lg text-gray-600">
                Loading upcoming trips...
              </div>
            )}
            {companionsError && (
              <div className="text-center py-3 bg-red-50 border border-red-200 rounded-lg text-red-700">
                {companionsError}
              </div>
            )}

            {!companionsLoading && !companionsError && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {publicTravels
                  .filter((t) => new Date(t.start_date) >= new Date())
                  .map((trip) => (
                    <div
                      key={trip.id}
                      className="bg-white rounded-xl shadow-md p-5 border border-gray-100 hover:shadow-lg transition"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-sm text-blue-600 font-semibold">Public Trip</p>
                          <h3 className="text-lg font-bold text-gray-900">{trip.title}</h3>
                        </div>
                        <span className="text-xs px-2 py-1 rounded-full bg-green-50 text-green-700">
                          Upcoming
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {trip.description || 'No description provided.'}
                      </p>
                      <div className="grid grid-cols-2 gap-3 text-sm text-gray-700 mb-4">
                        <div>
                          <p className="text-xs text-gray-500">Dates</p>
                          <p className="font-semibold">
                            {new Date(trip.start_date).toLocaleDateString()} -{' '}
                            {new Date(trip.end_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Travelers</p>
                          <p className="font-semibold">{trip.number_of_travelers}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Budget</p>
                          <p className="font-semibold">
                            {trip.currency} {trip.budget ?? '-'}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Owner</p>
                          <p className="font-semibold">User #{trip.user_id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={async () => {
                            setJoining(trip.id);
                            try {
                              await tripPlanningApi.cloneTripFromTemplate({
                                source_travel_id: trip.id,
                                copy_activities: true,
                                copy_itinerary: true,
                              });
                              navigate('/trip-planning');
                            } catch (error) {
                              const message = error instanceof Error ? error.message : 'Unable to join trip';
                              setCompanionsError(message);
                            } finally {
                              setJoining(null);
                            }
                          }}
                          disabled={joining === trip.id}
                          className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition disabled:opacity-60"
                        >
                          {joining === trip.id ? 'Joining...' : 'Tag Along'}
                        </button>
                        <Link
                          to="/trip-planning"
                          className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                        >
                          View planner
                        </Link>
                      </div>
                    </div>
                  ))}
                {publicTravels.filter((t) => new Date(t.start_date) >= new Date()).length === 0 && (
                  <div className="col-span-full text-center py-12 bg-white rounded-lg shadow-lg text-gray-600">
                    No upcoming public trips right now. Check back soon!
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {/* Other Tabs (Placeholder) */}
        {activeTab !== 'overview' && activeTab !== 'destinations' && activeTab !== 'trips' && activeTab !== 'companions' && (
          <motion.div
            className="text-center py-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="text-6xl mb-4">
              {tabs.find((tab) => tab.id === activeTab)?.icon && (
                <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full">
                  {(() => {
                    const Icon = tabs.find((tab) => tab.id === activeTab)?.icon;
                    return Icon ? <Icon className="w-12 h-12 text-blue-600" /> : null;
                  })()}
                </div>
              )}
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {tabs.find((tab) => tab.id === activeTab)?.label}
            </h2>
            <p className="text-gray-600 mb-6">
              This section is coming soon! We're working on amazing features for you.
            </p>
            <button
              onClick={() => setActiveTab('overview')}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Back to Overview
            </button>
          </motion.div>
        )}
      </main>

      <AnimatePresence>
        {showRealtimeModal && (
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm flex items-center justify-center px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full p-6 space-y-6"
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Real-time Updates</h3>
                  <p className="text-sm text-gray-600">
                    How we deliver flight, weather, event, and disruption alerts for your trips.
                  </p>
                </div>
                <button
                  className="p-2 text-gray-500 hover:text-gray-800 rounded-full hover:bg-gray-100"
                  onClick={() => setShowRealtimeModal(false)}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50">
                  <p className="text-xs font-semibold text-blue-700 uppercase tracking-wide mb-2">Step 1 - Data Tracking</p>
                  <p className="text-sm text-gray-800">
                    We poll flight tracking, weather (OpenWeather), local events, and disruption feeds tied to your trip destinations.
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50">
                  <p className="text-xs font-semibold text-blue-700 uppercase tracking-wide mb-2">Step 2 - System Monitoring</p>
                  <p className="text-sm text-gray-800">
                    Collected data is compared with your itinerary: flight numbers, dates, cities, and routes.
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50">
                  <p className="text-xs font-semibold text-blue-700 uppercase tracking-wide mb-2">Step 3 - Triggers</p>
                  <p className="text-sm text-gray-800">
                    Changes like delays, storms, closures, strikes, or safety notices fire notification jobs instantly.
                  </p>
                </div>
                <div className="p-4 rounded-xl border border-gray-100 bg-gray-50">
                  <p className="text-xs font-semibold text-blue-700 uppercase tracking-wide mb-2">Step 4 - Delivery</p>
                  <p className="text-sm text-gray-800">
                    Alerts surface in-app (and push/email where enabled) so you don't have to check multiple apps.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 text-sm text-gray-700">
                <span className="px-3 py-1 rounded-full bg-green-50 text-green-700 border border-green-100">Flight updates</span>
                <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-100">Weather alerts</span>
                <span className="px-3 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-100">Local events</span>
                <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-100">Disruptions</span>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div className="text-sm text-gray-600">
                  Monitoring <span className="font-semibold text-gray-900">{realtimeContext.destination}</span> ({realtimeContext.window}).
                </div>
                <div className="flex gap-3">
                  <button
                    className="px-4 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50"
                    onClick={() => setShowRealtimeModal(false)}
                  >
                    Close
                  </button>
                  <button
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-teal-600 text-white font-medium hover:shadow-lg"
                    onClick={() => {
                      setShowRealtimeModal(false);
                      navigateTo('/trip-planning');
                    }}
                  >
                    Link my trips
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Budget modal removed in favor of direct navigation */}

      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <motion.div
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-6"
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Profile Settings</h3>
                  <p className="text-sm text-gray-500">Update your profile information.</p>
                </div>
                <button
                  className="p-2 text-gray-500 hover:text-gray-800 rounded-full hover:bg-gray-100"
                  onClick={() => setIsSettingsOpen(false)}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <label className="block">
                  <span className="text-sm font-medium text-gray-700">Full name</span>
                  <input
                    type="text"
                    className="mt-2 w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={profileForm.full_name}
                    onChange={(e) => handleProfileChange('full_name', e.target.value)}
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700">Username</span>
                  <input
                    type="text"
                    className="mt-2 w-full border border-gray-200 rounded-lg px-3 py-2 bg-gray-50 cursor-not-allowed"
                    value={profileForm.username}
                    disabled
                  />
                  <p className="text-xs text-gray-500 mt-1">Usernames are managed by support.</p>
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700">Avatar URL</span>
                  <input
                    type="url"
                    className="mt-2 w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={profileForm.avatar_url}
                    onChange={(e) => handleProfileChange('avatar_url', e.target.value)}
                    placeholder="https://example.com/avatar.png"
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700">Location</span>
                  <input
                    type="text"
                    className="mt-2 w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={profileForm.location}
                    onChange={(e) => handleProfileChange('location', e.target.value)}
                    placeholder="City, Country"
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-gray-700">Bio</span>
                  <textarea
                    className="mt-2 w-full border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    value={profileForm.bio}
                    onChange={(e) => handleProfileChange('bio', e.target.value)}
                    placeholder="Tell us about your travel style..."
                  />
                </label>
                {profileError && (
                  <div className="flex items-center space-x-2 text-red-600 text-sm bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                    <AlertCircle className="w-4 h-4" />
                    <span>{profileError}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <button
                  className="text-red-600 hover:text-red-700 flex items-center space-x-2"
                  onClick={() => {
                    logout();
                    setIsSettingsOpen(false);
                    navigate('/login');
                  }}
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
                <div className="flex space-x-3">
                  <button
                    className="px-4 py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50"
                    onClick={() => setIsSettingsOpen(false)}
                    disabled={isSavingProfile}
                  >
                    Cancel
                  </button>
                  <button
                    className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60 flex items-center space-x-2"
                    onClick={saveProfile}
                    disabled={isSavingProfile}
                  >
                    {isSavingProfile && (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    )}
                    <span>Save</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default UserDashboard;
