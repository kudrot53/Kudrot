import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Plane, ChevronLeft, ChevronRight, MapPin, ShieldAlert } from 'lucide-react';
import TripForm from '../components/ui/TripForm';
import ItineraryPreview from '../components/ui/ItineraryPreview';
import { useTripPlan } from '../store/tripPlanContext';
import { useAuth } from '../store/authContext';

const TripPlanningPage = () => {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'plan' | 'itinerary'>('plan');
  const {
    travels,
    currentTravel,
    selectTravel,
    loadInitial,
    loading,
    error,
  } = useTripPlan();
  const [searchParams] = useSearchParams();
  const groupMode = searchParams.get('mode') === 'group';
  const { user } = useAuth();

  const formatRange = (start?: string, end?: string) => {
    if (!start || !end) return '';
    const s = new Date(start).toLocaleDateString();
    const e = new Date(end).toLocaleDateString();
    return `${s} \u2192 ${e}`;
  };

  const [calendarMonth, setCalendarMonth] = useState<Date>(new Date());
  useEffect(() => {
    if (travels.length > 0 && currentTravel) {
      setCalendarMonth(new Date(currentTravel.start_date));
    }
  }, [travels, currentTravel]);

  const startOfMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth(), 1);
  const daysInMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 0).getDate();
  const startWeekday = startOfMonth.getDay(); // 0=Sun

  const bookedDaySet = useMemo(() => {
    const set = new Set<number>();
    travels.forEach((t) => {
      const start = new Date(t.start_date);
      const end = new Date(t.end_date);
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        if (d.getFullYear() === calendarMonth.getFullYear() && d.getMonth() === calendarMonth.getMonth()) {
          set.add(d.getDate());
        }
      }
    });
    return set;
  }, [travels, calendarMonth]);

  const changeMonth = (delta: number) => {
    setCalendarMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  };

  const handleTravelSelect = async (travelId: number) => {
    if (!travelId) return;
    await selectTravel(travelId);
  };

  const ownedTravels = useMemo(
    () => travels.filter((t) => !user || !t.user_id || t.user_id === user.id),
    [travels, user],
  );
  const isReadOnlyShared = currentTravel && user && currentTravel.user_id !== user.id;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex items-center gap-2 hover:bg-white hover:bg-opacity-20 px-3 py-2 rounded-lg transition"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </button>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <Plane className="w-8 h-8" />
            <h1 className="text-4xl font-bold">Trip Planning</h1>
          </div>
          <p className="text-blue-100">Create new trips and build itineraries without leaving this workspace.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {error && !loading && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 flex items-center justify-between gap-4">
            <span>{error}</span>
            <button
              onClick={() => void loadInitial()}
              className="px-4 py-2 rounded-lg bg-white text-red-700 border border-red-200 hover:bg-red-100 transition"
            >
              Retry
            </button>
          </div>
        )}

        {/* Mode switch */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode('plan')}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition ${
                viewMode === 'plan'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              Trip setup
            </button>
            <button
              onClick={() => setViewMode('itinerary')}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition ${
                viewMode === 'itinerary'
                  ? 'bg-blue-600 text-white shadow'
                  : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
              disabled={!currentTravel}
            >
              Itinerary builder
            </button>
          </div>
          {viewMode === 'plan' && (
            <button
              onClick={() => setViewMode('itinerary')}
              disabled={!currentTravel}
              className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition disabled:opacity-60"
            >
              Go to itinerary
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 gap-8">
          {/* Trip planning section */}
          <div className={viewMode === 'plan' ? '' : 'hidden'}>
            {groupMode && (
              <div className="p-4 rounded-lg bg-purple-50 border border-purple-200 text-sm text-purple-800">
                Step 1: pick companions, then create your trip and itinerary in one go.
              </div>
            )}
            <TripForm
              groupMode={groupMode}
              selectedTravel={currentTravel}
              readOnly={!!isReadOnlyShared}
              onUpdated={(id) => {
                if (id) {
                  void handleTravelSelect(id);
                }
              }}
            />

            <div className="p-4 rounded-lg bg-white shadow flex flex-col gap-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm text-gray-500">Itinerary target</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {currentTravel ? currentTravel.title : 'No trip selected'}
                  </p>
                </div>
                {travels.length > 0 && (
                  <select
                    value={currentTravel?.id ?? ''}
                    onChange={(e) => void handleTravelSelect(Number(e.target.value))}
                    className="tg-input w-48 text-sm"
                  >
                    <option value="">Choose trip</option>
                    {travels.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.title}
                      </option>
                    ))}
                  </select>
                )}
              </div>
              <p className="text-sm text-gray-600 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                Manage trips from Dashboard &gt; My Trips. This page stays focused on planning and itineraries.
              </p>
            </div>

            {travels.length > 0 && (
              <div className="p-4 rounded-lg border border-blue-100 bg-blue-50 text-sm text-blue-800 space-y-3 shadow">
                {isReadOnlyShared && (
                  <div className="p-3 rounded-md bg-amber-50 border border-amber-200 text-amber-800 flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-semibold">View-only shared trip</p>
                      <p className="text-xs text-amber-700">
                        You are not the owner of this trip. Switch to one of your own trips to edit or cancel it.
                      </p>
                      {ownedTravels.length > 0 && (
                        <button
                          type="button"
                          className="mt-2 text-sm font-semibold text-blue-700 hover:underline"
                          onClick={() => void handleTravelSelect(ownedTravels[0].id)}
                        >
                          Switch to my trip
                        </button>
                      )}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <p className="font-semibold">Booked dates</p>
                  <div className="flex items-center gap-2 text-blue-700">
                    <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-blue-100 rounded">
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="font-semibold">
                      {calendarMonth.toLocaleString(undefined, { month: 'short', year: 'numeric' })}
                    </span>
                    <button onClick={() => changeMonth(1)} className="p-1 hover:bg-blue-100 rounded">
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-7 text-center text-xs text-blue-700 gap-1">
                  {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                    <span key={d} className="font-semibold">{d}</span>
                  ))}
                  {Array.from({ length: startWeekday }).map((_, idx) => (
                    <span key={`empty-${idx}`} />
                  ))}
                  {Array.from({ length: daysInMonth }).map((_, idx) => {
                    const day = idx + 1;
                    const isBooked = bookedDaySet.has(day);
                    return (
                      <span
                        key={day}
                        className={`py-1 rounded ${
                          isBooked ? 'bg-blue-600 text-white font-semibold' : 'text-blue-800'
                        }`}
                      >
                        {day}
                      </span>
                    );
                  })}
                </div>
                <div className="space-y-1">
                  {travels.map((t) => (
                    <div key={t.id} className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-500" />
                      <span>{t.title}: {formatRange(t.start_date, t.end_date)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Itinerary section */}
          <div className={viewMode === 'itinerary' ? 'space-y-4' : 'hidden'}>
            <div className="tg-card p-5 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-gray-500">Itinerary workspace</p>
                  <h2 className="text-2xl font-bold text-gray-900">Add activities & schedule</h2>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  {travels.length > 0 && (
                    <select
                      value={currentTravel?.id ?? ''}
                      onChange={(e) => void handleTravelSelect(Number(e.target.value))}
                      className="tg-input w-48 text-sm"
                    >
                      <option value="">Switch trip...</option>
                      {travels.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.title}
                        </option>
                      ))}
                    </select>
                  )}
                  {currentTravel && (
                    <div className="text-right">
                      <p className="text-xs uppercase tracking-wide text-gray-500">Active trip</p>
                      <p className="text-sm font-semibold text-gray-800">{currentTravel.title}</p>
                      <p className="text-xs text-gray-500">{formatRange(currentTravel.start_date, currentTravel.end_date)}</p>
                    </div>
                  )}
                </div>
              </div>
              <p className="text-sm text-gray-600">
                Create a trip plan on the left, then add day-by-day activities here. Switch trips using the selector to edit a different itinerary.
              </p>
            </div>

            <ItineraryPreview />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-50 border-t border-gray-200 mt-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-gray-600">
          <p>Tip: Add activities with dates, times, costs, and locations to create a detailed itinerary.</p>
        </div>
      </div>
    </div>
  );
};

export default TripPlanningPage;
