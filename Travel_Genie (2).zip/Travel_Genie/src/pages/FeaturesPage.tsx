import { useState } from 'react';
import { motion } from 'framer-motion';
import {
    Map,
    Calendar,
    DollarSign,
    Users,
    Camera,
    Shield,
    Clock,
    Star,
    Globe,
    Heart,
    TrendingUp,
    Award,
    Zap,
    Search,
    Filter,
    ArrowRight,
    Check,
    ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

const FeaturesPage = () => {
    const [selectedCategory, setSelectedCategory] = useState('all');

    // Feature flag: when false (default), everyone sees premium features unlocked.
    // Set VITE_ENABLE_PREMIUM_LOCKS=true in your env to re-enable premium gating.
    const premiumLocksEnabled = import.meta.env.VITE_ENABLE_PREMIUM_LOCKS === 'true';

    const categories = [
        { id: 'all', name: 'All Features', icon: Globe },
        { id: 'planning', name: 'Planning Tools', icon: Calendar },
        { id: 'discovery', name: 'Discovery', icon: Map },
        { id: 'social', name: 'Social', icon: Users },
        { id: 'management', name: 'Management', icon: DollarSign }
    ];

    const features = [
        {
            id: 1,
            title: 'AI-Powered Itinerary Planning',
            description: 'Get personalized day-by-day itineraries based on your preferences, travel style, and interests using advanced AI algorithms.',
            icon: Calendar,
            category: 'planning',
            color: 'from-blue-500 to-blue-600',
            features: ['Smart scheduling', 'Weather integration', 'Activity optimization', 'Time management'],
            premium: false
        },
        {
            id: 2,
            title: 'Destination Discovery Engine',
            description: 'Explore thousands of destinations with detailed insights, hidden gems, and local recommendations tailored to your interests.',
            icon: Map,
            category: 'discovery',
            color: 'from-teal-500 to-teal-600',
            features: ['AI recommendations', 'Local insights', 'Seasonal guides', 'Travel alerts'],
            premium: false
        },
        {
            id: 3,
            title: 'Budget Tracking & Optimization',
            description: 'Track expenses in real-time, find the best deals, and optimize your travel budget with smart spending recommendations.',
            icon: DollarSign,
            category: 'management',
            color: 'from-green-500 to-green-600',
            features: ['Real-time tracking', 'Deal finder', 'Currency converter', 'Budget alerts'],
            premium: true
        },
        {
            id: 4,
            title: 'Group Trip Coordination',
            description: 'Plan trips with friends and family, collaborate on itineraries, vote on activities, and share expenses seamlessly.',
            icon: Users,
            category: 'social',
            color: 'from-purple-500 to-purple-600',
            features: ['Shared planning', 'Voting system', 'Group chat', 'Expense splitting'],
            premium: true
        },
        {
            id: 5,
            title: 'Travel Journal & Memories',
            description: 'Document your journey with photo journals, location tagging, and create beautiful travel stories to share with loved ones.',
            icon: Camera,
            category: 'social',
            color: 'from-pink-500 to-pink-600',
            features: ['Photo journal', 'Location tagging', 'Story creation', 'Social sharing'],
            premium: false
        },
        {
            id: 6,
            title: '24/7 Travel Safety',
            description: 'Stay safe with emergency support, travel insurance, real-time safety alerts, and medical assistance wherever you go.',
            icon: Shield,
            category: 'management',
            color: 'from-red-500 to-red-600',
            features: ['Emergency support', 'Travel insurance', 'Safety alerts', 'Medical locator'],
            premium: true
        },
        {
            id: 7,
            title: 'Smart Recommendations',
            description: 'Get personalized recommendations for restaurants, attractions, and activities based on your preferences and travel history.',
            icon: Star,
            category: 'discovery',
            color: 'from-yellow-500 to-yellow-600',
            features: ['Personalized suggestions', 'Reviews integration', 'Rating system', 'Preference learning'],
            premium: false
        },
        {
            id: 8,
            title: 'Real-time Updates',
            description: 'Receive instant updates about flight changes, weather alerts, local events, and travel disruptions affecting your trip.',
            icon: Clock,
            category: 'management',
            color: 'from-indigo-500 to-indigo-600',
            features: ['Flight updates', 'Weather alerts', 'Event notifications', 'Disruption alerts'],
            premium: true
        }
    ];

    const filteredFeatures = selectedCategory === 'all'
        ? features
        : features.filter(feature => feature.category === selectedCategory);

    const stats = [
        { number: '50+', label: 'Premium Features', icon: Award },
        { number: '1M+', label: 'Active Users', icon: Users },
        { number: '150+', label: 'Countries Covered', icon: Globe },
        { number: '24/7', label: 'Support Available', icon: Clock }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
            {/* Header */}
            <motion.header
                className="bg-white border-b border-gray-200 sticky top-0 z-40"
                initial={{ y: -100 }}
                animate={{ y: 0 }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4">
                    <div className="flex items-center justify-between h-16">
                        <Link to="/" className="flex items-center space-x-2">
                            <Calendar className="w-8 h-8 text-blue-600" />
                            <span className="text-2xl font-bold text-gray-900">Travel Genie</span>
                        </Link>

                        <nav className="hidden md:flex items-center space-x-8">
                            <Link to="/" className="text-gray-600 hover:text-gray-900 transition-colors">Home</Link>
                            <Link to="/features" className="text-blue-600 font-medium">Features</Link>
                            <Link to="/login" className="bg-blue-600 text-white px-6 py-2 rounded-full font-medium hover:bg-blue-700 transition-colors">
                                Get Started
                            </Link>
                        </nav>

                        <Link to="/" className="text-gray-600 hover:text-gray-900">
                            <ChevronRight className="w-5 h-5 rotate-180" />
                        </Link>
                    </div>
                </div>
            </motion.header>

            {/* Hero Section */}
            <section className="py-20 px-4">
                <div className="container mx-auto">
                    <motion.div
                        className="text-center max-w-4xl mx-auto"
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                    >
                        <motion.div
                            className="inline-flex items-center space-x-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6"
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2, duration: 0.6 }}
                        >
                            <Zap className="w-4 h-4" />
                            <span className="text-sm font-medium">Powerful Features</span>
                        </motion.div>

                        <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                            Everything You Need for
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-teal-600 block">
                                Perfect Travel
                            </span>
                        </h1>

                        <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                            Discover our comprehensive suite of travel planning tools designed to make every journey
                            unforgettable, from inspiration to execution.
                        </p>
                    </motion.div>

                    {/* Stats */}
                    <motion.div
                        className="grid grid-cols-2 lg:grid-cols-4 gap-8 mt-16"
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3, duration: 0.8 }}
                    >
                        {stats.map((stat, index) => (
                            <motion.div
                                key={index}
                                className="text-center"
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.4 + index * 0.1, duration: 0.6 }}
                                whileHover={{ y: -10 }}
                            >
                                <motion.div
                                    className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-100 to-teal-100 rounded-full mb-4 mx-auto"
                                    whileHover={{ scale: 1.1, rotate: 360 }}
                                    transition={{ duration: 0.6 }}
                                >
                                    <stat.icon className="w-8 h-8 text-blue-600" />
                                </motion.div>

                                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                                <div className="text-gray-600 font-medium">{stat.label}</div>
                            </motion.div>
                        ))}
                    </motion.div>
                </div>
            </section>

            {/* Category Filter */}
            <section className="py-8 px-4 bg-white border-y border-gray-200">
                <div className="container mx-auto">
                    <div className="flex flex-wrap justify-center gap-4">
                        {categories.map((category) => (
                            <motion.button
                                key={category.id}
                                onClick={() => setSelectedCategory(category.id)}
                                className={`flex items-center space-x-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${selectedCategory === category.id
                                        ? 'bg-gradient-to-r from-blue-600 to-teal-600 text-white shadow-lg'
                                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    }`}
                                initial={{ opacity: 0, scale: 0.8 }}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                <category.icon className="w-4 h-4" />
                                <span>{category.name}</span>
                            </motion.button>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features Grid */}
            <section className="py-16 px-4">
                <div className="container mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredFeatures.map((feature, index) => (
                            <motion.div
                                key={feature.id}
                                className="group relative"
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1, duration: 0.6 }}
                            >
                                <motion.div
                                    className="bg-white rounded-2xl p-8 h-full border border-gray-100 hover:shadow-2xl transition-all duration-300 relative overflow-hidden"
                                    whileHover={{ y: -10 }}
                                >
                                    {/* Premium Badge (hidden when locks are disabled) */}
                                    {feature.premium && premiumLocksEnabled && (
                                        <div className="absolute top-4 right-4 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                                            PREMIUM
                                        </div>
                                    )}

                                    {/* Background Gradient */}
                                    <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />

                                    {/* Icon */}
                                    <motion.div
                                        className={`inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br ${feature.color} rounded-full mb-6`}
                                        whileHover={{ scale: 1.1, rotate: 360 }}
                                        transition={{ duration: 0.6 }}
                                    >
                                        <feature.icon className="w-8 h-8 text-white" />
                                    </motion.div>

                                    {/* Content */}
                                    <h3 className="text-2xl font-bold text-gray-900 mb-4">{feature.title}</h3>
                                    <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>

                                    {/* Features List */}
                                    <ul className="space-y-2 mb-6">
                                        {feature.features.map((item, itemIndex) => (
                                            <motion.li
                                                key={itemIndex}
                                                className="flex items-center space-x-2 text-sm text-gray-600"
                                                initial={{ opacity: 0, x: -10 }}
                                                animate={{ opacity: 1, x: 0 }}
                                                transition={{ delay: 0.5 + index * 0.1 + itemIndex * 0.05, duration: 0.4 }}
                                            >
                                                <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                                                <span>{item}</span>
                                            </motion.li>
                                        ))}
                                    </ul>

                                    {/* CTA Button */}
                                    <motion.button
                                        className={`w-full py-3 rounded-lg font-medium transition-all duration-300 ${
                                            feature.premium && premiumLocksEnabled
                                                ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-white hover:from-yellow-500 hover:to-yellow-600'
                                                : 'bg-gradient-to-r from-blue-600 to-teal-600 text-white shadow-md hover:shadow-lg'
                                        }`}
                                        whileHover={{ scale: 1.02 }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                        {feature.premium && premiumLocksEnabled ? 'Upgrade to Premium' : 'Start Using'}
                                    </motion.button>

                                    {!premiumLocksEnabled && feature.premium && (
                                        <div className="mt-3 inline-flex items-center rounded-full bg-blue-50 text-blue-700 text-xs font-semibold px-3 py-1">
                                            Included for all travelers
                                        </div>
                                    )}
                                </motion.div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-teal-600">
                <div className="container mx-auto text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        viewport={{ once: true }}
                    >
                        <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
                            Ready to Transform Your Travel Experience?
                        </h2>
                        <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                            Join millions of travelers who are already using Travel Genie to create unforgettable journeys.
                        </p>

                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <motion.button
                                onClick={() => window.location.href = '/login'}
                                className="bg-white text-blue-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors shadow-xl"
                                whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(0,0,0,0.2)' }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Start Free Trial
                            </motion.button>

                            <motion.button
                                onClick={() => window.location.href = '/'}
                                className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition-all duration-300"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                View Demo
                            </motion.button>
                        </div>
                    </motion.div>
                </div>
            </section>
        </div>
    );
};

export default FeaturesPage;
