import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, DollarSign, Users, Sparkles, Wallet2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { travelsApi, type Travel } from '../api/travels';
import { tripPlanningApi } from '../api/trip-planning';
import { useAuth } from '../store/authContext';
import { listItineraryItems, addItineraryItem } from '../api/firebase-firestore';

interface Participant {
  id: string;
  name: string;
  color: string;
}

interface ExpenseItem {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitAmong: string[];
  date: string;
}

interface Settlement {
  from: string;
  to: string;
  amount: number;
}

type PlannedTrip = {
  id: string;
  name: string;
  dateRange: string;
  budget?: number;
  people: string[];
  currency?: string;
  travel?: Travel;
};

const COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F'];

const ExpenseSplitterPage = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();

  const [tripMode, setTripMode] = useState<'solo' | 'group'>('group');
  const [baseBudget, setBaseBudget] = useState<string>('');
  const [selectedTripId, setSelectedTripId] = useState<string>('');
  const [plannedTrips, setPlannedTrips] = useState<PlannedTrip[]>([]);
  const plannedTripsRef = useRef<PlannedTrip[]>([]);
  const [tripError, setTripError] = useState<string | null>(null);
  const [loadingTrips, setLoadingTrips] = useState(false);
  const [participantHints, setParticipantHints] = useState<string[]>([]);
  const [savingItinerary, setSavingItinerary] = useState(false);
  const [itineraryItems, setItineraryItems] = useState<any[]>([]);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [expenses, setExpenses] = useState<ExpenseItem[]>([]);
  const [expenseError, setExpenseError] = useState<string | null>(null);
  const [newParticipantName, setNewParticipantName] = useState('');
  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: '',
    paidBy: 'init-1',
    date: new Date().toISOString().split('T')[0],
  });
  const selfName = useMemo(
    () => user?.full_name || user?.username || user?.email || 'You',
    [user?.email, user?.full_name, user?.username],
  );

  const calculateBalances = () => {
    const balances: Record<string, number> = {};
    participants.forEach(p => (balances[p.id] = 0));

    expenses.forEach(expense => {
      const splitCount = expense.splitAmong.length || 1;
      const amountPerPerson = expense.amount / splitCount;

      balances[expense.paidBy] = (balances[expense.paidBy] || 0) + expense.amount;

      expense.splitAmong.forEach(participantId => {
        balances[participantId] = (balances[participantId] || 0) - amountPerPerson;
      });
    });

    return balances;
  };

  const calculateSettlements = (balances: Record<string, number>): Settlement[] => {
    const debtors = Object.entries(balances)
      .filter(([_, balance]) => balance < 0)
      .map(([id, balance]) => ({ id, amount: Math.abs(balance) }));

    const creditors = Object.entries(balances)
      .filter(([_, balance]) => balance > 0)
      .map(([id, balance]) => ({ id, amount: balance }));

    const settlements: Settlement[] = [];
    let debtorIndex = 0;
    let creditorIndex = 0;

    while (debtorIndex < debtors.length && creditorIndex < creditors.length) {
      const debtor = debtors[debtorIndex];
      const creditor = creditors[creditorIndex];
      const settleAmount = Math.min(debtor.amount, creditor.amount);

      settlements.push({
        from: debtor.id,
        to: creditor.id,
        amount: Math.round(settleAmount * 100) / 100,
      });

      debtor.amount -= settleAmount;
      creditor.amount -= settleAmount;

      if (debtor.amount === 0) debtorIndex++;
      if (creditor.amount === 0) creditorIndex++;
    }

    return settlements;
  };

  const balances = useMemo(() => calculateBalances(), [expenses, participants]);
  const settlements = useMemo(() => calculateSettlements(balances), [balances]);

  const mapTravelToPlannedTrip = useCallback(
    (travel: Travel): PlannedTrip => ({
      id: String(travel.id),
      name: travel.title ?? travel.destination?.name ?? 'Trip',
      dateRange:
        travel.start_date && travel.end_date ? `${travel.start_date} to ${travel.end_date}` : 'Dates TBD',
      budget: travel.budget ?? travel.actual_cost ?? undefined,
      people: [],
      currency: travel.currency ?? 'USD',
      travel,
    }),
    [],
  );

  const hydrateParticipantsForTrip = useCallback(
    async (trip: PlannedTrip): Promise<Participant[]> => {
      const travelId = Number(trip.travel?.id ?? trip.id);
      const seen = new Set<string>();
      const hydrated: Participant[] = [];

      const addParticipantSafe = (name: string, id: string) => {
        const key = name.trim().toLowerCase();
        if (!key || seen.has(key)) return;
        hydrated.push({
          id,
          name,
          color: COLORS[hydrated.length % COLORS.length],
        });
        seen.add(key);
      };

      addParticipantSafe(selfName, `owner-${travelId || Date.now()}`);
      trip.people.forEach((person, idx) => addParticipantSafe(person, `${trip.id}-person-${idx}`));

      if (travelId && tripPlanningApi.getSharedAccesses) {
        try {
          const sharedAccesses = await tripPlanningApi.getSharedAccesses(travelId);
          const sharedNames = sharedAccesses.map(access => access.email?.split('@')[0] || access.email || 'Guest');
          sharedAccesses.forEach((access, idx) => {
            const label = sharedNames[idx];
            addParticipantSafe(label, `shared-${access.id}`);
          });
          setParticipantHints(sharedNames);
        } catch (error) {
          console.warn('Failed to load shared participants for travel', travelId, error);
          setParticipantHints([]);
        }
      } else {
        setParticipantHints([]);
      }

      const expectedCount = trip.travel?.number_of_travelers;
      if (expectedCount && expectedCount > hydrated.length) {
        for (let idx = hydrated.length; idx < expectedCount && hydrated.length < 6; idx += 1) {
          addParticipantSafe(`Traveler ${idx + 1}`, `${trip.id}-placeholder-${idx}`);
        }
      }

      if (hydrated.length === 0) {
        addParticipantSafe(selfName, `fallback-${trip.id}`);
      }

      return hydrated.slice(0, 6);
    },
    [selfName],
  );

  const loadItineraryItems = useCallback(async (travelId?: string) => {
    if (!travelId) {
      setItineraryItems([]);
      return;
    }
    try {
      const items = await listItineraryItems(travelId);
      setItineraryItems(Array.isArray(items) ? items : []);
    } catch (error) {
      console.warn('Failed to load itinerary items for trip', travelId, error);
      setItineraryItems([]);
    }
  }, []);

  const loadTrip = useCallback(
    async (tripId: string, sourceList?: PlannedTrip[]) => {
      const list = sourceList && sourceList.length ? sourceList : plannedTripsRef.current;
      const trip = list.find(t => t.id === tripId);
      if (!trip) return;

      setSelectedTripId(tripId);

      const hydratedParticipants = await hydrateParticipantsForTrip(trip);
      const isSolo = hydratedParticipants.length <= 1;
      setTripMode(isSolo ? 'solo' : 'group');
      setParticipants(hydratedParticipants);

      const budgetValue =
        trip.budget ??
        trip.travel?.budget ??
        trip.travel?.actual_cost ??
        (trip.travel as any)?.estimated_budget ??
        '';
      setBaseBudget(budgetValue ? String(budgetValue) : '');
      setExpenses([]);
      setNewExpense(prev => ({
        ...prev,
        paidBy: hydratedParticipants[0]?.id || '',
      }));

      const travelId = String(trip.travel?.id ?? trip.id);
      await loadItineraryItems(travelId);
    },
    [hydrateParticipantsForTrip, loadItineraryItems],
  );

  useEffect(() => {
    const fallbackParticipant = { id: 'init-1', name: selfName, color: COLORS[0] };
    setParticipants([fallbackParticipant]);
    setNewExpense(prev => ({ ...prev, paidBy: fallbackParticipant.id }));
  }, [selfName]);

  // Load trips from API
  useEffect(() => {
    if (authLoading) return;

    const bootstrap = async () => {
      if (!isAuthenticated) {
        setTripError('Please log in to see your trips.');
        setPlannedTrips([]);
        plannedTripsRef.current = [];
        setSelectedTripId('');
        setExpenses([]);
        setItineraryItems([]);
        const fallbackParticipant = { id: 'init-1', name: selfName, color: COLORS[0] };
        setParticipants([fallbackParticipant]);
        setNewExpense(prev => ({ ...prev, paidBy: fallbackParticipant.id }));
        return;
      }

      try {
        setLoadingTrips(true);
        setTripError(null);
        const trips = await travelsApi.getMyTravels();
        if (Array.isArray(trips) && trips.length) {
          const mapped = trips.map(mapTravelToPlannedTrip);
          plannedTripsRef.current = mapped;
          setPlannedTrips(mapped);
          const firstId = mapped[0]?.id;
          if (firstId) {
            await loadTrip(firstId, mapped);
          }
          return;
        }
        setTripError('No trips found. Create a trip to start splitting expenses.');
        plannedTripsRef.current = [];
        setPlannedTrips([]);
        setSelectedTripId('');
        const fallbackParticipant = { id: 'init-1', name: selfName, color: COLORS[0] };
        setParticipants([fallbackParticipant]);
        setNewExpense(prev => ({ ...prev, paidBy: fallbackParticipant.id }));
        setExpenses([]);
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Failed to load your trips';
        setTripError(message);
        plannedTripsRef.current = [];
        setPlannedTrips([]);
        setSelectedTripId('');
        setItineraryItems([]);
        const fallbackParticipant = { id: 'init-1', name: selfName, color: COLORS[0] };
        setParticipants([fallbackParticipant]);
        setNewExpense(prev => ({ ...prev, paidBy: fallbackParticipant.id }));
        setExpenses([]);
      } finally {
        setLoadingTrips(false);
      }
    };

    void bootstrap();
  }, [authLoading, isAuthenticated, loadTrip, mapTravelToPlannedTrip, selfName]);

  const switchMode = (mode: 'solo' | 'group') => {
    if (mode === tripMode) return;

    if (mode === 'solo') {
      const soloParticipant: Participant = { id: 'solo', name: selfName, color: COLORS[0] };
      setTripMode('solo');
      setParticipants([soloParticipant]);
      setExpenses(
        expenses.map(exp => ({
          ...exp,
          paidBy: soloParticipant.id,
          splitAmong: [soloParticipant.id],
        }))
      );
      setNewExpense(prev => ({
        ...prev,
        paidBy: soloParticipant.id,
      }));
    } else {
      setTripMode('group');
      if (participants.length === 0) {
        setParticipants([{ id: '1', name: selfName, color: COLORS[0] }]);
        setNewExpense(prev => ({ ...prev, paidBy: '1' }));
      }
    }
  };

  const addParticipant = () => {
    if (tripMode === 'solo') return;
    const nextName = newParticipantName.trim();
    if (!nextName || participants.length >= 6) return;
    const duplicate = participants.some(p => p.name.toLowerCase() === nextName.toLowerCase());
    if (duplicate) {
      setNewParticipantName('');
      return;
    }
    if (nextName && participants.length < 6) {
      const newParticipant: Participant = {
        id: Date.now().toString(),
        name: nextName,
        color: COLORS[participants.length % COLORS.length],
      };
      setParticipants([...participants, newParticipant]);
      setNewParticipantName('');
    }
  };

  const removeParticipant = (id: string) => {
    const filteredParticipants = participants.filter(p => p.id !== id);
    setParticipants(filteredParticipants);
    setExpenses(expenses.filter(e => e.paidBy !== id && !e.splitAmong.includes(id)));
    if (newExpense.paidBy === id) {
      setNewExpense(prev => ({
        ...prev,
        paidBy: filteredParticipants[0]?.id || '',
      }));
    }
  };

  const createItineraryEntryFromExpense = useCallback(
    async (expensePayload: { description: string; amount: number; date: string }) => {
      const travelId = selectedTripId;
      if (!travelId) return;
      try {
        setSavingItinerary(true);
        const createdId = await addItineraryItem(travelId, {
          title: expensePayload.description,
          date: expensePayload.date,
          itemType: 'activity',
          cost: expensePayload.amount,
          notes: 'Added from Expense Splitter',
        });
        if (createdId) {
          setItineraryItems(prev => [{ id: createdId, title: expensePayload.description, date: expensePayload.date }, ...prev]);
        }
      } catch (error) {
        console.warn('Failed to create itinerary item from expense', error);
      } finally {
        setSavingItinerary(false);
      }
    },
    [selectedTripId],
  );

  const addExpense = async () => {
    if (!newExpense.description || !newExpense.amount || !newExpense.paidBy) {
      setExpenseError('Please provide a description, amount, and payer.');
      return;
    }
    if (!participants.length) {
      setExpenseError('Add at least one participant before adding expenses.');
      return;
    }

    setExpenseError(null);
    const splitAmong =
      tripMode === 'solo' && participants.length > 0 ? [participants[0].id] : participants.map(p => p.id);

    const expense: ExpenseItem = {
      id: Date.now().toString(),
      description: newExpense.description,
      amount: parseFloat(newExpense.amount),
      paidBy: newExpense.paidBy,
      splitAmong,
      date: newExpense.date,
    };

    setExpenses(prev => [...prev, expense]);

    if (itineraryItems.length === 0 && newExpense.description.trim()) {
      await createItineraryEntryFromExpense({
        description: newExpense.description,
        amount: parseFloat(newExpense.amount),
        date: newExpense.date,
      });
    }

    setNewExpense({
      description: '',
      amount: '',
      paidBy: participants[0]?.id || '',
      date: new Date().toISOString().split('T')[0],
    });
  };

  const removeExpense = (id: string) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  const toggleParticipantInExpense = (expenseId: string, participantId: string) => {
    setExpenses(
      expenses.map(e => {
        if (e.id === expenseId) {
          if (e.splitAmong.includes(participantId)) {
            return { ...e, splitAmong: e.splitAmong.filter(id => id !== participantId) };
          }
          return { ...e, splitAmong: [...e.splitAmong, participantId] };
        }
        return e;
      })
    );
  };

  const getParticipantName = (id: string) => participants.find(p => p.id === id)?.name || 'Unknown';
  const getParticipantColor = (id: string) => participants.find(p => p.id === id)?.color || '#ccc';

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const parsedBudget = parseFloat(baseBudget) || 0;
  const budgetLeft = parsedBudget > 0 ? parsedBudget - totalExpenses : 0;
  const selectedTrip = plannedTrips.find(t => t.id === selectedTripId);
  const currencyCode = selectedTrip?.currency || 'USD';
  const currencySymbolMap: Record<string, string> = {
    USD: '$',
    EUR: 'EUR',
    GBP: 'GBP',
    BDT: 'BDT',
    INR: 'INR',
    CAD: 'C$',
    AUD: 'A$',
  };
  const currencySymbol = currencySymbolMap[currencyCode] || '$';

  const suggestionPool = participantHints.length ? participantHints : selectedTrip?.people || [];
  const companionSuggestions = suggestionPool.filter(
    p => !participants.some(part => part.name.toLowerCase() === p.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 text-white shadow-lg rounded-b-3xl">
        <div className="max-w-5xl px-4 mx-auto py-6 flex flex-col gap-3">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-sm font-semibold text-white/90 hover:text-white transition w-fit"
          >
            {'< Back to Dashboard'}
          </button>
          <div className="text-left">
            <h1 className="text-3xl md:text-4xl font-extrabold leading-tight">Expense Splitter</h1>
            <p className="text-sm md:text-base text-white/90 mt-1">
              Track your solo budgets or split group costs without leaving this workspace.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-5xl px-4 mx-auto mt-10 pb-12 space-y-10">
        {/* Trip setup */}
        <motion.div
          className="tg-card bg-white p-6 border border-gray-100 shadow-xl"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-indigo-500" />
              <div>
                <h3 className="text-xl font-bold text-gray-900">Trip Mode</h3>
                <p className="text-sm text-gray-600">
                  Choose whether you are tracking a solo budget or splitting with a group.
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => switchMode('solo')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  tripMode === 'solo'
                    ? 'bg-gradient-to-r from-blue-600 to-teal-500 text-white shadow-md'
                    : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                Solo Trip
              </button>
              <button
                onClick={() => switchMode('group')}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  tripMode === 'group'
                    ? 'bg-gradient-to-r from-blue-600 to-teal-500 text-white shadow-md'
                    : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                Group Trip
              </button>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-3">
            <label className="md:col-span-2">
              <span className="text-sm text-gray-700 font-semibold mb-1 block">Planned Trips</span>
              <select
                value={selectedTripId}
                onChange={e => void loadTrip(e.target.value)}
                disabled={loadingTrips || !plannedTrips.length}
                className="w-full px-3 py-2 rounded-lg border border-gray-300 bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-60"
              >
                {loadingTrips && <option>Loading your trips...</option>}
                {!loadingTrips && plannedTrips.length === 0 && <option value="">No trips available</option>}
                {!loadingTrips &&
                  plannedTrips.map(trip => (
                    <option key={trip.id} value={trip.id}>
                      {trip.name} - {trip.dateRange}
                    </option>
                  ))}
              </select>
              {tripError && <p className="text-xs text-red-600 mt-1">{tripError}</p>}
            </label>

            <label className="flex flex-col">
              <span className="text-sm text-gray-700 font-semibold mb-1 block">Total Trip Budget</span>
              <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-indigo-500 bg-white">
                <Wallet2 className="w-4 h-4 text-gray-500" />
                <input
                  type="number"
                  value={baseBudget}
                  onChange={e => setBaseBudget(e.target.value)}
                  placeholder="e.g. 1200"
                  className="w-full bg-transparent focus:outline-none"
                />
              </div>
            </label>
          </div>

          <div className="mt-4 flex flex-col md:flex-row gap-3">
            <div className="flex-1 text-sm text-gray-600">
              Loaded trip:{' '}
              <span className="font-semibold text-gray-900">
                {selectedTrip?.name || 'None loaded'}
              </span>
            </div>
            <div className="px-3 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-800 w-full md:w-auto text-sm font-semibold">
              {tripMode === 'solo' ? 'Solo (1)' : `${participants.length} participant${participants.length === 1 ? '' : 's'}`}
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <motion.div className="lg:col-span-1 space-y-6" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
            {/* Participants Section */}
            <div className="tg-card p-6 shadow-lg">
              <div className="flex items-center mb-4">
                <Users className="w-5 h-5 text-blue-600 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">Participants ({participants.length}/6)</h2>
              </div>

              {participantHints.length > 0 && (
                <p className="text-xs text-gray-500 mb-2">
                  Loaded shared companions from your trip invites.
                </p>
              )}

              <div className="space-y-3 mb-4">
                {participants.map(p => (
                  <motion.div
                    key={p.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: p.color }} />
                      <span className="font-medium text-gray-700">{p.name}</span>
                    </div>
                    {tripMode === 'group' && participants.length > 1 && (
                      <button onClick={() => removeParticipant(p.id)} className="text-red-500 hover:text-red-700 transition">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </motion.div>
                ))}
              </div>

              {tripMode === 'group' && participants.length < 6 && (
                <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
                  <div className="flex-1 min-w-0">
                    <input
                      type="text"
                      value={newParticipantName}
                      onChange={e => setNewParticipantName(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && addParticipant()}
                      placeholder="Add participant"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    {companionSuggestions.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {companionSuggestions.slice(0, 4).map(name => (
                          <button
                            key={name}
                            type="button"
                            onClick={() => {
                              setNewParticipantName(name);
                              setTimeout(addParticipant, 0);
                            }}
                            className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-blue-50 border border-gray-200"
                          >
                            {name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={addParticipant}
                    className="sm:w-auto w-full justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center gap-2 whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    Add
                  </button>
                </div>
              )}
            </div>

            {/* Add Expense Form */}
            <div className="tg-card p-6 shadow-lg">
              <div className="flex items-center mb-4">
                <DollarSign className="w-5 h-5 text-green-600 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">Add Expense</h2>
              </div>

              <div className="space-y-3">
                {expenseError && (
                  <div className="p-3 bg-red-50 border border-red-200 text-sm text-red-700 rounded-lg">
                    {expenseError}
                  </div>
                )}

                <div className="space-y-1">
                  <input
                    type="text"
                    value={newExpense.description}
                    onChange={e => setNewExpense({ ...newExpense, description: e.target.value })}
                    placeholder="Description (pick from itinerary or type)"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  {itineraryItems.length === 0 && selectedTripId && (
                    <p className="text-xs text-gray-500">
                      No itinerary items yet for this trip. We will create one when you save your first expense.
                    </p>
                  )}
                  {itineraryItems.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {itineraryItems.slice(0, 6).map(item => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() =>
                            setNewExpense(prev => ({
                              ...prev,
                              description: item.title || item.description || '',
                            }))
                          }
                          className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-blue-50 border border-gray-200"
                        >
                          {item.title || 'Untitled'}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <input
                  type="number"
                  value={newExpense.amount}
                  onChange={e => setNewExpense({ ...newExpense, amount: e.target.value })}
                  placeholder="Amount"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />

                <select
                  value={newExpense.paidBy}
                  onChange={e => setNewExpense({ ...newExpense, paidBy: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled={participants.length === 0}
                >
                  {participants.map(p => (
                    <option key={p.id} value={p.id}>
                      {tripMode === 'solo' ? 'You paid' : `${p.name} paid`}
                    </option>
                  ))}
                </select>

                <input
                  type="date"
                  value={newExpense.date}
                  onChange={e => setNewExpense({ ...newExpense, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />

                {savingItinerary && (
                  <p className="text-xs text-blue-600">
                    Saving to itinerary and syncing with your trip plan...
                  </p>
                )}

                <button onClick={addExpense} className="w-full tg-btn-primary">
                  <Plus className="w-4 h-4" />
                  Add Expense
                </button>
              </div>
            </div>
          </motion.div>

          {/* Right Column */}
          <motion.div className="lg:col-span-2 space-y-6" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6 }}>
            {/* Summary */}
            <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Summary</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm">
                  <p className="text-gray-600 text-sm">Total Expenses</p>
                  <p className="text-3xl font-bold text-blue-600">{currencySymbol}{totalExpenses.toFixed(2)}</p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm">
                  <p className="text-gray-600 text-sm">Per Person</p>
                  <p className="text-3xl font-bold text-green-600">{currencySymbol}{(totalExpenses / (participants.length || 1)).toFixed(2)}</p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm">
                  <p className="text-gray-600 text-sm">Expenses</p>
                  <p className="text-3xl font-bold text-purple-600">{expenses.length}</p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm">
                  <p className="text-gray-600 text-sm">Budget Left</p>
                  <p className={`text-3xl font-bold ${budgetLeft >= 0 ? 'text-emerald-600' : 'text-red-600'} overflow-hidden`}>
                    {parsedBudget > 0 ? `${currencySymbol}${budgetLeft.toFixed(2)}` : 'Not set'}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-3">Balances</h3>
                <div className="space-y-2">
                  {participants.map(p => {
                    const balance = balances[p.id] || 0;
                    const isPositive = balance > 0;
                    return (
                      <div key={p.id} className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }} />
                          <span className="font-medium text-gray-700">{p.name}</span>
                        </div>
                        <span className={`font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                          {isPositive ? '+' : ''}{currencySymbol}{Math.abs(balance).toFixed(2)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Settlements */}
            {settlements.length > 0 && tripMode === 'group' && (
              <div className="bg-gradient-to-br from-emerald-50 to-white rounded-2xl shadow-lg p-6 border border-emerald-100">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Who Owes Whom</h2>
                <div className="space-y-3">
                  {settlements.map((settlement, idx) => (
                    <motion.div
                      key={idx}
                      className="flex items-center justify-between p-4 bg-white rounded-lg"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                    >
                      <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: getParticipantColor(settlement.from) }} />
                      <span className="font-medium text-gray-700">{getParticipantName(settlement.from)}</span>
                        <span className="text-gray-500">{'->'}</span>
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: getParticipantColor(settlement.to) }} />
                      <span className="font-medium text-gray-700">{getParticipantName(settlement.to)}</span>
                    </div>
                      <span className="text-lg font-bold text-green-600">{currencySymbol}{settlement.amount.toFixed(2)}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Expenses List */}
            {expenses.length > 0 && (
              <div className="tg-card p-6 shadow-lg">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Expenses</h2>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {expenses.map((expense, idx) => (
                    <motion.div
                      key={expense.id}
                      className="p-4 bg-gray-50 rounded-lg"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-gray-900">{expense.description}</p>
                          <p className="text-sm text-gray-600">
                            {getParticipantName(expense.paidBy)} paid on {expense.date}
                          </p>
                        </div>
                        <button onClick={() => removeExpense(expense.id)} className="text-red-500 hover:text-red-700 transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {tripMode === 'group' && (
                        <div className="mb-3">
                          <p className="text-sm text-gray-700 font-semibold mb-2">Split among:</p>
                          <div className="flex flex-wrap gap-2">
                            {participants.map(p => (
                              <button
                                key={p.id}
                                onClick={() => toggleParticipantInExpense(expense.id, p.id)}
                                className={`px-3 py-1 rounded-full text-sm transition ${
                                  expense.splitAmong.includes(p.id) ? 'bg-blue-200 text-blue-800 font-semibold' : 'bg-gray-200 text-gray-600'
                                }`}
                              >
                                {p.name}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <p className="text-lg font-bold text-green-600">{currencySymbol}{expense.amount.toFixed(2)}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ExpenseSplitterPage;
