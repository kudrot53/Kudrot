import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Flame, Award, Globe, MapPin, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { listPublicTravels } from '../api/firebase-firestore';

interface LeaderboardUser {
  id: string;
  username: string;
  full_name: string;
  avatar_url?: string | null;
  is_premium: boolean;
  public_travels: number;
  completed_achievements: number;
  points: number;
}

type SortTab = 'points' | 'travels' | 'achievements';

const LeaderboardPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<SortTab>('points');
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user_data');
    if (!storedUser) return;

    try {
      const parsed = JSON.parse(storedUser);
      if (parsed?.uid || parsed?.id) {
        setCurrentUserId(String(parsed.uid ?? parsed.id));
      }
    } catch {
      // Ignore malformed user data.
    }
  }, []);

  useEffect(() => {
    let cancelled = false;

    const loadLeaderboard = async () => {
      setLoading(true);
      setError(null);
      try {
        const travels = await listPublicTravels(100);
        if (cancelled) return;
        const grouped: Record<string, LeaderboardUser> = {};
        travels.forEach((t: any, idx: number) => {
          const owner = t.userId || t.ownerUid || `user-${idx}`;
          if (!grouped[owner]) {
            grouped[owner] = {
              id: owner,
              username: owner,
              full_name: owner,
              avatar_url: null,
              is_premium: false,
              public_travels: 0,
              completed_achievements: 0,
              points: 0,
            };
          }
          grouped[owner].public_travels += 1;
          grouped[owner].points += 10;
        });
        setLeaderboard(Object.values(grouped));
      } catch (err) {
        if (cancelled) return;
        const message = err instanceof Error ? err.message : 'Failed to load leaderboard';
        setError(message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadLeaderboard();
    return () => {
      cancelled = true;
    };
  }, []);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-orange-600" />;
    return <span className="text-lg font-bold text-gray-600">#{rank}</span>;
  };

  const sortedLeaderboard = useMemo(() => {
    const sorted = [...leaderboard].sort((a, b) => {
      if (activeTab === 'points') return b.points - a.points;
      if (activeTab === 'travels') return b.public_travels - a.public_travels;
      return b.completed_achievements - a.completed_achievements;
    });

    return sorted.map((entry, idx) => ({ ...entry, rank: idx + 1 }));
  }, [leaderboard, activeTab]);

  const currentUserRank = useMemo(
    () => sortedLeaderboard.find(entry => entry.id === currentUserId) ?? null,
    [sortedLeaderboard, currentUserId],
  );

  const totalPlayers = leaderboard.length;
  const totalPoints = leaderboard.reduce((sum, user) => sum + (user.points || 0), 0);
  const totalTravels = leaderboard.reduce((sum, user) => sum + (user.public_travels || 0), 0);

  const stats = [
    { label: 'Total Players', value: totalPlayers.toLocaleString(), icon: Globe },
    { label: 'Total Points', value: totalPoints.toLocaleString(), icon: Trophy },
    { label: 'Public Trips Shared', value: totalTravels.toLocaleString(), icon: MapPin },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-teal-600 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => navigate('/')}
              className="text-white hover:bg-white hover:bg-opacity-20 px-4 py-2 rounded-lg transition"
            >
              {'< Back to Home'}
            </button>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-8 h-8" />
            <h1 className="text-4xl font-bold">Leaderboard</h1>
          </div>
          <p className="text-blue-100">Climb the ranks by earning achievements and sharing your trips.</p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-semibold">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-lg">
                  <stat.icon className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Sort Filters */}
        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex gap-2">
            {(['points', 'travels', 'achievements'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg font-semibold transition ${
                  activeTab === tab
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                {tab === 'points' && 'Points'}
                {tab === 'travels' && 'Public Trips'}
                {tab === 'achievements' && 'Achievements'}
              </button>
            ))}
          </div>
        </div>

        {/* Loading / Error States */}
        {loading && (
          <div className="bg-white rounded-lg shadow-lg p-6 text-center text-gray-700">
            Loading leaderboard...
          </div>
        )}
        {error && !loading && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-red-700">
            {error}
          </div>
        )}

        {/* Current User Card */}
        {!loading && !error && currentUserRank && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 bg-gradient-to-r from-blue-100 to-teal-100 border-2 border-blue-400 rounded-lg p-6"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-blue-600 rounded-full flex items-center justify-center text-2xl text-white">
                  {currentUserRank.avatar_url ? (
                    <img
                      src={currentUserRank.avatar_url}
                      alt={currentUserRank.username}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    currentUserRank.username.slice(0, 2).toUpperCase()
                  )}
                </div>
                <div>
                  <p className="text-sm text-gray-600">Your Rank</p>
                  <h3 className="text-2xl font-bold text-gray-900">{currentUserRank.full_name}</h3>
                  <p className="text-sm text-gray-600">@{currentUserRank.username}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center justify-end gap-2 mb-2">
                  <Flame className="w-5 h-5 text-orange-500" />
                  <span className="text-3xl font-bold text-gray-900">#{currentUserRank.rank}</span>
                </div>
                <p className="text-sm text-gray-600">{currentUserRank.points.toLocaleString()} points</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Leaderboard Table */}
        {!loading && !error && (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Rank</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Player</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">
                      {activeTab === 'points' && 'Points'}
                      {activeTab === 'travels' && 'Public Trips'}
                      {activeTab === 'achievements' && 'Completed Achievements'}
                    </th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">Achievements</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">Public Trips</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedLeaderboard.map((user, index) => (
                    <motion.tr
                      key={user.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.04 }}
                      className={`border-b border-gray-200 hover:bg-gray-50 transition ${
                        currentUserRank?.id === user.id ? 'bg-blue-50' : ''
                      }`}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center">{getRankIcon(user.rank)}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-teal-500 rounded-full flex items-center justify-center text-sm font-semibold text-white">
                            {user.avatar_url ? (
                              <img
                                src={user.avatar_url}
                                alt={user.username}
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              user.username.slice(0, 2).toUpperCase()
                            )}
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{user.full_name}</p>
                            <p className="text-xs text-gray-600">
                              @{user.username}{' '}
                              {user.is_premium && <Sparkles className="inline w-4 h-4 text-yellow-500 ml-1" />}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="font-bold text-gray-900">
                          {activeTab === 'points' && user.points.toLocaleString()}
                          {activeTab === 'travels' && user.public_travels}
                          {activeTab === 'achievements' && user.completed_achievements}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right text-gray-700">{user.completed_achievements}</td>
                      <td className="px-6 py-4 text-right text-gray-700">{user.public_travels}</td>
                    </motion.tr>
                  ))}

                  {sortedLeaderboard.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-6 text-center text-gray-600">
                        No leaderboard entries yet. Earn achievements to appear here.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Achievement Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-12 bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg p-8 border border-blue-200"
        >
          <div className="flex items-start gap-4">
            <Award className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">How to Climb the Leaderboard</h3>
              <ul className="space-y-2 text-gray-700">
                <li>Complete achievements to earn more points.</li>
                <li>Share public trips to showcase your journeys.</li>
                <li>Keep your streak by planning and finishing travels.</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LeaderboardPage;
