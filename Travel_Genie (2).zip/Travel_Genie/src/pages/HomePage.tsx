import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Menu, X, Plane, MapPin, Calendar, Users, Star, ChevronRight, Mail, Phone, MessageCircle } from 'lucide-react';
import Header from '../components/layout/Header';
import AboutSection from '../components/sections/AboutSection';
import ServicesSection from '../components/sections/ServicesSection';
import ContactSection from '../components/sections/ContactSection';
import FAQSection from '../components/sections/FAQSection';
import HeroSection from '../components/sections/HeroSection';

const HomePage = () => {
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className="min-h-screen">
            <Header isScrolled={isScrolled} />

            <main>
                <HeroSection />
                <AboutSection />
                <ServicesSection />
                <ContactSection />
                <FAQSection />
            </main>

            <footer className="bg-gray-900 text-white py-12">
                <div className="container mx-auto px-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div>
                            <div className="flex items-center space-x-2 mb-4">
                                <Plane className="w-6 h-6 text-blue-400" />
                                <span className="text-xl font-bold">Travel Genie</span>
                            </div>
                            <p className="text-gray-400">Your intelligent travel companion for unforgettable journeys.</p>
                        </div>

                        <div>
                            <h4 className="font-semibold mb-4">Quick Links</h4>
                            <ul className="space-y-2 text-gray-400">
                                <li><a href="#about" className="hover:text-white transition">About</a></li>
                                <li><a href="#services" className="hover:text-white transition">Services</a></li>
                                <li><a href="#contact" className="hover:text-white transition">Contact</a></li>
                                <li><a href="#faq" className="hover:text-white transition">FAQ</a></li>
                            </ul>
                        </div>

                        <div>
                            <h4 className="font-semibold mb-4">Services</h4>
                            <ul className="space-y-2 text-gray-400">
                                <li>Travel Planning</li>
                                <li>Destination Discovery</li>
                                <li>Itinerary Management</li>
                                <li>Budget Tracking</li>
                            </ul>
                        </div>

                        <div>
                            <h4 className="font-semibold mb-4">Connect</h4>
                            <div className="flex space-x-4">
                                <Mail className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition" />
                                <Phone className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition" />
                                <MessageCircle className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition" />
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
                        <p>&copy; 2024 Travel Genie. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default HomePage;