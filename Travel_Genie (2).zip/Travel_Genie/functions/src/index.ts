import * as admin from 'firebase-admin';
import { onRequest } from 'firebase-functions/v2/https';
import { logger } from 'firebase-functions';
import cors from 'cors';

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();
const CACHE_TTL_MS = 45 * 60 * 1000; // 45 minutes
const allowedOrigins = [
  'http://localhost:5173',
  'https://travel-genie-e4193.web.app',
  'https://travel-genie-e4193.firebaseapp.com',
];

const corsHandler = cors({
  origin: allowedOrigins,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
});

const withCors = (fn: (req: any, res: any) => Promise<void> | void) => {
  return (req: any, res: any) =>
    corsHandler(req, res, async () => {
      const origin = req.headers.origin;
      if (origin && allowedOrigins.includes(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
      } else {
        // Fallback for unexpected origins: still allow GET without credentials
        res.setHeader('Access-Control-Allow-Origin', '*');
      }
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

      if (req.method === 'OPTIONS') {
        res.status(204).send('');
        return;
      }

      try {
        await fn(req, res);
      } catch (error) {
        logger.error('Function error', error);
        res.status(500).json({ error: (error as Error).message || 'Internal error' });
      }
    });
};

export const getRates = onRequest(withCors(async (req, res) => {
  const baseParam = (req.query.base as string) || 'USD';
  const base = baseParam.trim().toUpperCase().replace(/[^A-Z]/g, '');
  if (!base) {
    res.status(400).json({ error: 'Missing base currency (e.g., USD)' });
    return;
  }

  const cacheRef = db.collection('fxCache').doc(base);
  const cacheSnap = await cacheRef.get();
  const now = Date.now();
  const cachedExpires = cacheSnap.exists ? cacheSnap.data()?.expiresAt?.toMillis?.() : 0;

  if (cacheSnap.exists && cachedExpires && cachedExpires > now) {
    const data = cacheSnap.data() || {};
    res.json({
      base,
      date: data.date || new Date().toISOString(),
      rates: data.rates || {},
      cached: true,
    });
    return;
  }

  const fxResp = await fetch(`https://api.exchangerate.host/latest?base=${encodeURIComponent(base)}`);
  if (!fxResp.ok) {
    const text = await fxResp.text();
    throw new Error(`FX provider error ${fxResp.status}: ${text}`);
  }
  const body = await fxResp.json();
  const rates = body?.rates || {};
  const date = body?.date || new Date().toISOString();

  await cacheRef.set(
    {
      base,
      rates,
      date,
      fetchedAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: admin.firestore.Timestamp.fromMillis(now + CACHE_TTL_MS),
    },
    { merge: true },
  );

  res.json({
    base,
    date,
    rates,
    cached: false,
  });
}));

export const getSafety = onRequest(withCors(async (req, res) => {
  const country = ((req.query.country as string) || '').trim() || 'Unknown';
  const city = ((req.query.city as string) || '').trim() || null;

  res.json({
    country,
    city,
    safety: {
      advisory: `Stay aware of local guidelines and advisories for ${city || country}.`,
      medical: 'Carry basic medication and keep travel insurance details handy.',
      emergency: 'Save local emergency numbers before you travel.',
    },
    weather_alerts: [],
  });
}));

export const getRecommendations = onRequest(withCors(async (req, res) => {
  const country = ((req.query.country as string) || '').trim() || 'Unknown';
  const city = ((req.query.city as string) || '').trim() || null;

  res.json({
    country,
    city,
    currency: { note: 'Use getRates for live FX conversions', baseHint: 'USD' },
    language: { primary: 'English (varies by region)', tip: 'Learn a local greeting to break the ice.' },
    electricity: { voltage: '220-240V in most regions', plugs: 'Common plugs: Type C/G/I (check your destination)' },
    water: { safe: false, guidance: 'Prefer bottled or filtered water unless local guidance says otherwise.' },
    vaccinations: [],
    suggested_activities: [
      `Explore a top landmark in ${city || country}`,
      'Try a local dish from a trusted spot',
      'Walk a popular market or neighborhood',
    ],
  });
}));
