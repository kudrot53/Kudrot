/**
 * Seed Travel Genie Firestore with Bangladesh-focused data (Firebase-only).
 * Usage:
 *   node scripts/seed-firestore.cjs path/to/serviceAccount.json YOUR_TEST_UID
 */
const admin = require("firebase-admin");
const fs = require("fs");

const saPath = process.argv[2];
const SEED_UID = process.argv[3];
if (!saPath || !SEED_UID) {
  console.error("Usage: node scripts/seed-firestore.cjs serviceAccount.json YOUR_TEST_UID");
  process.exit(1);
}

admin.initializeApp({
  credential: admin.credential.cert(JSON.parse(fs.readFileSync(saPath, "utf8"))),
});

const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;
const now = () => FieldValue.serverTimestamp();

async function setDoc(path, data) {
  const parts = path.split("/");
  let ref = db.collection(parts[0]).doc(parts[1]);
  for (let i = 2; i < parts.length; i += 2) {
    ref = ref.collection(parts[i]).doc(parts[i + 1]);
  }
  await ref.set(data, { merge: true });
}

function slug(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

// ---------------------------
// 50 Bangladesh destinations
// ---------------------------
const destinationsBD = [
  { name: "Lalbagh Fort", city: "Dhaka", category: "heritage", lat: 23.7189, lng: 90.3887, cost: 35 },
  { name: "Ahsan Manzil (Pink Palace)", city: "Dhaka", category: "heritage", lat: 23.7086, lng: 90.4072, cost: 35 },
  { name: "Bangladesh National Museum", city: "Dhaka", category: "museum", lat: 23.7392, lng: 90.3921, cost: 40 },
  { name: "Dhakeshwari National Temple", city: "Dhaka", category: "culture", lat: 23.7231, lng: 90.3885, cost: 30 },
  { name: "Hatirjheel", city: "Dhaka", category: "city", lat: 23.7633, lng: 90.4092, cost: 25 },

  { name: "Patenga Sea Beach", city: "Chattogram", category: "beach", lat: 22.2393, lng: 91.8135, cost: 45 },
  { name: "Foy's Lake", city: "Chattogram", category: "nature", lat: 22.3617, lng: 91.8146, cost: 50 },
  { name: "Ethnological Museum", city: "Chattogram", category: "museum", lat: 22.3337, lng: 91.8317, cost: 35 },

  { name: "Cox's Bazar Sea Beach", city: "Cox's Bazar", category: "beach", lat: 21.4272, lng: 92.0058, cost: 60 },
  { name: "Himchari National Park", city: "Cox's Bazar", category: "nature", lat: 21.3667, lng: 92.0167, cost: 55 },
  { name: "Inani Beach", city: "Cox's Bazar", category: "beach", lat: 21.15, lng: 92.05, cost: 55 },
  { name: "Maheshkhali Island", city: "Cox's Bazar", category: "island", lat: 21.55, lng: 91.95, cost: 50 },

  { name: "St. Martin's Island", city: "Teknaf", category: "island", lat: 20.6236, lng: 92.323, cost: 75 },

  { name: "Jaflong", city: "Sylhet", category: "nature", lat: 25.1647, lng: 92.0171, cost: 55 },
  { name: "Ratargul Swamp Forest", city: "Sylhet", category: "nature", lat: 25.0, lng: 91.9, cost: 55 },
  { name: "Bichanakandi", city: "Sylhet", category: "nature", lat: 25.1526, lng: 92.086, cost: 55 },
  { name: "Shrine of Hazrat Shah Jalal", city: "Sylhet", category: "culture", lat: 24.8917, lng: 91.8687, cost: 35 },

  { name: "Sreemangal Tea Gardens", city: "Sreemangal", category: "nature", lat: 24.3065, lng: 91.7296, cost: 55 },
  { name: "Lawachara National Park", city: "Sreemangal", category: "wildlife", lat: 24.33, lng: 91.78, cost: 60 },

  { name: "Kaptai Lake", city: "Rangamati", category: "nature", lat: 22.495, lng: 92.19, cost: 60 },
  { name: "Hanging Bridge (Rangamati)", city: "Rangamati", category: "nature", lat: 22.638, lng: 92.178, cost: 45 },
  { name: "Sajek Valley", city: "Khagrachari", category: "mountain", lat: 23.3833, lng: 92.2833, cost: 70 },
  { name: "Nilgiri Hills", city: "Bandarban", category: "mountain", lat: 21.9667, lng: 92.3, cost: 70 },
  { name: "Nilachal", city: "Bandarban", category: "mountain", lat: 22.2, lng: 92.2, cost: 65 },
  { name: "Boga Lake", city: "Bandarban", category: "mountain", lat: 21.8, lng: 92.4, cost: 75 },

  { name: "Sundarbans (Mangrove Forest)", city: "Khulna", category: "wildlife", lat: 22.0, lng: 89.6, cost: 80 },
  { name: "Kuakata Sea Beach", city: "Kuakata", category: "beach", lat: 21.8167, lng: 90.1167, cost: 60 },

  { name: "Paharpur Buddhist Vihara", city: "Naogaon", category: "heritage", lat: 25.0317, lng: 88.9772, cost: 55 },
  { name: "Mahasthangarh", city: "Bogura", category: "heritage", lat: 24.9575, lng: 89.3428, cost: 50 },
  { name: "Mainamati Ruins", city: "Cumilla", category: "heritage", lat: 23.4633, lng: 91.1789, cost: 50 },

  { name: "Shilpacharya Zainul Abedin Museum", city: "Mymensingh", category: "museum", lat: 24.7471, lng: 90.4203, cost: 35 },
  { name: "Bhawal National Park", city: "Gazipur", category: "nature", lat: 24.0, lng: 90.43, cost: 45 },
  { name: "Atia Mosque", city: "Tangail", category: "heritage", lat: 24.2392, lng: 89.9442, cost: 35 },
  { name: "Bikrampur Museum", city: "Munshiganj", category: "museum", lat: 23.543, lng: 90.531, cost: 35 },
  { name: "Sonargaon (Panam City)", city: "Narayanganj", category: "heritage", lat: 23.65, lng: 90.6, cost: 45 },
  { name: "Michael Madhusudan Dutt Memorial", city: "Jashore", category: "culture", lat: 23.1667, lng: 89.2, cost: 30 },
  { name: "Kantajew Temple", city: "Dinajpur", category: "heritage", lat: 25.8, lng: 88.65, cost: 50 },
  { name: "Hardinge Bridge Viewpoint", city: "Pabna", category: "nature", lat: 24.0667, lng: 89.0333, cost: 35 },

  { name: "Shat Gombuj Mosque", city: "Bagerhat", category: "heritage", lat: 22.6525, lng: 89.7858, cost: 50 },
  { name: "Bagerhat Historic Mosque City", city: "Bagerhat", category: "heritage", lat: 22.65, lng: 89.79, cost: 50 },
  { name: "Sompur Mahavihara Museum Area", city: "Naogaon", category: "museum", lat: 25.031, lng: 88.978, cost: 45 },
  { name: "Jatiyo Smriti Soudho", city: "Savar", category: "heritage", lat: 23.9156, lng: 90.2581, cost: 35 },
  { name: "Nijhum Dwip", city: "Noakhali", category: "island", lat: 22.05, lng: 91.0, cost: 70 },
  { name: "Sonadia Island", city: "Cox's Bazar", category: "island", lat: 21.4833, lng: 91.9, cost: 70 },
  { name: "Chandranath Hill", city: "Sitakunda", category: "mountain", lat: 22.6167, lng: 91.6667, cost: 50 },
  { name: "Sitakunda Eco Park", city: "Sitakunda", category: "nature", lat: 22.611, lng: 91.676, cost: 45 },
  { name: "Alutila Cave", city: "Khagrachari", category: "nature", lat: 23.1, lng: 91.98, cost: 45 },
  { name: "Keokradong Trek Start", city: "Bandarban", category: "mountain", lat: 21.9333, lng: 92.45, cost: 85 },
  { name: "Tanguar Haor", city: "Sunamganj", category: "nature", lat: 25.05, lng: 91.05, cost: 80 },
  { name: "Bisanakandi River Walks", city: "Sylhet", category: "nature", lat: 25.15, lng: 92.09, cost: 55 },
  { name: "Shalbon Bihar", city: "Cumilla", category: "heritage", lat: 23.4638, lng: 91.1794, cost: 45 },
  { name: "War Cemetery", city: "Chattogram", category: "heritage", lat: 22.355, lng: 91.825, cost: 25 },
  { name: "Cox's Bazar Marine Drive", city: "Cox's Bazar", category: "city", lat: 21.3, lng: 92.05, cost: 40 },
  { name: "Baitul Mukarram Mosque", city: "Dhaka", category: "culture", lat: 23.7336, lng: 90.4106, cost: 25 },
  { name: "Ramna Park", city: "Dhaka", category: "city", lat: 23.7396, lng: 90.4057, cost: 20 },
  { name: "Curzon Hall Area", city: "Dhaka", category: "heritage", lat: 23.727, lng: 90.3996, cost: 20 },
];

// ---------------------------
// Achievements catalog
// ---------------------------
const achievements = [
  { id: "first_trip", name: "First Trip", description: "Create your first trip", icon_url: "", badge_color: "#3B82F6", points: 10, category: "starter", is_active: true },
  { id: "planner_5", name: "Planner", description: "Add 5 itinerary items", icon_url: "", badge_color: "#10B981", points: 25, category: "planning", is_active: true },
  { id: "explorer_5", name: "Explorer", description: "Visit 5 destinations", icon_url: "", badge_color: "#F59E0B", points: 30, category: "travel", is_active: true },
  { id: "reviewer_3", name: "Reviewer", description: "Write 3 reviews", icon_url: "", badge_color: "#8B5CF6", points: 20, category: "community", is_active: true },
  { id: "budget_master", name: "Budget Master", description: "Finish a trip under budget", icon_url: "", badge_color: "#EF4444", points: 40, category: "finance", is_active: true },
];

// ---------------------------
// 100 planned activities (20 types × 5 each)
// ---------------------------
const plannedActivities100 = [
  // FOOD (5)
  { name: "Street Food Crawl (Old Dhaka)", cost: 12, category: "food", duration_hours: 2 },
  { name: "Biriyani Tasting Tour", cost: 15, category: "food", duration_hours: 2 },
  { name: "Iftar Market Visit (Ramadan season)", cost: 10, category: "food", duration_hours: 1.5 },
  { name: "Seafood Dinner (Cox's Bazar)", cost: 25, category: "food", duration_hours: 2 },
  { name: "Tea & Snacks Tasting (Sreemangal)", cost: 7, category: "food", duration_hours: 1 },

  // SIGHTSEEING (5)
  { name: "City Highlights Walk", cost: 10, category: "sightseeing", duration_hours: 2 },
  { name: "Rooftop Viewpoint Stop", cost: 5, category: "sightseeing", duration_hours: 1 },
  { name: "Landmark Photo Tour", cost: 8, category: "sightseeing", duration_hours: 2 },
  { name: "Evening Lights Walk", cost: 0, category: "sightseeing", duration_hours: 1.5 },
  { name: "Neighborhood Discovery Walk", cost: 0, category: "sightseeing", duration_hours: 2 },

  // CULTURE (5)
  { name: "Traditional Music Night", cost: 15, category: "culture", duration_hours: 2 },
  { name: "Local Theatre/Drama Show", cost: 12, category: "culture", duration_hours: 2 },
  { name: "Cultural Center Visit", cost: 8, category: "culture", duration_hours: 1.5 },
  { name: "Craft Demonstration Visit", cost: 10, category: "culture", duration_hours: 2 },
  { name: "Folk Art Gallery Visit", cost: 7, category: "culture", duration_hours: 1.5 },

  // HERITAGE (5)
  { name: "Lalbagh Fort Visit", cost: 5, category: "heritage", duration_hours: 2 },
  { name: "Ahsan Manzil Tour", cost: 5, category: "heritage", duration_hours: 2 },
  { name: "Panam City Walk (Sonargaon)", cost: 8, category: "heritage", duration_hours: 2.5 },
  { name: "Shat Gombuj Mosque Visit (Bagerhat)", cost: 6, category: "heritage", duration_hours: 2 },
  { name: "Mainamati Ruins Exploration", cost: 7, category: "heritage", duration_hours: 3 },

  // MUSEUM (5)
  { name: "National Museum Visit (Dhaka)", cost: 5, category: "museum", duration_hours: 2 },
  { name: "Ethnological Museum Visit (Chattogram)", cost: 4, category: "museum", duration_hours: 1.5 },
  { name: "Liberation War Museum Visit", cost: 5, category: "museum", duration_hours: 2 },
  { name: "Zainul Abedin Museum Visit", cost: 4, category: "museum", duration_hours: 1.5 },
  { name: "Local History Museum Stop", cost: 3, category: "museum", duration_hours: 1.5 },

  // NATURE (5)
  { name: "Tea Garden Walk (Sreemangal)", cost: 10, category: "nature", duration_hours: 2 },
  { name: "Ratargul Swamp Boat Ride", cost: 18, category: "nature", duration_hours: 2.5 },
  { name: "Waterfall Exploration", cost: 20, category: "nature", duration_hours: 3 },
  { name: "Sunrise Viewpoint Visit", cost: 8, category: "nature", duration_hours: 2 },
  { name: "River Cruise (short)", cost: 15, category: "nature", duration_hours: 2 },

  // WILDLIFE (5)
  { name: "Sundarbans Wildlife Cruise", cost: 45, category: "wildlife", duration_hours: 4 },
  { name: "Birdwatching Session", cost: 10, category: "wildlife", duration_hours: 2 },
  { name: "Dolphin Spotting (river)", cost: 25, category: "wildlife", duration_hours: 3 },
  { name: "National Park Guided Walk", cost: 18, category: "wildlife", duration_hours: 3 },
  { name: "Butterfly & Nature Trail", cost: 8, category: "wildlife", duration_hours: 2 },

  // BEACH (5)
  { name: "Beach Leisure Time (Cox's Bazar)", cost: 0, category: "beach", duration_hours: 3 },
  { name: "Sunset at Inani Beach", cost: 0, category: "beach", duration_hours: 2 },
  { name: "Beachside Cycling", cost: 8, category: "beach", duration_hours: 1.5 },
  { name: "Beach Volleyball / Games", cost: 0, category: "beach", duration_hours: 2 },
  { name: "Early Morning Beach Walk", cost: 0, category: "beach", duration_hours: 1.5 },

  // ISLAND (5)
  { name: "St. Martin's Island Day Trip", cost: 35, category: "island", duration_hours: 8 },
  { name: "Snorkeling (St. Martin's)", cost: 20, category: "island", duration_hours: 2 },
  { name: "Island Sunset Walk", cost: 0, category: "island", duration_hours: 2 },
  { name: "Coral Beach Photo Stop", cost: 0, category: "island", duration_hours: 1.5 },
  { name: "Island Seafood Lunch", cost: 18, category: "island", duration_hours: 2 },

  // MOUNTAIN (5)
  { name: "Sajek Valley Viewpoint Visit", cost: 12, category: "mountain", duration_hours: 3 },
  { name: "Nilgiri Hills Scenic Stop", cost: 15, category: "mountain", duration_hours: 2.5 },
  { name: "Short Hill Trek", cost: 18, category: "mountain", duration_hours: 3 },
  { name: "Boga Lake Hike", cost: 22, category: "mountain", duration_hours: 5 },
  { name: "Keokradong Trek (short segment)", cost: 25, category: "mountain", duration_hours: 6 },

  // ADVENTURE (5)
  { name: "Cave Exploration (Alutila)", cost: 12, category: "adventure", duration_hours: 2 },
  { name: "Zipline / Adventure Park Visit", cost: 20, category: "adventure", duration_hours: 2 },
  { name: "Guided Jungle Trek", cost: 18, category: "adventure", duration_hours: 4 },
  { name: "Kayaking (calm water)", cost: 22, category: "adventure", duration_hours: 2.5 },
  { name: "Cycling Trail Ride", cost: 10, category: "adventure", duration_hours: 2 },

  // SHOPPING (5)
  { name: "New Market Bargain Shopping (Dhaka)", cost: 5, category: "shopping", duration_hours: 2.5 },
  { name: "Jamuna Future Park Visit", cost: 0, category: "shopping", duration_hours: 2.5 },
  { name: "Handloom Shopping (Tangail)", cost: 8, category: "shopping", duration_hours: 3 },
  { name: "Souvenir Shopping (Cox's Bazar)", cost: 6, category: "shopping", duration_hours: 2 },
  { name: "Local Handicraft Market Visit", cost: 5, category: "shopping", duration_hours: 2 },

  // CITY (5)
  { name: "Rickshaw Ride Experience", cost: 6, category: "city", duration_hours: 1 },
  { name: "Hatirjheel Evening Walk", cost: 0, category: "city", duration_hours: 2 },
  { name: "Old Dhaka Alley Walk", cost: 0, category: "city", duration_hours: 2.5 },
  { name: "Coffee Shop Crawl", cost: 12, category: "city", duration_hours: 2 },
  { name: "Local Street Photography Walk", cost: 0, category: "city", duration_hours: 2 },

  // LEISURE (5)
  { name: "Park Relaxation Time", cost: 0, category: "leisure", duration_hours: 2 },
  { name: "Riverside Chill Session", cost: 0, category: "leisure", duration_hours: 2 },
  { name: "Board Games Café Time", cost: 8, category: "leisure", duration_hours: 2 },
  { name: "Movie Night", cost: 7, category: "leisure", duration_hours: 2.5 },
  { name: "Evening Stroll & Snacks", cost: 5, category: "leisure", duration_hours: 2 },

  // WELLNESS (5)
  { name: "Local Spa / Massage Session", cost: 25, category: "wellness", duration_hours: 1.5 },
  { name: "Morning Yoga Session", cost: 10, category: "wellness", duration_hours: 1 },
  { name: "Meditation / Quiet Time", cost: 0, category: "wellness", duration_hours: 1 },
  { name: "Nature Breathing Walk", cost: 0, category: "wellness", duration_hours: 1.5 },
  { name: "Tea & Calm Evening", cost: 6, category: "wellness", duration_hours: 1.5 },

  // RELIGION (5)
  { name: "Baitul Mukarram Mosque Visit", cost: 0, category: "religion", duration_hours: 1.5 },
  { name: "Dhakeshwari Temple Visit", cost: 0, category: "religion", duration_hours: 1.5 },
  { name: "Shrine Visit (Shah Jalal)", cost: 0, category: "religion", duration_hours: 2 },
  { name: "Historic Mosque Architecture Walk", cost: 0, category: "religion", duration_hours: 2 },
  { name: "Quiet Reflection Time", cost: 0, category: "religion", duration_hours: 1 },

  // TRANSPORT (5)
  { name: "Local Launch Ride (short)", cost: 8, category: "transport", duration_hours: 2 },
  { name: "Train Ride Experience (intercity)", cost: 12, category: "transport", duration_hours: 4 },
  { name: "CNG Ride Across Town", cost: 4, category: "transport", duration_hours: 1 },
  { name: "Ferry Crossing (river)", cost: 5, category: "transport", duration_hours: 2 },
  { name: "Bus Ride + Local Snacks Stop", cost: 6, category: "transport", duration_hours: 3 },

  // PHOTOGRAPHY (5)
  { name: "Sunset Photography Session", cost: 0, category: "photography", duration_hours: 2 },
  { name: "Street Portrait Photo Walk", cost: 0, category: "photography", duration_hours: 2.5 },
  { name: "Architecture Photography Tour", cost: 0, category: "photography", duration_hours: 2 },
  { name: "Nature Landscape Photo Trip", cost: 0, category: "photography", duration_hours: 3 },
  { name: "Night City Photography", cost: 0, category: "photography", duration_hours: 2 },

  // FESTIVAL (5)
  { name: "Pohela Boishakh Celebration Walk", cost: 5, category: "festival", duration_hours: 3 },
  { name: "Eid Market & Lights Tour", cost: 8, category: "festival", duration_hours: 2.5 },
  { name: "Local Fair (Mela) Visit", cost: 4, category: "festival", duration_hours: 3 },
  { name: "Cultural Parade Viewing", cost: 0, category: "festival", duration_hours: 2 },
  { name: "Seasonal Night Bazaar Visit", cost: 6, category: "festival", duration_hours: 2.5 },

  // EDUCATION (5)
  { name: "University Campus Walk (DU area)", cost: 0, category: "education", duration_hours: 1.5 },
  { name: "Library / Bookstore Visit", cost: 0, category: "education", duration_hours: 2 },
  { name: "Science Museum / Exhibit Visit", cost: 6, category: "education", duration_hours: 2 },
  { name: "History Talk / Guided Lecture", cost: 10, category: "education", duration_hours: 1.5 },
  { name: "Local Workshop (craft/skills)", cost: 15, category: "education", duration_hours: 2.5 },

  // SPORTS (5)
  { name: "Cricket Match Viewing (local)", cost: 5, category: "sports", duration_hours: 3 },
  { name: "Badminton Session", cost: 4, category: "sports", duration_hours: 1.5 },
  { name: "Morning Jog by the Lake", cost: 0, category: "sports", duration_hours: 1 },
  { name: "Football Game (local field)", cost: 0, category: "sports", duration_hours: 2 },
  { name: "Cycling Workout Session", cost: 0, category: "sports", duration_hours: 1.5 },
];

// ---------------------------
// Itinerary generator (40 per trip)
// ---------------------------
function toISODate(d) {
  return d.toISOString().slice(0, 10);
}
function dateRangeInclusive(startISO, endISO) {
  const out = [];
  const start = new Date(startISO + "T00:00:00");
  const end = new Date(endISO + "T00:00:00");
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    out.push(toISODate(d));
  }
  return out;
}
function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function randCost(min, max) {
  if (min === 0 && max === 0) return 0;
  return Math.round(min + Math.random() * (max - min));
}

function buildTemplate(tripType) {
  const breakfast = [
    { title: "Breakfast", startTime: "08:30", endTime: "09:30", itemType: "meal", costMin: 4, costMax: 10 },
    { title: "Coffee & Snacks", startTime: "10:30", endTime: "11:00", itemType: "meal", costMin: 2, costMax: 6 },
  ];
  const lunch = [{ title: "Lunch", startTime: "13:00", endTime: "14:00", itemType: "meal", costMin: 6, costMax: 14 }];
  const dinner = [{ title: "Dinner", startTime: "19:30", endTime: "21:00", itemType: "meal", costMin: 10, costMax: 25 }];
  const transport = [
    { title: "Local Transport", startTime: "09:45", endTime: "10:15", itemType: "transport", costMin: 1, costMax: 6 },
    { title: "Transfer / Commute", startTime: "16:30", endTime: "17:00", itemType: "transport", costMin: 2, costMax: 10 },
  ];
  const misc = [
    { title: "Rest / Hotel Time", startTime: "14:30", endTime: "15:15", itemType: "leisure", costMin: 0, costMax: 0 },
    { title: "Tea Break", startTime: "16:15", endTime: "16:45", itemType: "meal", costMin: 1, costMax: 4 },
  ];

  if (tripType === "dhaka_heritage") {
    return {
      location: "Dhaka, Bangladesh",
      highlights: [
        { title: "Lalbagh Fort Visit", startTime: "11:00", endTime: "13:00", itemType: "activity", costMin: 2, costMax: 8 },
        { title: "Ahsan Manzil Tour", startTime: "11:30", endTime: "13:00", itemType: "activity", costMin: 2, costMax: 8 },
        { title: "National Museum Visit", startTime: "14:30", endTime: "16:00", itemType: "activity", costMin: 2, costMax: 6 },
        { title: "Old Dhaka Street Food Crawl", startTime: "16:00", endTime: "18:00", itemType: "activity", costMin: 6, costMax: 15 },
        { title: "Rickshaw Ride Through Old Town", startTime: "15:00", endTime: "16:00", itemType: "activity", costMin: 2, costMax: 6 },
        { title: "Hatirjheel Evening Walk", startTime: "17:30", endTime: "18:30", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Baitul Mukarram Mosque Visit", startTime: "10:45", endTime: "11:30", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Curzon Hall Photo Stop", startTime: "12:15", endTime: "12:45", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Ramna Park Stroll", startTime: "07:00", endTime: "08:00", itemType: "activity", costMin: 0, costMax: 0 },
      ],
      breakfast,
      lunch,
      dinner,
      transport,
      misc,
    };
  }

  if (tripType === "coxsbazar_beach") {
    return {
      location: "Cox's Bazar, Bangladesh",
      highlights: [
        { title: "Morning Beach Walk", startTime: "06:30", endTime: "07:30", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Cox's Bazar Beach Leisure", startTime: "10:30", endTime: "12:30", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Himchari National Park Visit", startTime: "11:00", endTime: "14:00", itemType: "activity", costMin: 3, costMax: 15 },
        { title: "Inani Beach Sunset", startTime: "16:00", endTime: "18:00", itemType: "activity", costMin: 0, costMax: 0 },
        { title: "Marine Drive Scenic Ride", startTime: "15:00", endTime: "16:00", itemType: "activity", costMin: 2, costMax: 10 },
        { title: "Souvenir Market Visit", startTime: "18:15", endTime: "19:00", itemType: "activity", costMin: 0, costMax: 25 },
        { title: "Beach Photography Session", startTime: "17:00", endTime: "18:00", itemType: "activity", costMin: 0, costMax: 0 },
      ],
      breakfast,
      lunch,
      dinner,
      transport,
      misc,
    };
  }

  // Default: Sylhet / nature-style
  return {
    location: "Sylhet, Bangladesh",
    highlights: [
      { title: "Tea Garden Walk (Sreemangal)", startTime: "09:30", endTime: "11:30", itemType: "activity", costMin: 2, costMax: 10 },
      { title: "Lawachara National Park Walk", startTime: "10:00", endTime: "13:00", itemType: "activity", costMin: 5, costMax: 18 },
      { title: "Ratargul Swamp Forest Boat Ride", startTime: "11:00", endTime: "13:30", itemType: "activity", costMin: 8, costMax: 22 },
      { title: "Jaflong Day Trip", startTime: "09:00", endTime: "16:00", itemType: "activity", costMin: 12, costMax: 30 },
      { title: "Bichanakandi Exploration", startTime: "10:30", endTime: "15:00", itemType: "activity", costMin: 12, costMax: 28 },
      { title: "Local Market Visit (Sylhet)", startTime: "17:00", endTime: "18:00", itemType: "activity", costMin: 0, costMax: 20 },
      { title: "Sunset Riverside Walk", startTime: "17:15", endTime: "18:15", itemType: "activity", costMin: 0, costMax: 0 },
    ],
    breakfast,
    lunch,
    dinner,
    transport,
    misc,
  };
}

function build40ItineraryItems(tripType, startISO, endISO) {
  const tpl = buildTemplate(tripType);
  const days = dateRangeInclusive(startISO, endISO);
  const out = [];
  let dayIndex = 0;

  while (out.length < 40) {
    const date = days[dayIndex % days.length];

    const b = pick(tpl.breakfast);
    out.push({ title: b.title, date, startTime: b.startTime, endTime: b.endTime, itemType: b.itemType, cost: randCost(b.costMin, b.costMax), location: tpl.location });

    const h1 = pick(tpl.highlights);
    out.push({ title: h1.title, date, startTime: h1.startTime, endTime: h1.endTime, itemType: h1.itemType, cost: randCost(h1.costMin, h1.costMax), location: tpl.location });

    const l = pick(tpl.lunch);
    out.push({ title: l.title, date, startTime: l.startTime, endTime: l.endTime, itemType: l.itemType, cost: randCost(l.costMin, l.costMax), location: tpl.location });

    let h2 = pick(tpl.highlights);
    if (h2.title === h1.title) h2 = pick(tpl.highlights);
    out.push({ title: h2.title, date, startTime: h2.startTime, endTime: h2.endTime, itemType: h2.itemType, cost: randCost(h2.costMin, h2.costMax), location: tpl.location });

    if (out.length < 40) {
      const extra = Math.random() < 0.6 ? pick(tpl.transport) : pick(tpl.misc);
      out.push({ title: extra.title, date, startTime: extra.startTime, endTime: extra.endTime, itemType: extra.itemType, cost: randCost(extra.costMin, extra.costMax), location: tpl.location });
    }

    if (out.length < 40 && Math.random() < 0.75) {
      const d = pick(tpl.dinner);
      out.push({ title: d.title, date, startTime: d.startTime, endTime: d.endTime, itemType: d.itemType, cost: randCost(d.costMin, d.costMax), location: tpl.location });
    }

    dayIndex++;
  }

  return out.slice(0, 40);
}

// ---------------------------
// MAIN
// ---------------------------
async function main() {
  // (Optional) public profile doc (useful if your UI reads publicUsers)
  await setDoc(`publicUsers/${SEED_UID}`, {
    uid: SEED_UID,
    username: "seed_user",
    avatarUrl: "",
    location: "Bangladesh",
    updatedAt: now(),
    createdAt: now(),
  });

  // Seed destinations
  for (const d of destinationsBD) {
    const id = slug(`${d.name}_${d.city}`);
    await setDoc(`destinations/${id}`, {
      name: d.name,
      description: `Explore ${d.name} in ${d.city}, Bangladesh.`,
      city: d.city,
      country: "Bangladesh",
      category: d.category,
      imageUrl: "",
      averageCostPerDay: d.cost,
      is_featured: ["Cox's Bazar Sea Beach", "St. Martin's Island", "Sundarbans (Mangrove Forest)", "Sajek Valley", "Sreemangal Tea Gardens"].includes(d.name),
      rating: Number((4.2 + Math.random() * 0.6).toFixed(1)),
      latitude: d.lat,
      longitude: d.lng,
      createdAt: now(),
      updatedAt: now(),
    });
  }

  // Seed achievements catalog
  for (const a of achievements) {
    await setDoc(`achievements/${a.id}`, { ...a, createdAt: now(), updatedAt: now() });
  }

  // Sample travels
  const sampleTravelDefs = [
    { title: "Dhaka Heritage Day", dest: "lalbagh_fort_dhaka", isPublic: false, start: "2025-12-20", end: "2025-12-20" },
    { title: "Cox's Bazar Weekend", dest: "cox_s_bazar_sea_beach_cox_s_bazar", isPublic: true, start: "2026-01-10", end: "2026-01-12" },
    { title: "Sylhet Nature Escape", dest: "jaflong_sylhet", isPublic: true, start: "2026-02-05", end: "2026-02-08" },
  ];

  for (const t of sampleTravelDefs) {
    const travelId = slug(`${t.title}_${t.start}`);

    await setDoc(`travels/${travelId}`, {
      userId: SEED_UID,
      title: t.title,
      description: `A curated trip: ${t.title}`,
      destinationId: t.dest,
      startDate: t.start,
      endDate: t.end,
      currency: "USD",
      numberOfTravelers: 2,
      isPublic: t.isPublic,
      status: "planned",
      budget: 300,
      createdAt: now(),
      updatedAt: now(),
    });

    // Trip plan
    const planId = "plan_1";
    await setDoc(`travels/${travelId}/tripPlans/${planId}`, {
      title: "Main Plan",
      description: "Auto-seeded plan",
      budget: 300,
      remaining_budget: 300,
      currency: "USD",
      preferred_activities: ["food", "sightseeing", "culture"],
      is_approved: true,
      travel_id: travelId,
      createdAt: now(),
      updatedAt: now(),
    });

    // Planned activities: 100 per travel plan
    for (let i = 0; i < plannedActivities100.length; i++) {
      const a = plannedActivities100[i];
      await setDoc(`travels/${travelId}/tripPlans/${planId}/plannedActivities/act_${i + 1}`, {
        ...a,
        description: `${a.name} in Bangladesh`,
        currency: "USD",
        location: "Bangladesh",
        booking_reference: "",
        is_completed: false,
        createdAt: now(),
        updatedAt: now(),
      });
    }

    // Itinerary items: 40 per travel (=> 120 total across 3 travels)
    let tripType = "sylhet_nature";
    const lowerTitle = (t.title || "").toLowerCase();
    if (lowerTitle.includes("dhaka")) tripType = "dhaka_heritage";
    if (lowerTitle.includes("cox")) tripType = "coxsbazar_beach";

    const items = build40ItineraryItems(tripType, t.start, t.end);

    for (let i = 0; i < items.length; i++) {
      await setDoc(`travels/${travelId}/itineraryItems/item_${i + 1}`, {
        title: items[i].title,
        description: "",
        date: items[i].date,
        startTime: items[i].startTime,
        endTime: items[i].endTime,
        location: items[i].location,
        cost: items[i].cost,
        bookingReference: "",
        notes: "",
        isCompleted: false,
        itemType: items[i].itemType,
        createdAt: now(),
        updatedAt: now(),
      });
    }
  }

  console.log("✅ Seed complete:");
  console.log(`- destinations: ${destinationsBD.length}`);
  console.log(`- achievements: ${achievements.length}`);
  console.log(`- travels: ${sampleTravelDefs.length} (each has 1 tripPlan, 100 plannedActivities, 40 itinerary items)`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
